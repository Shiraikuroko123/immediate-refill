"""Recompute the corresponding retrospective sensitivity analysis. Use reproduce.py from the ZIP root."""
import csv
import hashlib
import json
from pathlib import Path
import argparse

parser = argparse.ArgumentParser(add_help=False)
parser.add_argument('--out-dir', type=Path, required=True)
run_out = parser.parse_args().out_dir
from statistics import mean

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CLOCK = ROOT / "tracks/interference/prospective-device/session01/prediction.json"
QUESTIONS = ROOT / "tracks/interference/opportunity/results/questions.csv"


def wall_time(first, second, third, launch, costs):
    intervals = ((0, first), (0, second), (launch, launch + third))
    edges = sorted({edge for interval in intervals for edge in interval})
    return sum(
        (right - left) * costs[sum(start <= left < end for start, end in intervals)]
        for left, right in zip(edges, edges[1:])
    )


def best_third_launch(first, second, third, costs):
    # Interval ordering changes only where t or t+w3 crosses w1 or w2.
    # After both initial requests finish, further waiting cannot help.
    cuts = {0, first, second, max(0, first - third), max(0, second - third)}
    times = {t: wall_time(first, second, third, t, costs) for t in cuts}
    best_launch = min(cuts, key=lambda t: (times[t], t))
    return best_launch, times


def main():
    costs = [0, *json.loads(CLOCK.read_bytes())["clock_ms"]]
    with QUESTIONS.open(encoding="utf8", newline="") as stream:
        rows = list(csv.DictReader(stream))
    results = []
    for row in rows:
        first, second, third = (int(row[f"length_{i}"]) for i in range(3))
        best_launch, times = best_third_launch(first, second, third, costs)
        base = times[0]
        two_action = min(base, times[min(first, second)])
        # In the device witness the second path is the first to finish.
        # These interpretations of "delay until the second request finishes"
        # can diverge when the first two archived workloads vary.
        wait_for_second = times[second]
        best = times[best_launch]
        assert abs(base - float(row["immediate_ms"])) < 1e-8
        assert abs(two_action - float(row["oracle_ms"])) < 1e-8
        results.append(dict(
            question=row["question"], lengths=[first, second, third],
            best_launch=best_launch, immediate_ms=base,
            two_action_ms=two_action, continuous_ms=best, wait_for_second_ms=wait_for_second,
            two_action_gain_pct=100 * (1 - two_action / base),
            wait_for_second_oracle_gain_pct=100 * (1 - min(base, wait_for_second) / base),
            continuous_gain_pct=100 * (1 - best / base),
        ))
    summary = dict(
        scope="Post-hoc; first two launch at zero, all three must finish, known fixed lengths.",
        input_sha256={str(p.relative_to(ROOT).as_posix()): hashlib.sha256(p.read_bytes()).hexdigest()
                      for p in (CLOCK, QUESTIONS)},
        clock_ms=costs[1:], questions=len(rows),
        two_action_mean_gain_pct=mean(r["two_action_gain_pct"] for r in results),
        first_finishes_before_second=sum(r["lengths"][0] < r["lengths"][1] for r in results),
        wait_for_second_oracle_mean_gain_pct=mean(r["wait_for_second_oracle_gain_pct"] for r in results),
        wait_for_second_better_than_immediate=sum(r["wait_for_second_oracle_gain_pct"] > 1e-8 for r in results),
        continuous_mean_gain_pct=mean(r["continuous_gain_pct"] for r in results),
        two_action_better_than_immediate=sum(r["two_action_gain_pct"] > 1e-8 for r in results),
        continuous_better_than_immediate=sum(r["continuous_gain_pct"] > 1e-8 for r in results),
        continuous_better_than_two_action=sum(
            r["two_action_ms"] - r["continuous_ms"] > 1e-8 for r in results
        ),
    )
    (run_out / "third-launch-oracle.json").write_text(
        json.dumps(dict(summary=summary, per_question=results), indent=2) + "\n", encoding="utf8"
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
