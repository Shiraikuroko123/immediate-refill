"""Run fixed scheduling policies on four public, immutable Qwen3-4B output files."""
import csv
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import random
import re
import sys

import requests

HERE = Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/"validation"))
import validate

REPO = "reasoning-cues/rollouts-qwen4b"
REV = "b8c33b85a1a6cdfb23b06a5f9d696f52950780e4"
EXPECTED = {
    "rollouts_base_none_p00000.jsonl": (4678427, "703cb11de67833bc1a6c7f8d359c4d4e6acec532"),
    "rollouts_base_none_p00000_b2.jsonl": (4137763, "932058e76b15376b95428bdc6fbb414948c76c63"),
    "rollouts_base_none_p00025.jsonl": (809486, "7045bd4c168c22fd82534556060625cfdaa55a49"),
    "rollouts_base_none_p00025_b2.jsonl": (756078, "e2626ff936c8b06bfa5e03e61309ea3821d14134"),
}


def boxed(text):
    matches = list(re.finditer(r"\\boxed\s*\{", text))
    if not matches:
        return None
    start = matches[-1].end()
    depth = 1
    for idx in range(start,len(text)):
        depth += (text[idx] == "{") - (text[idx] == "}")
        if depth == 0:
            inside = re.sub(r"\s", "",text[start:idx]).replace(r"\,", "").replace(r"\!", "").strip("$")
            return str(int(inside)) if re.fullmatch(r"[0-9]{1,3}",inside) else None
    return None


def read_pool():
    pool = defaultdict(list)
    raw_dir = HERE/"raw"
    raw_dir.mkdir(exist_ok=True)
    sources = []
    for name, (size,git_oid) in EXPECTED.items():
        path = raw_dir/name
        url = f"https://www.huggingface.co/datasets/{REPO}/resolve/{REV}/boxed/aime2024/run/{name}"
        if path.exists():
            content = path.read_bytes()
        else:
            with requests.get(url,headers={"Host":"huggingface.co"},timeout=(8,30)) as response:
                response.raise_for_status()
                content=response.content
        assert len(content) == size
        assert hashlib.sha1(f"blob {size}\0".encode()+content).hexdigest() == git_oid
        if not path.exists():
            path.write_bytes(content)
        sources.append(dict(url=url,bytes=size,sha256=hashlib.sha256(content).hexdigest(),git_oid=git_oid))
        batch = int(name.endswith("_b2.jsonl"))
        for line_number,line in enumerate(content.splitlines(),1):
            row = json.loads(line)
            length = row["output_tokens"]
            assert type(length) is int and 0 < length <= 31744
            pool[row["problem_key"]].append(dict(index=row["rollout_index"], length=length,
                final=boxed(row["completion"]), batch=batch, source_file=name, line=line_number,
                cap=bool(row["hit_token_cap"]), finish_reason=row["finish_reason"]))
    assert len(pool)==30 and all(len(paths)==32 for paths in pool.values())
    return pool,sources


def main(out):
    frozen = json.loads((HERE/"freeze.json").read_bytes())
    for label,digest in frozen["inputs"].items():
        assert hashlib.sha256((HERE/label).read_bytes()).hexdigest()==digest,label
    out.mkdir(exist_ok=False)
    started=datetime.now(timezone.utc).isoformat()
    pool,sources=read_pool()
    schedule_rows = []
    trace_rows = []
    questions = []
    for ordinal,(key,records) in enumerate(sorted(pool.items())):
        records.sort(key=lambda r:(r["batch"],r["index"],r["line"]))
        assert Counter(r["batch"] for r in records)=={0:16,1:16}
        for i,r in enumerate(records):
            trace_rows.append(dict(qid=ordinal,problem_key=key,slot=i,**r))
        questions.append(dict(qid=ordinal,problem_key=key,records=len(records),
                              abstentions=sum(r["final"] is None for r in records),
                              capped=sum(r["cap"] for r in records),
                              generated_tokens=sum(r["length"] for r in records)))
        indices=list(range(32))
        random.Random(137+ordinal).shuffle(indices)
        for width in [8,16]:
            for i in range(0,len(indices),width):
                ids=indices[i:i+width]
                panel=[dict(index=j,length=records[j]["length"],final=records[j]["final"]) for j in ids]
                for cap in [4,width]:
                    schedule_rows.extend(validate.scheduling(panel,ordinal,width,i//width,cap))
    validate.save(out/"traces.csv",trace_rows)
    validate.save(out/"questions.csv",questions)
    validate.save(out/"schedule_panels.csv",schedule_rows)
    validate.summarize_schedule(out,schedule_rows)
    grouped=defaultdict(dict)
    for r in schedule_rows:
        grouped[(r["qid"],r["n"],r["panel"],r["capacity"])][r["policy"]]=r
    mismatches=sum(r["disagreements"] for r in schedule_rows)
    equal=sum(g["refill"]["tokens"]==g["rolling"]["tokens"]==g["serial"]["tokens"] for g in grouped.values())
    dominates=sum(g["refill"]["steps"] <= g["rolling"]["steps"] for g in grouped.values())
    log=dict(start_utc=started,end_utc=datetime.now(timezone.utc).isoformat(),source=REPO,
             revision=REV,sources=sources,freeze=frozen["inputs"],questions=len(questions),trajectories=len(trace_rows),
             answer_abstentions=sum(q["abstentions"] for q in questions),cap_hits=sum(q["capped"] for q in questions),
             input_tokens_generated=sum(q["generated_tokens"] for q in questions),policy_endpoint_disagreements=mismatches,
             panel_capacity_comparisons=len(grouped),equal_work_cases=equal,time_dominance_cases=dominates)
    (out/"manifest.json").write_text(json.dumps(log,indent=2)+"\n",encoding="utf8")
    assert mismatches==0 and equal==dominates==len(grouped)
    print(json.dumps({k:v for k,v in log.items() if k not in ["sources","freeze"]}))


if __name__=="__main__":
    main(Path(sys.argv[1]))
