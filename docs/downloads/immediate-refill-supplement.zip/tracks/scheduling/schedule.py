"""Exact event replay for fixed per-path decode lengths and shared step prices."""
from collections import Counter


def margin(votes):
    top = votes.most_common(2)
    return top[0][1] - (top[1][1] if len(top) == 2 else 0) if top else 0


def needed(remaining, gap):
    """Earliest number of additional completions at which a decision is possible."""
    return min(remaining, max(0, (remaining - gap) // 2 + 1))


def simulate(lengths, answers, mode, capacity):
    """A policy sees only completed votes and number of free execution slots."""
    n = len(lengths)
    if mode not in {"refill", "barrier", "fixed", "rolling"} or capacity < 1 or n < 1:
        raise ValueError("Unsupported policy or batch size")
    if len(answers) != n or any(t <= 0 for t in lengths):
        raise ValueError("Each path needs a positive length and an answer (possibly None)")
    votes = Counter()
    active = {}
    launched = completed = steps = tokens = launches = 0
    committed = 0
    while True:
        remaining = n - completed
        gap = margin(votes)
        if not remaining or gap > remaining:
            break
        width = capacity if mode == "fixed" else min(capacity, needed(remaining, gap))
        if mode == "rolling":
            if completed == committed:
                committed = completed + needed(remaining, gap)
            width = min(capacity, committed - completed)
        if mode != "barrier" or not active:
            batch = min(n - launched, width - len(active))
            if batch > 0:
                launches += 1
                for i in range(launched, launched + batch):
                    active[i] = lengths[i]
                launched += batch
        delta = min(active.values())
        steps += delta
        tokens += delta * len(active)
        finished = []
        for i in active:
            active[i] -= delta
            if active[i] == 0:
                finished.append(i)
        for i in finished:
            del active[i]
            if answers[i] is not None:
                votes[answers[i]] += 1
            completed += 1
    winner = min(votes, key=lambda x: (-votes[x], x)) if votes else None
    return dict(winner=winner, launched=launched, completed=completed, tokens=tokens,
                steps=steps, launches=launches, canceled=len(active))
