"""Draw the three-path example from the paper using virtual work units."""

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle


# Let pdfLaTeX embed Type 1 fonts for both tick labels and math.
plt.rcParams.update({
    "pgf.texsystem": "pdflatex", "pgf.rcfonts": False,
    "pgf.preamble": r"\usepackage[T1]{fontenc}\usepackage{helvet,amssymb}",
    "font.family": "sans-serif",
})


WORK = (2, 1, 1)
COST = (0, 10, 11, 13)
POLICIES = (("Immediate refill", (0, 0, 0)), ("Delay path 3", (0, 0, 1)))


def main():
    plt.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.size": 7.5,
            "text.color": "#222222",
        }
    )
    # Draw in printer's points so dimensions and font sizes match the final PDF.
    width, height = 234, 96
    fig = plt.figure(figsize=(width / 72, height / 72))
    ax = fig.add_axes([0, 0, 1, 1], xlim=(0, width), ylim=(0, height))
    ax.set_axis_off()
    row_y = (68, 55, 42)
    band_height, step_width = 6.4, 21.8
    for index, y in enumerate(row_y):
        ax.text(1, y, f"Path {index + 1}", va="center")
    ax.text(1, 24, "Virtual time", va="center")
    ax.text(1, 7, "Wall time", va="center", weight="bold")

    for (name, starts), left in zip(POLICIES, (68, 166)):
        center = left + step_width
        ax.text(center, 86, name, va="center", ha="center", weight="bold", fontsize=8.2)
        for t in range(3):
            x = left + t * step_width
            ax.plot([x, x], [34, 74], lw=0.55, color="#bbbbbb", zorder=1)
            ax.text(x, 24, str(t), ha="center", va="center")
        for i, (start, work, y) in enumerate(zip(starts, WORK, row_y)):
            ax.add_patch(
                Rectangle(
                    (left + start * step_width, y - band_height / 2),
                    work * step_width,
                    band_height,
                    facecolor="#374a56" if i < 2 else "#eeeeee",
                    edgecolor="#374a56",
                    linewidth=0.8,
                    zorder=2,
                )
            )
        step_costs = [
            COST[sum(start <= t < start + work for start, work in zip(starts, WORK))]
            for t in range(2)
        ]
        equation = f"{step_costs[0]} + {step_costs[1]} = {sum(step_costs)}"
        ax.text(center, 7, equation, va="center", ha="center", fontsize=8.0)
    ax.plot([1, width - 1], [16, 16], lw=0.55, color="#bbbbbb")
    fig.savefig(
        Path(__file__).resolve().with_name("refill-timeline.pdf"),
        backend="pgf", metadata={
            "Title": "Effect of delaying the third path on virtual and wall time",
            "CreationDate": None,
            "ModDate": None,
        },
    )
    plt.close(fig)


if __name__ == "__main__":
    main()
