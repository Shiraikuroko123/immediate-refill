"""Exhaust every schedule in two small, predetermined finite families."""
import collections
import hashlib
import itertools
import json
from pathlib import Path
import platform
import sys
import time


def gap(counts):
    highest = sorted(counts.values(), reverse=True) + [0, 0]
    return highest[0] - highest[1]


def limit(remaining, lead, slots):
    return min(slots, remaining, max(0, (remaining - lead)//2 + 1))


def vote(counts, answer):
    if answer is not None:
        counts[answer] += 1


def reference(answers):
    counts = collections.Counter()
    for i, answer in enumerate(answers, 1):
        vote(counts, answer)
        if gap(counts) > len(answers)-i:
            return i
    return len(answers)


def simulate(answers, durations, slots, barrier):
    n = len(answers)
    counts = collections.Counter()
    launched = completed = tick = 0
    running = {}
    while completed < n:
        lead = gap(counts)
        if lead > n-completed:
            break
        capacity = limit(n-completed, lead, slots)
        assert len(running) <= capacity
        while len(running) < capacity:
            running[launched] = tick + durations[launched]
            launched += 1
        tick = max(running.values()) if barrier else min(running.values())
        finished = [index for index, finish in running.items() if finish <= tick]
        for index in finished:
            del running[index]
            vote(counts, answers[index])
        completed += len(finished)
    assert not running
    return launched, tick


def verify(n, labels, duration_set, cap_set):
    total = strict = 0
    example = None
    for answers in itertools.product(labels, repeat=n):
        prefix = reference(answers)
        for durations in itertools.product(duration_set, repeat=n):
            for cap in cap_set:
                asynchronous, async_time = simulate(answers,durations,cap,False)
                waves, waves_time = simulate(answers,durations,cap,True)
                if (prefix != asynchronous or prefix != waves or async_time > waves_time):
                    raise AssertionError((answers,durations,cap,prefix,asynchronous,async_time,waves,waves_time))
                total += 1
                if async_time < waves_time:
                    strict += 1
                    if example is None:
                        example = dict(answers=answers,durations=durations,cap=cap,prefix=prefix,
                                       asynchronous_time=async_time,barrier_time=waves_time)
    return dict(n=n,labels=labels,durations=duration_set,caps=list(cap_set),tested=total,
                strict_latency_improvements=strict,first_strict_example=example)


if __name__ == "__main__":
    out = Path(sys.argv[1])
    out.mkdir(parents=True,exist_ok=False)
    start=time.perf_counter()
    rows=[]
    for n in range(1,6):
        rows.append(verify(n,["A","B","C",None],[1,2],range(1,n+1)))
        print(n, rows[-1]["tested"],flush=True)
    rows.append(verify(6,["A","B"],[1,2,3],[1,2,3,6]))
    result={"sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),"python":sys.version,
            "platform":platform.platform(),"elapsed_seconds":time.perf_counter()-start,
            "cases":sum(r["tested"] for r in rows), "failures":0, "families":rows}
    (out/"summary.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
    print(f"Verified {result['cases']} schedules in {result['elapsed_seconds']:.1f} s.")
