# When Is Immediate Refill Optimal for Parallel Voting?

## Abstract

Launching another reasoning path in parallel voting can change the cost of the next decoding step for every active path. We study when to refill a free slot under a per-problem launch limit relative to serial voting, counting even paths canceled after launch. With no extra launches, immediate refill minimizes latency on every input for a fixed panel size, slot capacity, and launch quota if and only if step costs are discretely concave over the reachable widths. In this zero-extra-budget regime, fixing only slot capacity and step costs gives an exact worst-case latency ratio determined by the least concave majorant of the cost curve. On one NVIDIA A800 with three prescribed request lengths, delaying the third launch reduced latency by a median of 2.46% across 12 paired blocks, against a prediction of 3.13%. On the first three paths of 200 archived GSM8K problems, a length-informed oracle saved 0.364% on average by choosing whether to launch the third path immediately or at the first completion.

---

## 1 Introduction

In parallel self-consistency voting (Parallel Voting), a language model generates multiple candidate reasoning paths for the same prompt. Once the votes returned so far make it impossible for the remaining unreturned votes to alter the leading label, generation can terminate early. Whenever a shorter path finishes and frees a concurrency slot, a scheduler can immediately refill that slot with the next candidate path rather than waiting for earlier, longer paths to complete (Jiang et al., 2025; Xiong et al., 2026). However, admitting a new path changes the active concurrency width of the batch, which can alter the wall-clock cost of the next decoding step for every running path. Consequently, whether immediate refill is fastest when a free slot is available depends on how the per-step decoding cost scales with concurrency width.

Consider four candidate paths, three slots, a quota of three launches, and no extra launches over serial voting (Figure 1). If the first three votes agree, all three must finish to certify the winner. Let their lengths be $(2,1,1)$ and the step costs at widths 1, 2, and 3 be 10, 11, and 13. Launching all three together costs $13+10=23$. After one step, the long path runs alone. Delaying the third launch until the first short path finishes keeps two paths active on both steps and costs $11+11=22$. Both schedules do four units of work in two virtual steps. Their wall-clock times differ because they visit different widths.

> **Figure 1**: With four candidates, three slots, and a launch quota of three, the first three paths have lengths $(2,1,1)$ and agree. Delaying the third launch lowers latency from 23 to 22 at step costs $(10,11,13)$.

> **Figure 2**: Immediate-refill workflow under index-based admission. The scheduler adds simultaneously completing path indices to the completed set $S$ and tracks cumulative launches $J$. Based on observed votes, it computes the earliest possible serial stopping index $M(S)$ to bound safe lookahead launches.

Because voting supports early stopping, the scheduler must also respect a launch budget at every refill decision. Every launched request consumes budget from the moment it starts, even if it is later canceled upon early termination. We use serial voting as the per-problem reference baseline: for example, if serial voting certifies a winner on the ninth vote, an extra launch budget of $B = 1$ permits at most ten requests for that problem. Although the scheduler does not observe future votes at launch time, it must guarantee no budget overrun under any realization of unreturned votes consistent with current observations. In addition, a service may impose a hard per-problem launch quota $Q$.

When no extra launches are permitted ($B = 0$), every valid schedule completes the exact same path prefix on any given input. In any prefix of virtual decoding time, immediate refill does at least as much work as any competing schedule does over intervals of the same total virtual duration, even if those intervals are disjoint and chosen in hindsight. This majorization property yields both a necessary and sufficient condition for immediate refill to be universally optimal and an exact worst-case latency ratio across configurations. When extra launches are allowed ($B \ge 1$), different schedules may complete different sets of paths; we derive a general wall-clock lower bound from the work required to certify a winner and use it to disentangle two distinct sources of savings: admitting paths earlier using out-of-order vote returns, and deliberately delaying an already-admitted launch to optimize concurrency width.

---

## 2 Problem Formulation and Admission Control

### 2.1 Candidate Panels and Winner Certification

For each input problem, we are given a predetermined sequence of candidate paths (hereafter a **panel**), indexed in launch order by $i = 1, \dots, N$ ($N \ge 1$). Path $i$ has positive workload $w_i > 0$ and upon completion returns an answer label $v_i$ or an abstention. Let $S \subseteq \{1, \dots, N\}$ denote the set of completed path indices, and let $\text{gap}(S)$ denote the vote margin between the first- and second-place labels among completed non-abstaining paths (unseen labels have zero votes). Abstentions count toward $|S|$. The margin is zero if no label has received a vote. A winner is **strictly certified** whenever

$$
\text{gap}(S) > N - \vert{}S\vert{}.
$$

Under this condition, the leading label is guaranteed to win even if every remaining unknown vote favors the runner-up, and the service returns immediately. Let $1 \le Q \le N$ be an integer absolute launch quota. If all $Q$ paths complete without strictly certifying a winner, the service returns the plurality label with a shared deterministic tie-break, or $\bot$ if all votes abstain. If $Q < N$ and the observed votes do not suffice to determine the full-panel winner, the output is flagged as **uncertified**. In our evaluation, we separately measure agreement with the full-panel plurality outcome and accuracy against ground-truth answers.

### 2.2 Budget Constraints and Safe Admission Bounds

Let $K(v)$ denote the prefix length at which serial voting first strictly certifies a winner (or $N$ if it exhausts all paths). Given $P \ge 1$ concurrency slots and an integer extra launch budget $B \ge 0$, cumulative launches $J$ (including subsequently canceled requests) must satisfy

$$
J \le K(v) + B
$$

for every realization of unknown votes consistent with the votes observed so far. The model assumes that elapsed service time alone rules out no vote outcome; paths are launched in index order and occupy one slot until completion or service termination.

While voting is ongoing, consider any serial prefix of length $t \in \{1, \dots, N\}$. Let $S_t = S \cap \{1, \dots, t\}$ be the completed indices within this prefix and $u_t = t - \vert{}S_t\vert{}$ be the number of unknown votes in the prefix. Under current observations, the maximum achievable vote margin on this prefix is $g_t = \text{gap}(S_t) + u_t$. We define the earliest possible serial stopping index $M(S)$ and the safe cumulative launch bound $F(S)$ as

$$
M(S) = \min\left(\{t < N : g_t > N - t\} \cup \{N\}\right), \tag{1}
$$

$$
F(S) = \min\{Q,\; \vert{}S\vert{} + P,\; M(S) + B\}. \tag{2}
$$

Assigning all $u_t$ missing votes in the prefix to a current plurality label achieves the maximum margin $g_t$. Hence, $M(S)$ is the earliest stopping position of serial voting across all vote completions consistent with $S$; launching beyond $M(S) + B$ would violate the budget under at least one consistent completion. Combining this limit with the absolute quota $Q$ and slot capacity $P$ yields the exact safe launch bound $F(S)$. Online admission computes $F(S)$ by scanning prefixes in index order while tracking the top two vote counts; as new votes arrive, the set of consistent completions shrinks and $F(S)$ is monotonically non-decreasing.

The greedy **index-based admission** policy $G$ refills immediately up to $F(S)$ (Figure 2). By contrast, **buffered admission** computes $M$ using only the longest contiguously completed prefix starting at index 1, although both policies release slots based on total completions, terminate using all returned votes, and charge every launch to the budget. For example, let $N = Q = 5$, $P = 3$, and $B = 1$. Suppose paths 2 and 3 have returned $A$ and $B$, respectively, while paths 1 and 4 remain running. Because two of the first three votes already disagree, the leader can lead by at most 1 vote and cannot certify a winner with two votes remaining. Index-based admission thus infers $M = 4$ and launches path 5, whereas buffered admission cannot see beyond the contiguous prefix, cannot rule out all three initial votes being $A$, and stops at $M = 3$, leaving a slot idle.

| Symbol | Meaning |
| :--- | :--- |
| $N, Q, P$ | Total panel paths, absolute launch quota, and maximum concurrency slots |
| $S, J$ | Set of completed path indices and cumulative launches to date |
| $K, B$ | Serial voting stopping index and allowed extra launches over serial |
| $M(S), F(S)$ | Earliest possible serial stopping index and current safe launch bound |
| $V, T, c_k$ | Virtual time, wall-clock time, and per-step cost at concurrency width $k$ |
| $G, \hat{c}$ | Greedy index-based immediate-refill policy and least concave majorant of $c$ |

---

## 3 When Does Immediate Refill Minimize Wall-Clock Time?

Let $1 \le k \le P$ be the number of concurrently active paths (concurrency width). Under the **shared decoding clock** model, each active path advances at rate $1/c_k$, where $c_k > 0$ is the per-step wall-clock cost at width $k$, and let $c_{\min} = \min_{1 \le k \le P} c_k$. Unless stated otherwise, sums over $k$ range over $1 \le k \le P$. In one unit of virtual time (one decoding step), every active path completes one unit of work, taking $c_k$ units of wall-clock time. Let $V_A$ and $T_A$ denote the virtual time and wall-clock time elapsed from start to return under policy $A$. If $A$ runs at width $k$ for virtual duration $d_k$, then $V_A = \sum_k d_k$, total work is $\sum_k k d_k$, and $T_A = \sum_k c_k d_k$. Idle intervals with zero active paths can be excised without loss of generality. All policies share identical path workloads, votes, and admission rules.

At the virtual time when any valid competing policy $A$ launches path $i$, the greedy policy $G$ has either already launched path $i$ or already returned. For the case where $G$ is still active, induction on launch order shows that any earlier path $j$ completes $w_j$ virtual time units after launch; by the induction hypothesis, every vote seen by $A$ prior to launching $i$ has already been seen by $G$, so $G$ is permitted to launch at least up to index $i$. Similarly, when $A$ returns, if $G$ is still active, $G$ has already observed the votes needed to certify a winner or exhausted $Q$. Consequently, $V_G \le V_A$ and $T_A \ge V_G c_{\min}$. Below, we first compare slot-occupancy profiles under zero extra budget ($B = 0$) and then derive certificate-work lower bounds when $B \ge 1$.

### 3.1 Optimality of Immediate Refill Under Zero Extra Budget

When $B = 0$, all valid schedules complete the exact same prefix of length $\min(K, Q)$ and perform the same total work $W^*$ (Appendix A). Let $h_A(t)$ be the number of active paths under policy $A$ at virtual time $t$ (zero after return). Under $G$, $h_G(t)$ is non-increasing in $t$. Moreover, for any union $E$ of disjoint intervals in a competing schedule's execution, $G$ performs at least as much work in its first $|E|$ virtual time units as the competing schedule performs during $E$.

**Theorem 1 (Immediate Refill Under Arbitrary Slot Capacity)**  
Fix slot capacity $P \ge 1$ and step costs $c_1, \dots, c_P > 0$, with $c_0 = 0$. Let $\mathcal{I}$ be the class of all zero-extra-budget ($B = 0$) instances with arbitrary panel size $N \ge 1$, quota $1 \le Q \le N$, positive path workloads, and unit-weight votes. Then greedy immediate refill $G$ minimizes wall-clock time on every $I \in \mathcal{I}$ if and only if the step-cost curve satisfies **discrete concavity**:

$$
2c_j \ge c_{j-1} + c_{j+1}, \qquad 1 \le j < P.
$$

Let $\hat{c}$ be the least concave majorant of $c$ on $\{0, \dots, P\}$ (the pointwise smallest concave function dominating $c$), and let $T_{\text{opt}}(I)$ denote the infimum wall-clock time over all valid schedules on $I$. Then

$$
\sup_{I \in \mathcal{I}} \frac{T_G(I)}{T_{\text{opt}}(I)} = \max_{1 \le k \le P} \frac{\hat{c}_k}{c_k}.
$$

Furthermore, for any valid schedule $A$ and any measurable subset $E$ of its virtual timeline,

$$
\int_E h_A(t)\,dt \le \int_0^{|E|} h_G(t)\,dt. \tag{3}
$$

> **Figure 3**: Worst-case latency ratio under $B = 0$ for step costs $(1, 1, 6)$. At concurrency width 2, the cost is 1 while its least concave majorant is 4. Fixing $P = 3$ and allowing panel size and quota to vary yields a supremum ratio of 4; further fixing $N = 4$ and $Q = P = 3$ reduces the exact worst-case ratio to $7/2$.

**Occupancy Concentration.**  
Although the cumulative launch bound $F(S)$ never decreases as votes arrive, the maximum number of simultaneously active paths under $B = 0$ obeys a non-increasing upper bound. With $R = N - |S|$ unknown votes remaining and current lead $g$, even if every subsequent vote favors the leader, at least $\lfloor(R - g)/2\rfloor + 1$ additional votes are required to certify a winner (or all remaining votes must be exhausted). Taking the minimum of this quantity with $R$, $P$, and $Q - |S|$ gives the maximum safe concurrency width. Each returned vote decreases $R$ by 1 and changes $g$ by at most 1, so this width bound never increases (Appendix B).

Given any union of intervals $E$ on $A$'s virtual timeline, preserve durations inside $E$ and scale durations in the active complement $E^c$ by $\varepsilon \in (0, 1)$. Applying this time-compression map to all launch and completion times and setting shortened workloads accordingly preserves event ordering and simultaneous completions, so replaying $A$'s launches remains valid on the compressed input. On the compressed input, $G$ finishes the same prefix no later than the replay ends; by induction on launch order, at every virtual time the compressed $G$ has seen every vote seen by the original $G$ and therefore runs with no more active paths. Thus, by virtual time $|E| + \varepsilon|E^c|$, the original $G$ performs at least as much work as the compressed execution, which is at least the work $A$ performs on $E$. Letting $\varepsilon \to 0^+$ yields Eq. (3).

**Discrete Concavity and Cost Decomposition.**  
For each width threshold $1 \le j < P$, define the excess occupancy integral $U_A(j) = \int_0^{V_A} (h_A(t) - j)_+\,dt$, where $(x)_+ = \max\{x, 0\}$. Setting $E = \{t : h_A(t) > j\}$ in Eq. (3) and subtracting $j|E|$ from both sides gives $U_A(j) \le U_G(j)$. Letting $\theta_j = 2c_j - c_{j-1} - c_{j+1}$, wall-clock latency decomposes as

$$
T_A = c_1 W^* - \sum_{j=1}^{P-1} \theta_j U_A(j).
$$

Because $W^*$ is invariant across all valid schedules and $G$ maximizes $U_A(j)$ at every threshold $j$, discrete concavity ($\theta_j \ge 0$ for all $j$) implies $T_G \le T_A$. This conclusion relies critically on occupancy majorization rather than per-task completion dominance: as shown in a four-task precedence-constrained counterexample in Appendix J, even when $G$ completes every task no later than a competing schedule in virtual time, $G$ can still take wall-clock time 4 against 3.75 under a concave cost curve.

**Fixed Panel Size and Quota.**  
Fixing $N$ and $Q$ as well restricts reachable widths to at most $b = \min(P, Q, \lfloor N/2 \rfloor + 1)$. Thus concavity is needed only on $\{0,\dots,b\}$. If $c_{j+1}+c_{j-1}>2c_j$ for some $1\le j<b$, take unanimous votes, workloads 2 on the first $j-1$ paths, 1 on the next two, and $\varepsilon>0$ on the rest. As $\varepsilon$ tends to zero, the greedy cost tends to $c_{j+1}+c_{j-1}$ and the cost of a feasible schedule that starts at width $j$ tends to $2c_j$. The strict difference persists for sufficiently small $\varepsilon$ (Appendix B.2). Figure 1 attains $23/22$ at $N=4$, $Q=P=3$. At $N=Q=P=3$ only positive widths 1 and 2 are reachable, and greedy is optimal for these same costs.

**Non-Concave Step Costs.**  
Figure 3 illustrates how $\gamma = \max_{1 \le k \le P} \hat{c}_k / c_k$ is read off the cost curve. Fix any valid schedule $A$ under cost $c$ with width durations $d_k$. Keeping its virtual launch times fixed preserves the votes visible at each launch, so re-pricing the same virtual trajectory under $\hat{c}$ remains valid, and $G$ follows the exact same virtual trajectory under both cost curves. Applying optimality under $\hat{c}$ to this replay yields

$$
T_G(c) \le T_G(\hat{c}) \le \sum_{k=1}^P \hat{c}_k d_k \le \gamma \sum_{k=1}^P c_k d_k = \gamma T_A(c).
$$

When $\gamma > 1$, this ratio can be approached arbitrarily closely by taking a chord of $\hat{c}$ spanning a maximizer $j$, using a vanishingly short unanimous prefix to lock the allowed width to the chord's right endpoint, and configuring subsequent opposing votes and path lengths in proportion to the chord endpoints (Appendix B.1).

### 3.2 Wall-Clock Lower Bounds via Terminal Completion Sets

When $B \ge 1$, different schedules need not complete the same set of paths. However, given any terminal completion set $S \subseteq \{1, \dots, Q\}$ at return time, the work already delivered to each path $1 \le i \le Q$ is at least

$$
a_i(S) = \min\left\{w_i,\; \max_{j \in S,\, j \ge i} w_j\right\}, \tag{4}
$$

with the empty maximum taken as 0. Indeed, completing path $j \in S$ requires $w_j$ work after $j$ launches, and every earlier path $i \le j$ launches no later than $j$, so by the time $j$ completes, path $i$ has either finished (receiving $w_i$) or received at least $w_j$ units of work. For example, if certifying a winner requires waiting for a fourth path of length 100, each of the first three paths must have accrued at least $\min\{w_i, 100\}$ work—explaining why summing only completed path lengths underestimates actual work performed.

Sort $(a_1(S), \dots, a_Q(S))$ in non-increasing order, let $W_m(S)$ be the sum of the top $m$ entries (zero-padded if $m > Q$), and let $W(S) = \sum_{i=1}^Q a_i(S)$. To lower-bound individual completion times as well, extend $G$ past its first certification on the same virtual clock by keeping active paths running and refilling any free slot until $Q$ launches occur, and let $e_i$ be the completion time of path $i$ in this extended run. No valid schedule can complete path $i$ earlier than $e_i$.

**Theorem 2 (Certificate-Work Lower Bound)**  
For each candidate terminal completion set $S$, minimize $\sum_{k=1}^P c_k d_k$ over $d_k \ge 0$ ($1 \le k \le P$) subject to:

$$
\begin{aligned}
\sum_{k=1}^P d_k &\ge \max\left\{V_G,\; \max_{i \in S} e_i\right\}, \\
\sum_{k=1}^P \min(k, m)\, d_k &\ge W_m(S), \qquad 1 \le m < P, \\
\sum_{k=1}^P k\, d_k &\ge W(S).
\end{aligned} \tag{5}
$$

If a family of candidate sets covers all realizable terminal completion sets, the minimum optimal LP value across that family is a valid wall-clock lower bound for any admissible policy at return time—even an omniscient adversary that knows all workloads and votes in advance, provided every launch satisfies the admission rule given information available at that moment.

**Proof**  
Prior to $G$'s first certification, the extended run coincides with $G$, so it launches every path launched by the adversary. Thereafter, the extended run is constrained only by $P$ and $Q$: whenever the adversary launches a path, the extended run has already observed all completions used for that admission and can launch at least to the same index, so the adversary cannot finish path $i$ before $e_i$. Furthermore, at width $k$, any $m$ paths accrue at most $\min(k, m)$ work per virtual step while all active paths accrue $k$ work. Applying Eq. (4) to the adversary's realized completion set $S$ shows that its realized width durations form a feasible solution to Eq. (5). Taking the minimum over all realizable terminal sets therefore yields a valid lower bound. $\square$

If $L$ denotes the resulting lower bound, no policy can save more than $1 - L/T_G$ relative to $G$. This bound can be loose when the LP combines width durations unrealizable by a single schedule. For $Q = 14$, we enumerate candidate terminal bitmasks, prune those violating index-order launches, and discard componentwise-dominated demand vectors (Appendix C); across 124 previously studied panels, at most four non-dominated vectors remain per panel.

**Cost of Delaying Refill.**  
Under $B \ge 1$, waiting can induce an unbounded latency ratio if a short decisive path is held back until a long running path finishes. If total delayed-refill virtual time is capped at $H$, the extra virtual latency relative to immediate refill is at most $H$ (proof and tight example in Appendix D).

---

## 4 Empirical Evaluation and Cost Calibration

We first test whether a measured step-cost curve predicts the effect of delaying a launch on one GPU. We then use archived workloads to estimate how much timing matters and how much can be gained by acting on votes that have already returned.

**Single-GPU Validation.**  
Consider three requests of fixed lengths $(256, 128, 128)$ that must all complete. Under the shared decoding clock, launching all three simultaneously takes $128(c_3 + c_1)$, whereas waiting for the second request to finish before launching the third maintains width 2 throughout and takes $256c_2$. Calibrating `Qwen2.5-1.5B-Instruct` on a single NVIDIA A800 yields step costs of $4.711\text{ ms}$, $4.611\text{ ms}$, and $4.810\text{ ms}$ at widths 1, 2, and 3, predicting a 3.13% speedup from delaying the third request. We logged this prediction prior to launching a fresh engine process for validation.

Across 12 paired blocks in one device session, delaying the third request reduced end-to-end latency by a median of 2.46% (in-session interval 2.38–2.61%). On the two-request control $(128,128)$, delaying the second request forces serial execution. The predicted slowdown was 104.30% and the measured median slowdown was 102.63%. Both intervals lay on the predicted side of zero, and each median was within two percentage points of its prediction, satisfying both prespecified criteria (Figure 4 and Appendix K).

> **Figure 4**: Paired wall-clock savings from delaying the final request on an A800 for three requests $(256, 128, 128)$ (left) and two equal-length control requests $(128, 128)$ (right). Points show 12 paired blocks from one A800 session, dashed lines show pre-logged predictions, and shaded bands span the 3rd to 10th order statistics (note different y-axis scales).

**Prevalence on Archived Trajectories.**  
On the first three paths of 200 archived GSM8K problems (Cobbe et al., 2021), we used `Qwen3-4B-Base` lengths (Wang et al., 2026) and the calibrated `Qwen2.5` clock. The first two requests start together and all three must finish. The third starts immediately or when either active request first finishes. Always delaying raised mean latency by 26.73%. A length-informed oracle chose delay on 66 problems and saved 0.364% on average relative to immediate launch (Appendix K).

### 4.1 Step-Cost Calibration Across Context Lengths

We profiled `DeepSeek-R1-Distill-Qwen-1.5B` in BF16 using `vLLM 0.8.5` on an `A800-SXM4-80GB` across three prompt lengths (512, 2,048, and 3,968 tokens) and concurrency widths $1 \le k \le 4$. After warmup, we ran eight randomized blocks; each window performed prefill plus 8 untimed decode steps followed by 96 device-synchronized cached decode steps (one token per active path per step, paired seeds for the first request, prefix caching disabled).

**Table 1**: Median per-step decoding latency (ms) across eight timing windows by prompt length and concurrency width. Each panel replay uses a single row of costs.

| Prompt Length (tokens) | $c_1$ | $c_2$ | $c_3$ | $c_4$ |
| :--- | :---: | :---: | :---: | :---: |
| 512 | 5.283 | 5.286 | 5.479 | 5.585 |
| 2,048 | 5.297 | 5.399 | 5.545 | 5.676 |
| 3,968 | 5.321 | 5.463 | 5.717 | 5.862 |

All three median cost curves in Table 1 violate discrete concavity at $j = 2$ (as does every individual block). Using the least concave majorant under $B = 0$, the maximum possible savings over immediate refill are 1.823%, 0.452%, and 1.015% at 512, 2,048, and 3,968 tokens, respectively; replaying the $j = 2$ construction achieves simulated savings of 1.776%, 0.408%, and 1.015% (excluding prefill and queuing).

### 4.2 Upper Bounds on Launch-Timing Optimization

We next examine $N = 16, P = 4, Q = 14, B = 1$. Paths run to their archived lengths and return recorded votes, stopping upon certification or quota exhaustion. For each problem $q$, we compute per-problem savings $1 - T_{\text{candidate},q}/T_{\text{reference},q}$ (positive indicates speedup) and report unweighted averages across problems.

We evaluate three benchmarks: AIME 2025 (30 problems split into two disjoint 16-path panels each, 60 panels total, retrospective) and AMC 2023 (40 panels from the second sampling batch), both from unguided `Qwen3-4B-Base` rollouts; plus 24 integer-answer English problems from OlympiadBench (He et al., 2024) with reference panels generated by `DeepSeek-R1-Distill-Qwen-1.5B`.

**Table 2**: Average latency-savings upper bounds (%) relative to index-based immediate refill under the 3,968-token fixed clock. "Completed Work" sums only completed path lengths; "Full Bound" applies Theorem 2.

| Dataset | Panels | $V_G c_{\min}$ Bound | Completed Work Bound | Full Bound (Thm. 2) |
| :--- | :---: | :---: | :---: | :---: |
| AIME25 | 60 | 5.571 | 0.287 | 0.216 |
| AMC23 | 40 | 5.578 | 0.910 | 0.424 |
| OlympiadBench | 24 | 7.903 | 0.549 | 0.215 |

While the naive $V_G c_{\min}$ bound leaves 5–8% apparent headroom under the 3,968-token clock, accounting for certificate work, accrued work on earlier paths, and earliest completion times via Theorem 2 drives all full bounds below 0.5% (Table 2). All full bounds remain below 1% under shorter-context clocks, and even when step costs vary arbitrarily within the calibrated block range during a run, the maximum bound across all three benchmarks and GSM8K is 1.034% (Appendix F).

### 4.3 Attributing Gains from Out-of-Order Vote Returns

We now hold the refill rule fixed. Both policies launch as soon as their information permits, so their difference measures the value of returned votes outside the contiguous prefix. Before inspecting the GSM8K trajectories, we fixed the parser, primary policies, and hash-based selection of 8 of 53 shards (200 problems, 16 paths per problem, $B=1$). Truncated or unparseable outputs count as abstentions (Appendix H).

Under the 3,968-token clock, index-based admission changed 138 of 200 launch schedules relative to buffered admission (109 faster, 28 slower, one tied). Simulated savings averaged 8.71% per problem (95% bootstrap CI $[6.61\%,11.02\%]$). The median was 0.14%, savings in summed latency were 18.72% (two long problems account for 67.04% of the net saving, Appendix H), and per-problem percentage savings in generated work averaged 1.58%.

> **Figure 5**: Decomposition of simulated savings on 200 GSM8K problems under the 3,968-token clock into gains from counting out-of-prefix returned votes and gains from tracking their exact indices (both normalized by buffered admission latency; 95% CI covers the total).

**Attribution and Waiting Heuristics.**  
Relative to buffered latency, using the out-of-prefix vote counts accounted for 8.41 percentage points of the 8.71% saving, and resolving their individual positions added 0.30 points (Figure 5). The latter step changed 22 of 200 archived schedules and none in retrospective replays of 32 device-generated panels at each of two caps. Measured against each comparator's own simulated latency, full indexing saved 0.67% over the unordered-vote rule and 0.30% over the prefix-plus-multiset rule. Both comparators were added post hoc (Appendix Table 5).

We next hold information fixed and vary the launch time. Let $g$ be the vote lead, $R$ the remaining votes, and $a$ the active paths. When $a>0$ and $g+2a>R$, aligned active votes can certify a winner. Repeatedly delaying the last eligible launch under this condition slowed 126 problems and sped up 39, raising latency by 73.24% on average. Two single-wait heuristics capped at eight steps also missed the prespecified 1% mean saving. With full trajectory knowledge, an oracle could choose one noninitial refill per panel and delay its last eligible launch until the next completion. It improved 168 panels. Its mean saving and Theorem 2 bound the mean of the per-panel optimal savings with full trajectory knowledge at $[0.1145\%,0.7382\%]$ (Appendix Figure 6).

### 4.4 End-to-End Device Comparisons

We evaluated both admission policies on an A800. Fixing reference workloads on 24 OlympiadBench problems produced identical launch and cancellation sequences (1,114,134 tokens each, 0.14% wall-clock difference). Under natural sampling with paired seeds, index-based admission averaged 0.12% savings (95% CI $[-0.06\%, 0.32\%]$); under fixed votes, 9 problems certified within 14 launches, all 24 outputs agreed with the full-panel outcome, including 12 cases where both returned $\bot$. Accuracy against ground truth was 11/24.

We selected 16 GSM8K problems by hash, two shared with the 200-problem archive (`gsm8k_497` and `gsm8k_695`). We ran balanced pairs under fixed workloads and natural sampling with `Qwen2.5-1.5B-Instruct` (BF16, temperature 0.7, top-p 0.95, 384-token cap). Our prespecified criteria required at least 2% mean fixed-workload savings, a positive 20,000-resample bootstrap lower bound, and at least one changed schedule.

**Table 3**: Index-based vs. buffered admission on 16 GSM8K problems on an A800. "Changed" denotes problems with differing launch steps; CIs are resampled by problem within the same session.

| Condition | Changed | Mean Savings (%) | 95% CI | Correct |
| :--- | :---: | :---: | :---: | :---: |
| Fixed Workload | 4 | 0.55 | $[-0.03,\; 1.29]$ | 10/16 |
| Natural Sampling | 5 | 0.48 | $[-0.04,\; 1.30]$ | 9/16 |

Fixed-workload savings averaged 0.55%, below the 2% threshold (Table 3). Index-based and buffered admission used 15,560 and 15,670 steps and generated 55,429 and 55,490 tokens, respectively. Under natural sampling the policies agreed on all answers, with 176 extra tokens for index-based admission (289,877 tokens across all 80 runs). Replay of the device traces predicted 0.60% savings and identified all four fixed-workload dispatch changes. The gap from the 8.71% archive estimate spans different models, samples, and length distributions. One timed pair per problem and condition in one session leaves cross-session variance unmeasured.

### 4.5 Effect of Output Length Caps

A shorter output cap frees slots earlier and converts truncated votes to abstentions. On the 200 archived problems, truncating lengths to 384 tokens while preserving votes reduced index-based admission savings from 8.71% to 2.62%. Changing only the votes yielded 9.64%, and changing both yielded 2.81%. Shorter paths thus explain the decrease within this archive.

With the device integer parser, raising the cap from 384 to 1,024 tokens increased simulated savings on the archive by 4.57 percentage points. On 32 new hash-selected GSM8K problems, we truncated each `Qwen2.5` 1,024-token reference panel to form a paired 384-token panel. Mean device savings were 0.86% (95% CI $[-0.33,2.23]\%$) at 384 tokens and 1.30% ($[0.33,2.39]\%$) at 1,024, below the 2% practical threshold for the long cap. The paired difference was $+0.44$ percentage points (20,000-resample CI $[-0.79,1.84]$), leaving its direction unresolved. Only 35 of 512 paths hit 384 tokens and two hit 1,024, leaving 20 problems unchanged across caps. Replay identified all changed schedules (5 at 384, 7 at 1,024) but predicted a $-0.32$ percentage-point shift (Appendix I, Figure 7 and Table 6).

---

## 5 Related Work

**List and Profile Scheduling.** List scheduling bounds makespan on identical processors (Graham, 1969, Theorem 1). Profile scheduling assumes externally given processor availability (Dolev & Warmuth, 1985; Liu & Sanlaville, 1995, 1997). Other results establish predictability under task shortening (Cucu-Grosjean & Goossens, 2010), model AND/OR precedence (Möhring et al., 2004), or compare stochastic throughput and response times (Baccelli et al., 1993). Earlier completion of each task alone does not imply lower concave cost (Appendix J). Here votes determine admission. A common terminal prefix and a shrinking permitted width let us compress a competing schedule to prove the virtual-time occupancy inequality (3). Classical majorization then gives the concave-cost comparison (Chang & Yao, 1993). The matching voting panels establish tightness.

**Parallel Reasoning and Early Stopping.** Self-consistency aggregates multiple reasoning paths (Wang et al., 2023), and recent work formalizes risk-controlled stopping and winner certification (Li & Li, 2026; Chen et al., 2026). We adopt strict margin certification and analyze safe lookahead admission prior to stopping. On 30 AIME questions, indexed and buffered rolling admission saved 47.38% and 40.45% in unit-cost replay against synchronous width-two batches. With rolling refill and equal budgets on both sides, indexed admission saved 10.14% relative to buffered admission (95% question bootstrap CI $[5.24\%,15.66\%]$). Asynchronous inference systems (Jiang et al., 2025; Xiong et al., 2026), speculative branch expansion (Zhong et al., 2026), delayed verification for batching in SpecScale (Jeong et al., 2026), and delayed replication (Badita et al., 2020) explore complementary latency-concurrency trade-offs; our framework compares policies on fixed workloads and votes while charging every canceled launch to the per-problem budget.

**Sequential Testing and Polyhedral Scheduling.** Our setting connects to curtailed sampling plans (Guenther, 2004), group sequential tests with delayed responses (Hampson & Jennison, 2013), parallel ranking and selection (Ni et al., 2017), stochastic Boolean function evaluation (Cicalese et al., 2011), and sequential batch testing (Segev & Shaposhnik, 2022; Yang et al., 2024). The capacity constraints in our certificate-work LP resemble discrete row- and column-sum inequalities (Ryser, 1957, Theorem 2.1). Unlike polyhedral scheduling with tunable per-job service rates (Jäger et al., 2025), all active paths in our hardware model advance at a shared decoding rate.

---

## 6 Scope, Limitations, and Conclusion

**Practicality of Per-Problem Budgets.** Launch budgets should reflect caller requirements. Evaluation suites often log fixed full panels (EleutherAI, 2024), while agent frameworks enforce absolute call limits (Pydantic, 2026; LangChain, 2026). Where early stopping is used, Li & Li (2026, Appendix H.4) charge all requests launched at micro-batch boundaries, bounding overrun to $m - 1$ at width $m$; how often production callers require a strict per-problem overrun cap $B$ relative to serial voting remains unmeasured. On 200 GSM8K problems, enforcing only $Q = 14$ with immediate refill exceeds $K + 1$ launches on 93 problems; adding $B = 1$ saves 0.985 launches per problem at a 20.76% simulated decision-latency cost. Replaying paths generated on the device for 32 problems saved 1.47 and 1.53 launches at latency costs of 0.42% and 0.16% for the two output caps, respectively.

**Summary and Deployment Considerations.** With zero extra launches, discrete concavity over reachable widths characterizes universal optimality. When panel size and quota vary, the least concave majorant gives the exact worst-case ratio. Fixing them can tighten it (Appendix B.2). With $B=1$, certificate work leaves less than 1% average room for timing gains on the tested panels under the fixed calibrated clocks. Most of the observed gain over buffered admission comes from counting out-of-prefix votes. The two prespecified fixed-length configurations met the prediction criteria in one A800 session. Extending the clock to shared serving requires modeling queues, prefill preemption, KV-cache imbalance, and interference across requests.

---

## Impact Statement

Per-problem launch budgets allow operators to bound speculative model calls and wasted compute. Deliberately delaying launches can increase user-facing tail latency while altering compute availability for concurrent workloads; net effects on answer quality, multi-tenant fairness, and cost depend on deployment policies and cancellation handling.

## AI Use Disclosure

OpenAI Codex assisted with formulating research questions and proofs, writing the primary simulator and engine drivers, running experiments, analyzing data, and drafting and revising the manuscript. Codex generated the figures from scheduling examples and archived data. Separate verification scripts enumerated small-panel instances and reconstructed latency comparisons from archived engine events. Literature checks recorded consulted versions, theorems, pages, and search scopes. The supplementary materials provide proofs, code, and input fingerprints. The authors take responsibility for the accuracy, originality, and integrity of the submitted work.

---

## References

Baccelli, F., Liu, Z., and Towsley, D. Optimal scheduling of parallel processing systems with real-time constraints. Research report RR-1113, INRIA, 1989. URL `https://inria.hal.science/inria-00075446v1`.

Baccelli, F., Liu, Z., and Towsley, D. Extremal scheduling of parallel processing with and without real-time constraints. *Journal of the ACM*, 40(5):1209–1237, 1993. doi: 10.1145/174147.169745.

Badita, A., Parag, P., and Aggarwal, V. Optimal server selection for straggler mitigation. *IEEE/ACM Transactions on Networking*, 28(2):709–721, 2020. doi: 10.1109/TNET.2020.2973224.

Chang, C.-S. and Yao, D. D. Rearrangement, majorization and stochastic scheduling. *Mathematics of Operations Research*, 18(3):658–684, 1993. doi: 10.1287/moor.18.3.658.

Chen, W., Li, P., Liu, M., Su, W., and Xie, T. MARS: Margin-adversarial risk-controlled stopping for parallel LLM test-time scaling. *arXiv:2606.12935*, 2026.

Cicalese, F., Gagie, T., Laber, E., and Milanič, M. Competitive Boolean function evaluation: Beyond monotonicity, and the symmetric case. *Discrete Applied Mathematics*, 159(11):1070–1078, July 2011. ISSN 0166-218X. doi: 10.1016/j.dam.2010.05.016. URL http://dx.doi.org/10.1016/j.dam.2010.05.016.

Cobbe, K., Kosaraju, V., Bavarian, M., Chen, M., Jun, H., Kaiser, L., Plappert, M., Tworek, J., Hilton, J., Nakano, R., Hesse, C., and Schulman, J. Training verifiers to solve math word problems. *arXiv:2110.14168*, 2021. URL https://arxiv.org/abs/2110.14168.

Cucu-Grosjean, L. and Goossens, J. Predictability of fixed-job priority schedulers on heterogeneous multiprocessor real-time systems. *Information Processing Letters*, 110(10):399–402, 2010. doi: 10.1016/j.ipl.2010.03.009.

Dolev, D. and Warmuth, M. K. Profile scheduling of opposing forests and level orders. *SIAM Journal on Algebraic Discrete Methods*, 6(4):665–687, 1985. doi: 10.1137/0606066.

EleutherAI. GSM8K chain-of-thought self-consistency task. *Language Model Evaluation Harness*, versioned configuration (https://github.com/EleutherAI/lm-evaluation-harness/blob/517aadc4d05507e2fea7b7753e91e6ad7dd76847/lm_eval/tasks/gsm8k/gsm8k-cot-self-consistency.yaml), 2024.

Graham, R. L. Bounds on multiprocessing timing anomalies. *SIAM Journal on Applied Mathematics*, 17(2):416–429, 1969. doi: 10.1137/0117039.

Guenther, W. C. Curtailed sampling plans. In *Encyclopedia of Statistical Sciences*. John Wiley & Sons, 2004. doi: 10.1002/0471667196.ess1662.

Hampson, L. V. and Jennison, C. Group sequential tests for delayed responses (with discussion). *Journal of the Royal Statistical Society Series B: Statistical Methodology*, 75(1):3–54, January 2013. ISSN 1467-9868. doi: 10.1111/j.1467-9868.2012.01030.x. URL http://dx.doi.org/10.1111/j.1467-9868.2012.01030.x.

He, C., Luo, R., Bai, Y., Hu, S., Thai, Z., Shen, J., Hu, J., Han, X., Huang, Y., Zhang, Y., Liu, J., Qi, L., Liu, Z., and Sun, M. OlympiadBench: A challenging benchmark for promoting AGI with olympiad-level bilingual multimodal scientific problems. In *Proceedings of the 62nd Annual Meeting of the Association for Computational Linguistics (Volume 1: Long Papers)*, pp. 3828–3850, 2024. doi: 10.18653/v1/2024.acl-long.211.

Jäger, S., Lindermayr, A., and Megow, N. The power of proportional fairness for non-clairvoyant scheduling under polyhedral constraints. In *Proceedings of the 2025 Annual ACM-SIAM Symposium on Discrete Algorithms (SODA)*, pp. 3901–3930, 2025. doi: 10.1137/1.9781611978322.132.

Jeong, J., Choi, W., Jeon, M., and Ahn, J. Taming speculative search for test-time scaling in LLM serving. *arXiv:2609.39334*, 2026.

Jiang, W., Shahout, R., Du, Y., Mitzenmacher, M., and Yu, M. Intra-request branch orchestration for efficient LLM reasoning. *arXiv:2509.24957*, 2025.

LangChain. Model call limit middleware. Versioned source code (https://github.com/langchain-ai/langchain/blob/e8a78d547970628c35cf5f3c7b054766099ea0bc/libs/langchain_v1/langchain/agents/middleware/model_call_limit.py), 2026.

Li, S. and Li, J. From discovery to decision: Finite-budget recoverability in LLM voting. *arXiv:2610.01014*, 2026.

Liu, Z. and Sanlaville, E. Preemptive scheduling with variable profile, precedence constraints and due dates. *Discrete Applied Mathematics*, 58(3):253–280, 1995. doi: 10.1016/0166-218X(93)E0151-N.

Liu, Z. and Sanlaville, E. Stochastic scheduling with variable profile and precedence constraints. *SIAM Journal on Computing*, 26(1):173–187, 1997. doi: 10.1137/S0097539791218949.

Möhring, R. H., Skutella, M., and Stork, F. Scheduling with AND/OR precedence constraints. *SIAM Journal on Computing*, 33(2):393–415, 2004. doi: 10.1137/S009753970037727X.

Ni, E. C., Ciocan, D. F., Henderson, S. G., and Hunter, S. R. Efficient ranking and selection in parallel computing environments. *Operations Research*, 65(3):821–836, June 2017. ISSN 1526-5463. doi: 10.1287/opre.2016.1577. URL http://dx.doi.org/10.1287/opre.2016.1577.

Pydantic. Pydantic AI: Usage limits and pre-request checks. Versioned source code (https://github.com/pydantic/pydantic-ai/blob/b2d64a332528f560ea543eb6e8d1743125e1446b/pydantic_ai_slim/pydantic_ai/usage.py), 2026.

Ryser, H. J. Combinatorial properties of matrices of zeros and ones. *Canadian Journal of Mathematics*, 9:371–377, 1957. doi: 10.4153/CJM-1957-044-3.

Segev, D. and Shaposhnik, Y. A polynomial-time approximation scheme for sequential batch testing of series systems. *Operations Research*, 70(2):1153–1165, March 2022. ISSN 1526-5463. doi: 10.1287/opre.2019.1967. URL http://dx.doi.org/10.1287/opre.2019.1967.

Wang, S. L., Dravid, A., Shao, R., Farhat, K., Min, S., and Efros, A. A. Base models can reason by taking a cue from training data. *arXiv:2610.06851*, 2026. URL https://arxiv.org/abs/2610.06851.

Wang, X., Wei, J., Schuurmans, D., Le, Q., Chi, E., Narang, S., Chowdhery, A., and Zhou, D. Self-consistency improves chain of thought reasoning in language models. In *International Conference on Learning Representations*, 2023.

Xiong, J., Chen, Q., Ye, F., Wan, Z., Zheng, C., Zhao, C., Shen, H., Li, H., Tao, C., Tan, H., Bai, H., Shang, L., Kong, L., and Wong, N. ATTS: Asynchronous test-time scaling via conformal prediction. In *International Conference on Learning Representations*, 2026. URL https://openreview.net/forum?id=YM3SskmtCE.

Yang, F., Hermans, B., Zufferey, N., and Leus, R. Sequential testing in batches with resource constraints. *Expert Systems with Applications*, 256:124858, 2024. doi: 10.1016/j.eswa.2024.124858.

Zhong, S., Huang, H., Qiu, S., Zuo, P., Wang, R., and Li, M. Breaking the reward barrier: Accelerating tree-of-thought reasoning via speculative exploration. In *Proceedings of the 20th USENIX Symposium on Operating Systems Design and Implementation (OSDI 26)*. USENIX Association, 2026. URL https://www.usenix.org/conference/osdi26/presentation/zhong.

---

## Appendix A: Workload Invariance Under Zero Extra Budget

Suppose the service returns because a winner is strictly certified after $s$ paths in set $S$ complete, certifying label $a$. Let $S_0 \subseteq S$ be the paths completed when the final launch occurred. Under the information available then, serial voting could still certify within $s$ votes: construct a consistent input retaining $v_i$ for $i \in S_0 \cap \{1, \dots, s\}$, assigning $a$ to all remaining positions in $\{1, \dots, s\}$, and retaining all known votes beyond $s$. This only preserves or strengthens $a$'s margin relative to $S$, so the constructed prefix strictly certifies $a$.

When $B = 0$, cumulative launches after the final launch must satisfy $J \le s$ (otherwise the constructed input overruns the budget); since every completed path was launched, $s = J$. Because launches follow index order, the completed paths form the exact serial prefix $\{1, \dots, J\}$, implying $K \le J$ and hence $J = K$. If instead the service exhausts quota $Q$ without certifying, then $K \ge Q$. Thus every valid schedule completes total work $\sum_{i=1}^{\min(K, Q)} w_i$ over the exact same set of paths.

---

## Appendix B: Occupancy Majorization Proof for Arbitrary Slot Counts

Under $B = 0$, let $m(S)$ be the minimum number of additional completions needed from reachable state $S$ to strictly certify a winner or exhaust all $N$ votes across all consistent completions, and let $\ell = |S| + m(S)$. Quota $Q$ limits remaining completions to $Q - |S|$. If $\ell = N$, serial voting stops at or before $N$, so $K \le \ell$. Otherwise, assigning $m(S)$ votes to a current plurality label maximizes the margin and strictly certifies a winner; filling unknown positions in $\{1, \dots, \ell\}$ with that label while preserving all known votes yields a consistent completion with $K \le \ell$, hence $M(S) \le \ell$. Conversely, monotonicity of $M$ and $B = 0$ ensure all admitted indices are at most $M$, and taking a completion that certifies at $M$ (or exhausts $N$) shows $M(S) = \ell$. Thus the allowed concurrency width after each refill is $\min(P, m(S), Q - |S|)$, where

$$
m(S) = \min\left\{R,\; \max\left\{0,\; \lfloor(R - g)/2\rfloor + 1\right\}\right\}, \qquad R = N - |S|,\; g = \text{gap}(S),
$$

which never increases as new votes arrive.

Fixing votes and shortening workloads to $0 < w'_i \le w_i$, induction on launch order shows that greedy $G$ on $w'$ launches and completes every path no later in virtual time than any valid schedule $A$ on $w$, and satisfies $h_{G, w'}(t) \le h_{G, w}(t)$. For any finite-duration schedule $A$ returning at $D$ and any measurable $E \subseteq [0, D]$ with complement $E^c = [0, D] \setminus E$, fix $\varepsilon \in (0, 1)$ and define the time-compression map

$$
\varphi_\varepsilon(t) = \int_0^t \left(\mathbf{1}_E(u) + \varepsilon \mathbf{1}_{E^c}(u)\right) du, \qquad 0 \le t \le D.
$$

Setting $w'_i = \varphi_\varepsilon(f_i^A) - \varphi_\varepsilon(s_i^A) > 0$ for completed paths preserves event order and simultaneous completions, yielding a valid replay finishing at $D_\varepsilon = \varphi_\varepsilon(D)$. Hence

$$
\int_E h_A(u)\,du + \varepsilon \int_{E^c} h_A(u)\,du = \sum_{i=1}^J w'_i = \int_0^{D_\varepsilon} h_{G, w'}(u)\,du \le \int_0^{D_\varepsilon} h_{G, w}(u)\,du.
$$

Letting $\varepsilon \to 0^+$ establishes Eq. (3). Setting $E = \{t : h_A(t) > j\}$ and subtracting $j|E|$ gives $U_A(j) \le U_G(j)$, which combined with $c_k = c_1 k - \sum_{j=1}^{P-1} \theta_j (k - j)_+$ and $\theta_j \ge 0$ proves $T_G \le T_A$. The same compression argument holds when all $N$ paths must complete in order.

For necessity, if $\theta_j < 0$ for some $1 \le j < P$, taking even $N \ge \max(2j, P)$, unanimous votes, $Q = j + 1$, workloads 2 on the first $j-1$ paths and 1 on the next two gives $c_{j+1} + c_{j-1} > 2c_j$. Independent dynamic-programming enumeration across 1,416 configurations (4–8 slots, 1,651,840 full histories) passed all 4,488 excess-occupancy comparisons.

### B.1 Exact Worst-Case Ratio Under Non-Concave Clocks

When $\gamma = \max_{1 \le k \le P} \hat{c}_k / c_k > 1$, let $j$ achieve $\gamma$ and let the chord of $\hat{c}$ containing $j$ meet $c$ at $0 \le a < j < b \le P$. Set $n_s = \text{lcm}(b - a, j - a)$, $L = n_s / (j - a)$, $d > n_s + a + P$ a multiple of $P$, $N = 2(d + b - 1)$, and $Q = d + a + n_s$. Assign workload $\varepsilon > 0$ and vote $A$ to the first $d$ paths, followed by $a$ paths of length $L$ and $n_s$ paths of length 1 all voting $B$. Both policies batch the prefix at width $P$. Across the suffix the votes keep the admission ceiling at $b$. Actual occupancy also depends on the remaining paths, quota, and slots. Greedy runs $a$ long and $b - a$ short paths for $n_s / (b - a)$ steps and then $a$ long paths until $L$, incurring suffix cost

$$
\frac{n_s}{b - a} c_b + \left(L - \frac{n_s}{b - a}\right) c_a = L\left(\frac{j - a}{b - a} c_b + \frac{b - j}{b - a} c_a\right) = L \hat{c}_j,
$$

while the competing schedule holds $j - a$ short paths with $a$ long paths until $L$ at cost $L c_j$. Letting $\varepsilon \to 0^+$ converges the ratio to $\hat{c}_j / c_j = \gamma$. All 210 triples $a < j < b$ for $P \in \{2, \dots, 8\}$ were verified by replay.

Note that re-pricing must hold the virtual launch trajectory fixed: for $N = 8, Q = 4, P = 3, B = 0$, unit workloads on the first four paths, and costs $(10, 11, 13)$, a policy that runs two paths in parallel and branches on whether wall-clock time is below 11.25 costs 22 under $c$ and 23 when re-priced on the fixed trajectory under $\hat{c} = (10, 11.5, 13)$, whereas re-evaluating the branch under $\hat{c}$ would cost $11.5 + 20 = 31.5$.

### B.2 Fixed Panel Size, Quota, and Slot Capacity

**Corollary to Theorem 1**  
Fixing $N, Q, P$ and setting $L = \min(Q, \lfloor N/2 \rfloor + 1)$ and $b = \min(P, L)$, immediate refill is optimal on all such panels under $B = 0$ if and only if $c$ is discretely concave on $\{0, \dots, b\}$.

*Proof sketch.* The initial width is at most $b$ and can only decrease, so Eq. (3) proves sufficiency. For necessity choose any $1\le j<b$ with $c_{j+1}+c_{j-1}>2c_j$. With unanimous votes all schedules complete the first $L$ paths. Give the first $j-1$ paths length 2, the next two length 1, and the remaining $L-j-1$ paths length $\varepsilon$. Greedy starts all $j+1$ long or unit paths at zero. During their execution any additional short paths change the occupancy for at most $(L-j-1)\varepsilon$ virtual time in total, and any residual short work takes at most that long. Its cost is $c_{j+1}+c_{j-1}+O(\varepsilon)$. A comparator can run the first $j+1$ paths at width $j$ for two steps, then finish the residual short paths at cost $O(\varepsilon)$. The strict gap persists as $\varepsilon$ decreases. $\square$

For $N = 4, Q = P = 3$, and costs $(1, 1, \lambda)$ with $\lambda \ge 2$, sorting the first three lengths as $0 < x \le y \le z$ gives $T_G = z + (\lambda - 1)x$. Any competing schedule of active virtual duration $V$ with three-way overlap $\delta$ must pack $(x-\delta, y-\delta, z-\delta)$ onto two tracks outside $\delta$, requiring $V - \delta \ge x + y - 2\delta$ and $V \ge z$, so $T_{\text{opt}} \ge \max(z, 2x)$ and $T_G / T_{\text{opt}} \le (\lambda + 1)/2$ (tight at $(2, 1, 1)$), strictly below the $2\lambda/3$ supremum from Theorem 1 for $\lambda > 3$.

---

## Appendix C: Candidate Enumeration and Integer-Launch Optimality

Represent a candidate terminal set $S\subseteq\{1,\dots,Q\}$ by a bit mask. Retain only masks that strictly certify a winner or exhaust all $Q$ paths. If $j\in S$, $i<j$, and $w_i\le w_j$, then $i\in S$ because $i$ starts no later than $j$. For the largest $j\in S$, the observed set $S_0$ at its launch satisfies $S_0\subseteq S\setminus\{j\}$, so $j\le F(S_0)\le F(S\setminus\{j\})$. For this necessary test, evaluate Eq. (2) algebraically even if the hypothetical set $S\setminus\{j\}$ already certifies a winner. These tests retain a superset of reachable terminal sets. After removing componentwise-dominated demand vectors, we solve the dual LP with exact rational arithmetic as follows.

$$
\max_{y \in [0, \infty)^P} b^\top y \qquad \text{s.t.} \quad \sum_{m=1}^P \min(k, m)\, y_m \le c_k,\quad k = 1, \dots, P,
$$

where $b_m$ is the maximum right-hand side among constraints with coefficient $\min(k, m)$. Although candidate masks grow exponentially in $Q$, bounds are computed offline on archived traces while online admission remains a lightweight index scan.

For positive integer workloads, remove global idle intervals and round every event with the same shift $\rho(t)=\lfloor t+U\rfloor$, where $U$ is uniform on $[0,1)$. Since $\rho(s_i+w_i)=\rho(s_i)+w_i$, every completed path receives its workload. Process simultaneous completions before launches, truncating at any earlier return. A surviving launch then sees at least its original votes, so the monotone admission bound and slot constraint still permit it. Each original interval $[a,b]$ has expected rounded duration $b-a$. Truncation only removes nonnegative cost, so some shift yields an integer schedule no slower than the original. Schedules no slower than greedy have bounded virtual duration because $c_{\min}>0$. Only finitely many integer launch vectors remain, so a minimum exists. Exhaustive DP checks over 11,776 small configurations (3–4 paths, 2–3 slots, workloads in $\{1,2\}$) confirmed every work lower bound (tight on 9,390, strictly tighter than virtual-time bounds on 6,537, waiting beat greedy on 3,112), alongside 17,640 zero-budget panel checks.

---

## Appendix D: Virtual-Time Bound Under Finite Waiting

Without a cap on waiting, taking $L > 4$, 16 unanimous $A$ votes, $P = 4, Q = 14, B = 1$, and workloads $(L, 2, 1, 1, \dots, 1)$ allows path 10 to launch safely at virtual time 3; greedy certifies at 4, whereas waiting for path 1 to finish delays certification to $L$.

**Theorem 3 (Finite Waiting)**  
Suppose a safe policy $D$ delays refill only on finitely many intervals of total virtual length $H$, refilling to the admission bound at all other times and at the right endpoints of waiting intervals. Then $V_G \le V_D \le V_G + H$, and the bound is tight at $N = 16, P = 4, Q = 14, B = 1$.

**Proof**  
Let $I \subseteq [0, V_D]$ be the union of waiting intervals ($|I| = H$), $C(t) = t - |I \cap [0, t]|$, and $\varphi(u) = \sup\{t \in [0, V_D] : C(t) \le u\}$ for $0 \le u < C(V_D)$. Then $C(\varphi(u)) = u$, $u \le \varphi(u) \le u + H$, and $\varphi(v) - \varphi(u) \ge v - u$ for $u \le v$. Induction on launch order shows that while $D$ has not returned, every path launched (or completed) by $G$ by time $u$ is launched (or completed) by $D$ by time $\varphi(u)$. If $V_G < C(V_D)$, setting $u = V_G$ forces $D$ to return by $\varphi(V_G) < V_D$, a contradiction. Thus $V_D - H \le V_G \le V_D$, achieved by delaying path 10 by $0 \le H < L - 4$ in the example above. $\square$

---

## Appendix E: Wall-Clock Bound from Finite Waiting

Let $c_{\max} = \max_{1 \le k \le P} c_k$ and define the maximum adjacent-width step-cost increments

$$
L_+ = \max\left(0,\, \max_{1 \le k < P}(c_{k+1} - c_k)\right), \qquad L_- = \max\left(0,\, \max_{1 \le k < P}(c_k - c_{k+1})\right).
$$

For $P=1$, set $L_+=L_-=0$. If $D$ satisfies Theorem 3, keeps at least one path active until return, and $G$ accrues $J$ launches and $C$ completions upon return, then

$$
T_D - T_G \le H(c_{\max} + C L_+ + J L_-).
$$

*Proof sketch*: By Appendix D, cumulative launches $J_D(t)$ and completions $C_D(t)$ lag $G$ by at most $H$ time units over $[0, V_G)$, bounding the integrated launch and completion lags by $JH$ and $CH$, respectively. Since active width equals cumulative launches minus completions, excess and deficit widths over $[0, V_G)$ are bounded by completion and launch lags, contributing at most $H(C L_+ + J L_-)$, while the remaining duration at most $H$ past $V_G$ costs at most $H c_{\max}$. Small-panel enumeration verified this bound across 24,768 schedule comparisons (3,096 tight).

---

## Appendix F: Clock Sensitivity of Extra-Budget Savings Bounds

For any fixed occupancy vector, cost is linear in $c$; hence the certificate lower bound $L_q(c)$ is concave in $c$, while $G_q(c)$ is positive linear. Over the hyperrectangle of block-mean step costs (16 vertices $\mathcal{V}$ for 4 widths), $L_q(c)/G_q(c)$ is bounded below by a weighted average of vertex ratios, so maximizing per-problem savings over $\mathcal{V}$ bounds any fixed clock in the range; taking componentwise minima for $L_q$ and maxima for $G_q$ bounds time-varying clocks. At 512 tokens, full bounds for AIME, AMC, and OlympiadBench are 0.413%, 0.528%, and 0.181% (0.117%, 0.268%, and 0.139% at 2,048 tokens). Over the 3,968-token block range, fixed-clock bounds across AIME, AMC, OlympiadBench, and GSM8K are 0.296%, 0.500%, 0.235%, and 0.845% (and 0.509%, 0.713%, 0.482%, and 1.034% under time-varying clocks).

---

## Appendix G: Partial-Index Admission and Low-Memory Implementation

To admit path $j$ safely, the maximum margin over the prefix of length $t = \max(0, j - B - 1)$ across all completions consistent with visible information must not exceed $N - t$. Index-based admission preserves known prefix positions; unordered admission enumerates which returned votes could fall inside the prefix; prefix-plus-multiset admission fixes the contiguous prefix before enumerating remaining votes. A memory-efficient implementation of index-based admission maintains only cumulative label counts and completion counts up to $t = \max(0, J - B)$ plus individual votes for at most the last $B$ launched positions.

---

## Appendix H: Data Sources, Statistical Methodology, and Additional Ablations

AIME, AMC, and GSM8K rollouts come from the public *Reasoning Cues* archive (`https://huggingface.co/datasets/reasoning-cues/rollouts-qwen4b/tree/b8c33b85a1a6cdfb23b06a5f9d696f52950780e4`, `Qwen3-4B-Base`, revision `b8c33b85`). AIME paths are deterministically shuffled into two disjoint 16-path panels. AMC uses batch 2. The GSM8K archive parser finds the last opening `\boxed{`, takes its brace-balanced contents, and removes whitespace. Any remaining nonempty string is a valid vote. Truncation, a missing or unclosed box, or an empty result yields an abstention. Substituting the device integer parser changes 209 of 3,200 votes and yields 8.60% mean savings at the original lengths, compared with 8.71% for the archive parser. Eight GSM8K shards (200 problems) were selected by SHA-256 hash order before inspection. For these archived admission comparisons we resampled problems (10,000 draws with seed 19431 for prespecified comparisons, 20,000 draws with seed 651 for post-hoc baselines).

**Post-hoc sensitivity to shards and long paths.** Each of the eight selected shards contains 25 problems. Omitting one shard at a time gave 8.15–9.23% mean savings against buffered admission. Resampling eight whole shards with replacement gave a 95% percentile interval of [6.71%, 10.74%]. The analogous intervals for the unordered and prefix-plus-unordered comparators, each using its own latency as denominator, were [0.237%, 1.191%] and [0.055%, 0.605%]. These intervals describe the observed shards under this clock. Two problems accounted for 67.04% of the net saving in summed latency. Their longest outputs, 31,744 and 16,994 tokens, exceed the calibration engine's 8,192-token context limit. Omitting those two problems diagnostically gave 7.82% mean per-problem savings and 7.09% savings in summed latency. The primary results retain all 200 problems.

> **Figure 6**: Per-problem latency savings of index-based vs. buffered admission on GSM8K under the 3,968-token clock (left, dashed line at mean), and theoretical upper bounds over index-based immediate refill across calibrated A800 cost curves (right).

**Table 4**: Mean simulated savings (%) on 200 GSM8K problems across calibrated fixed clocks (first row relative to buffered admission; remaining rows relative to index-based immediate refill).

| Policy | 512 tokens | 2,048 tokens | 3,968 tokens |
| :--- | :---: | :---: | :---: |
| Index-based vs. Buffered | 8.934 | 8.880 | 8.709 |
| Repeated Conditional Wait | −76.040 | −75.005 | −73.244 |
| First Conditional Wait (≤8 steps) | −0.307 | −0.302 | −0.300 |
| First Eligible Wait (≤8 steps) | −0.229 | −0.225 | −0.224 |
| Oracle Best Single Wait | 0.103 | 0.100 | 0.115 |

**Table 5**: Mean simulated savings (%) and 95% bootstrap CIs on 200 GSM8K problems under the fixed 3,968-token clock.

| Candidate vs. Reference Policy | Mean (%) | 95% CI |
| :--- | :---: | :---: |
| Index-based vs. Buffered | 8.71 | $[6.61,\; 11.02]$ |
| Index-based vs. Unordered | 0.67 | $[0.25,\; 1.22]$ |
| Index-based vs. Prefix + Unordered | 0.30 | $[0.07,\; 0.61]$ |
| Repeated Wait vs. Immediate Refill | −73.24 | $[−143.45,\; −20.24]$ |
| Capped Conditional Wait vs. Immediate Refill | −0.30 | $[−0.39,\; −0.22]$ |
| Capped Control Wait vs. Immediate Refill | −0.22 | $[−0.30,\; −0.15]$ |
| Oracle Single Wait vs. Immediate Refill | 0.115 | $[0.089,\; 0.142]$ |

Aggregating total latency across problems, repeated waiting increases total latency by 47.00%. Under the 512- and 2,048-token clocks, no valid policy can exceed 0.760% and 0.457% mean savings over index-based immediate refill on GSM8K.

---

## Appendix I: Supplementary Data from A800 Output-Cap Paired Experiments

Across 32 newly hash-selected GSM8K problems measured in balanced order within one A800 session (160 timed panels, 515,582 total tokens, 835.24 s synchronized wall-clock time; full 16-vote accuracy 27/32 at both caps), Table 6 reports aggregate resource usage.

**Table 6**: Aggregate resource usage across 32 GSM8K problems under fixed workloads (launches and generated tokens include canceled requests).

| Cap | Admission | Wall Time (s) | Steps | Tokens | Launches | Correct | Certified |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| 384 | Index-based | 153.33 | 26,895 | 95,159 | 384 | 26 | 26 |
| 384 | Buffered | 154.77 | 27,159 | 95,303 | 384 | 26 | 26 |
| 1,024 | Index-based | 158.22 | 27,578 | 96,855 | 380 | 27 | 27 |
| 1,024 | Buffered | 161.02 | 27,834 | 96,611 | 380 | 27 | 27 |

> **Figure 7**: Per-problem latency savings of index-based vs. buffered admission on 32 GSM8K problems on an A800 at 384- and 1,024-token caps and their paired differences (bottom panels zoom in on means and 95% paired bootstrap CIs).

---

## Appendix J: Counterexamples Comparing Classical Precedence Scheduling

In the author version of Chang & Yao (1993), Theorem 3.5 (Day) compares pairings of permutations of two fixed vectors for monotone supermodular or submodular functions. Theorem 3.6 compares expectations for independent random vectors with independent components. Section 3.2 restricts the permutations to a single cycle. In our setting, the competing schedules can occupy different widths for different durations. Appendix B uses time compression to establish inequality (3) before applying the concave-cost comparison.

Baccelli et al. (1989) fix a repeated precedence graph and a task-to-machine assignment. Under their Assumption A, service times of each task type are independent and identically distributed across jobs. Proposition 4.1 and Corollary 4.2 order job counts and throughput under FCFS. Proposition 4.3 compares response-time vectors. Equation (3) here compares occupied widths on the same fixed paths when returned votes determine admission. The following examples examine fixed precedences and taskwise completion times.

1. **Fixed precedence cannot capture voting admission.** Let $(N, P, Q, B) = (9, 5, 9, 0)$, $w_1 = 10$ (launched at 0), and tasks 2–5 have workloads $(4, 3, 2, 1)$ and votes $(A, A, B, B)$. Launching task $i \in \{2, 3, 4, 5\}$ at $5 - w_i \mp 1/4$ produces three states at time 5 with 2 completed tasks: $\{2, 4\}$ and $\{3, 5\}$ have disagreeing votes ($M = 6$, admitting task 6), whereas $\{2, 3\}$ has two $A$ votes ($M = 5$, blocking task 6). Because $\{2, 4\} \cap \{3, 5\} = \emptyset$, no static AND-precedence condition can admit the former two while blocking the third.
2. **Taskwise completion dominance does not imply concave-cost dominance.** Four unit-work tasks share 3 slots with tasks 3 and 4 depending on task 1. Immediate refill runs $\{1, 2\}$ then $\{3, 4\}$ (width 2 for 2 steps), whereas a competing schedule launches 1 at 0, $\{2, 3\}$ at 1, and 4 at 1.5 (widths 1, 2, 3 for 1.5, 0.5, 0.5 steps). Under concave costs $(1, 2, 2.5)$, immediate refill costs 4 versus 3.75.

---

## Appendix K: Device Clock Validation Details and Overrun-Cap Costs

Device validation used `vLLM 0.8.5 V0` (BF16, `Qwen2.5-1.5B-Instruct`, 512-token prompt, prefix caching and chunked prefill disabled). Median latencies for immediate and staged launch were $1,234\text{ ms}$ and $1,203\text{ ms}$ on three requests, and $602\text{ ms}$ and $1,221\text{ ms}$ on two equal requests. If the 12 paired block effects are independent and share a median with no probability mass at that median, the third and tenth order statistics bracket it with probability $2^{-12}\sum_{k=3}^9 \binom{12}{k}=1969/2048\approx96.14\%$. The blocks came from one session and may share timing drift. Decomposing the 2.508 percentage-point mean saving on three requests attributes $+3.165$ points to cached decode steps, $-0.644$ to first-token steps, and $-0.013$ to remaining host overhead. In the three-request runs, immediate and staged launch took 256 and 257 engine steps, respectively. The paired comparison tests the end-to-end latency prediction.

**Post-hoc sensitivity to the third launch time.** In the three-request archive replay, request 1 finished before request 2 on 113 of 200 problems. Choosing between immediate launch and waiting specifically for request 2 saved 0.162% on average (28 strict improvements). Waiting for the first completion instead gave the two-action oracle 0.364% (66 improvements). Allowing the oracle to choose any virtual time $t\ge0$ gave 0.764% (135 improvements). In each comparison, the first two requests start at zero, all three lengths are known, all requests must finish, and each problem's denominator is its immediate-launch latency. For fixed lengths, elapsed cost is piecewise linear in $t$ between changes in the order of starts and completions. Beyond $\max(w_1,w_2)$ further delay cannot help. Thus it suffices to check $0$, $w_1$, $w_2$, $\max(0,w_1-w_3)$, and $\max(0,w_2-w_3)$.

On 200 GSM8K problems with $N = Q = 16$, synchronous width-4 sampling overruns $K$ by $\ge 2$ on 98 problems and uncapped 4-slot immediate refill does so on 148 problems; enforcing $B = 1$ eliminates $\ge 2$ overruns and saves 1.56 launches per problem at a 35.36% simulated latency increase under the `DeepSeek` 3,968-token clock.

---

## Appendix L: Generalization to Collecting $r$ Passing Verifications

Consider $N$ non-revocable verification tasks sharing a decoding clock with positive workloads $w_i$ returning pass or fail. Serial verification stops at $r$ passes or after all $N$ tasks (index $K$), requiring $J \le K$.

**Proposition 4**  
At any unreturned state with $s$ passes and $f$ failures, the exact safe launch bound is $\min\{N, s + f + P, r + f\}$. Occupancy majorization Eq. (3) holds, and for fixed $P$ with varying $N, r$, workloads, and outcomes, the exact worst-case ratio of immediate refill over optimal is $\max_{1 \le j \le P} \hat{c}_j / c_j$, achievable with finite integer workloads.

*Proof.* The $f$ observed failures lie among the first $J$ positions. Prior safe launches ensure every compatible outcome has $K\ge J$. From position $J$ onward, no prefix shorter than $r+f$ can contain $r$ passes. Giving all unseen paths passing outcomes attains $K=\min(N,r+f)$, so the slot limit gives the stated bound. At return with $s=r$, we have $J\le r+f=s+f\le J$, hence all launched paths completed and form the serial stopping prefix. Exhausting all $N$ paths also fixes the completed set. The work is therefore invariant, and the allowed width $\min(P,N-s-f,r-s)$ is non-increasing. Appendix B's compression proves Eq. (3), and re-pricing the same virtual schedule gives the concave-majorant upper bound.

For equality, take a maximizing width $j$ on a chord with endpoints $a<j<b$ when the ratio exceeds one. Set $r=b$ and let all tasks fail. Take $a$ initial tasks of integer length $L=n_s/(j-a)$ followed by $n_s=\operatorname{lcm}(b-a,j-a)$ unit tasks, so $N=a+n_s\ge b$. Greedy runs at width $b$ for $n_s/(b-a)$ steps and at width $a$ for the remainder of $L$ (zero-cost padding if $a=0$). Its cost is $L\hat c_j$ by the chord identity. A schedule capped at width $j$ costs $Lc_j$, and the upper bound proves equality. If the maximum ratio is one, a single task attains it. $\square$
