"""Build the GPU section and auditable per-trial ledger from measured files."""
import argparse
import csv
import json
from pathlib import Path
import re
from statistics import median
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT/"tracks/scheduling/live"))
import analysis


def directories(label, raw, evidence):
    card = raw/label
    if (card/"profile/events.jsonl").is_file() and (card/"controlled/pairs.jsonl").is_file():
        return {key:card/key for key in ["profile","hf","http","controlled"]} | {"train":card/"train.jsonl","card":card}
    card = evidence/label
    suffix = "-02" if label=="h20" else ""
    return dict(profile=card/f"measure-{label}{suffix}",hf=card/f"panels-{label}{suffix}",
                http=card/f"http-{label}{suffix}"/"client",controlled=card/f"controlled-{label}"/"client",
                train=card/f"train-{label}.jsonl",card=card)


def version_record(directory):
    version_pattern = r"([0-9]+\.[0-9]+\.[0-9]+(?:[a-z][a-z0-9.]*)?(?:\+[A-Za-z0-9.]+)?)"
    explicit = directory/"vllm-version.txt"
    sources = [explicit] if explicit.is_file() else []
    sources += sorted(directory.rglob("*server*.log"))+sorted(directory.glob("vllm*setup*.log"),reverse=True)
    for path in sources:
        text=path.read_text(encoding="utf-8",errors="replace")
        patterns = ([version_pattern] if path==explicit else []) + [
            r"vLLM API server version\s+"+version_pattern,r"vllm=="+version_pattern,
            r"vLLM engine \(v?"+version_pattern+r"\)"]
        for pattern in patterns:
            found=re.search(pattern,text,re.IGNORECASE)
            if found:
                return {"version":found.group(1),"evidence_file":path.name}
    raise ValueError(f"No server version record found under {directory}")


def training(path):
    rows=[row for row in analysis.json_rows(path) if not row["warmup"]]
    if len(rows)!=3 or {r["iteration"] for r in rows}!={1,2,3}:
        raise ValueError(f"Incomplete training calibration: {path}")
    return dict(trials=len(rows),dtype=rows[0]["dtype"],input_tokens=rows[0]["input_tokens"],
                median_input_tokens_per_second=median(r["input_tok_per_sec"] for r in rows),
                peak_allocated_bytes=max(r["peak_allocated_bytes"] for r in rows),
                peak_reserved_bytes=max(r["peak_reserved_bytes"] for r in rows),
                sha256=analysis.file_hash(path))


def load_card(label, paths):
    hf, hfmeta, hffiles=analysis.hf_records(paths["hf"])
    http, httpmeta, httpfiles=analysis.http_records(paths["http"])
    control=analysis.controlled_summary(paths["controlled"])
    if not control["questions"]==6 or not control["paired_trials"]==18:
        raise ValueError("Controlled experiment lacks the six-question three-repetition design")
    raw_control=analysis.json_rows(paths["controlled"]/"pairs.jsonl")
    data=dict(label=label,profile=analysis.profile(paths["profile"]),training=training(paths["train"]),
              hf=analysis.summarize(hf,hfmeta,hffiles,"hf"),
              http=analysis.summarize(http,httpmeta,httpfiles,"http"),controlled=control,
              vllm=version_record(paths["card"]))
    for key in ("hf","http"):
        if data[key]["scope"]["independent_prompts"]!=6 or data[key]["scope"]["repeats_per_prompt"]!=3:
            raise ValueError(f"{label} {key} lacks the full measured design")
    ledger=[]
    for name,rows in [("hf",hf),("http",http)]:
        for r in rows:
            ledger.append(dict(gpu=label,engine=name,question=r["q"],repetition=r["rep"],policy=r["policy"],
                               wall_seconds=r["wall"],tokens=r["work"],paths=r["launched"],correct=r["correct"],
                               peak_allocated_bytes=r["allocated"],output_mismatches=r["content_diff"],
                               vote_mismatches=r["vote_diff"],winner_mismatch=r["winner_diff"],
                               mismatch_reference="full panel with the same path seeds"))
    for r in raw_control:
        for policy in ("rolling","refill"):
            ledger.append(dict(gpu=label,engine="controlled",question=r["qid"],repetition=r["repeat"],policy=policy,
                               wall_seconds=r[policy+"_seconds"],tokens=r["generated_tokens_each"],paths=r["matched_paths"],
                               correct=None,peak_allocated_bytes=None,
                               output_mismatches=r["generated_text_hash_mismatches"] if policy=="refill" else None,
                               vote_mismatches=0,winner_mismatch=False,mismatch_reference="rolling, fixed archived votes"))
    return data,ledger


def render_section(cards):
    row_lines=[]
    profile_lines=[]
    coupling=[]
    for label,card in cards.items():
        for engine,title in (("hf","Transformers"),("http","vLLM sampling"),("controlled","vLLM fixed lengths")):
            data=card[engine]
            if engine=="controlled":
                gain=data["macro_paired_wall_reduction"]
                interval=data["question_bootstrap_percentile_95"]
                delta=0
                unequal=0
            else:
                gain=data["paired"]["macro_wall_reduction"]
                interval=data["paired"]["question_bootstrap_percentile_95"]
                delta=data["paired"]["pooled_work_reduction"]
                unequal=data["paired"]["unequal_work_pairs"]
            row_lines.append(f"{label.upper()} & {title} & {gain*100:.1f} [{interval[0]*100:.1f}, {interval[1]*100:.1f}]"
                             f" & {delta*100:.1f} & {unequal}/18 \\\\")
        b={r["batch"]:r for r in card["profile"]["batches"]}
        t=card["training"]
        profile_lines.append(f"{label.upper()} & {b[1]['decode_tokens_per_second_median']:.1f} & "
                             f"{b[16]['decode_tokens_per_second_median']:.1f} & {b[16]['peak_allocated_bytes']/2**30:.2f} & "
                             f"{t['median_input_tokens_per_second']:.1f} & {t['peak_allocated_bytes']/2**30:.2f} \\\\")
        for engine,title in (("hf","Transformers"),("http","vLLM")):
            baseline=card[engine]["by_policy"]["refill"]
            coupling.append(f"{baseline['content_mismatches']}/{baseline['paths_checked']} for {title} on {label.upper()}")
    h20,a800=cards["h20"],cards["a800"]
    first=r"""
\section{Measured scheduling latency on two accelerators}
We ran Qwen2.5-1.5B-Instruct on one NVIDIA H20 and one A800, separately. Each run used six arithmetic prompts, three repetitions, eight indexed paths, four slots, temperature 0.7 and a 160-token limit. An excluded one-token warmup preceded each policy and prompt. The Transformers client batches active paths at each token. The vLLM client measures wall time from launching the first requests until a completed-answer lock or exhaustion. In the sampled conditions, temperature sampling used per-path seeds. We compared the resulting lengths, outputs and winners with separately executed full panels.

\begin{table}[htbp]\centering\small
\caption{Refill relative to committed rolling admission. Positive time and token reductions favor refill. Time is the mean of paired percentage reductions over three repetitions per question and then over six questions. Intervals resample questions 20,000 times. The work column reports the pooled percentage reduction in generated tokens. The last column counts pairs with unequal total work.}
\label{tab:measured-gpus}
\setlength{\tabcolsep}{4.8pt}
\begin{tabular}{llrrr}\toprule
GPU & Engine / workload & Time saved (\%) [95\% interval] & Work (\%) & Unequal \\\midrule
"""
    fixed_desc=(f"The controlled experiment forced the server to generate each path's recorded number of tokens, "
        f"verified the count from its response, and then released the recorded vote. Both cards used the same H20 full-panel reference. "
        f"The two policies each executed {h20['controlled']['equal_tokens_each']:,} controlled generation tokens on H20 and "
        f"{a800['controlled']['equal_tokens_each']:,} on A800. Its latency estimate conditions on the frozen lengths and votes. "
        f"Newly generated text was excluded from scoring. The server used vLLM {h20['vllm']['version']} on H20 and "
        f"{a800['vllm']['version']} on A800. Each comparison pairs policies within one card and software stack.")
    return (first+"\n".join(row_lines)+r"""
\bottomrule\end{tabular}
\end{table}

"""+fixed_desc+"\n\nIn natural generation, the numbers of refill outputs differing from the corresponding full-panel outputs were "
            +", ".join(coupling[:-1])+", and "+coupling[-1]
            +r""". The Transformers check compares generated token IDs. The serving check compares returned generation text. These differences limit the interpretation of sampled wall times as an effect of admission alone.

\begin{table}[htbp]\centering\small
\caption{Resource calibration with BF16 weights. Decode throughput uses a 512-token prefix, 32 cached decode steps and the median of three timed trials. Decode peak shows allocated device memory at batch size 16. Training used a full-parameter AdamW step, one synthetic 512-token sequence per step, one warmup and three timed steps. Training throughput counts input tokens. No updated checkpoint entered the scheduling runs.}
\label{tab:resource-gpus}
\begin{tabular}{lrr r rr}\toprule
 & \multicolumn{2}{c}{Decode (tokens/s)} & Decode peak & Train (tokens/s) & Train peak \\
GPU & Batch 1 & Batch 16 & GiB & Batch 1 & GiB \\\midrule
"""+"\n".join(profile_lines)+"\n\\bottomrule\\end{tabular}\n\\end{table}\n")


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--raw",type=Path,default=ROOT/"release/hardware/raw")
    parser.add_argument("--evidence",type=Path,default=ROOT/"evidence/gpu")
    parser.add_argument("--output",type=Path,default=ROOT/"release/hardware")
    parser.add_argument("--tex",type=Path,default=HERE/"hardware.tex")
    args=parser.parse_args()
    cards,rows={},[]
    for name in ("h20","a800"):
        card,ledger=load_card(name,directories(name,args.raw,args.evidence))
        cards[name]=card
        rows.extend(ledger)
    profile_hash=cards["h20"]["hf"]["input_sha256"].get("trials.jsonl")
    if profile_hash is None or any(card["controlled"]["trial_metadata"]["profile_sha256"]!=profile_hash
                                   for card in cards.values()):
        raise ValueError("Both controlled runs must use the archived full H20 HF trials.")
    if cards["h20"]["controlled"]["equal_tokens_each"]!=cards["a800"]["controlled"]["equal_tokens_each"]:
        raise ValueError("The frozen workload cost differs across cards.")
    section=render_section(cards)
    args.output.mkdir(parents=True,exist_ok=True)
    (args.output/"summary.json").write_text(json.dumps(cards,ensure_ascii=False,indent=2,allow_nan=False),encoding="utf-8")
    with (args.output/"panels.csv").open("w",newline="",encoding="utf-8") as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    args.tex.write_text(section,encoding="utf-8")
    print(f"Verified {len(rows)} policy observations and wrote {args.tex}")


if __name__=="__main__":
    main()
