# Reproducing the finite-panel scheduling study

The default run uses a CPU, Python 3.10, and the included measurements. From the extracted directory, run

```bash
python -m venv .venv
```

Activate the environment, then run

```bash
python -m pip install -r requirements.txt
python reproduce.py --out results
```

Choose a fresh output directory for each run. The program checks file integrity, regenerates Figures 1–2, compares Tables 1–5 with the manuscript values, and writes `results/verification.json`. The source figure program also writes regenerated files into `manuscript/`.

| Output | Input and verification |
|---|---|
| `table1.tex`, `figure1.pdf`, `figure2.pdf` | `manuscript/figures.py` simulates the four-path example and uses development measurements from 360 BRUMO panels. |
| `table2.tex` | The bootstrap analysis starts from numeric costs of individual validation panels, gives each of ten questions equal weight, and checks all point estimates and intervals. |
| `table3.csv` | The scheduling code replays all policies using 960 AIME path lengths and parsed votes. It checks paired contrasts at all four panel-size and slot-count combinations. |
| `tables4-5.tex`, `gpu/panels.csv`, `gpu/summary.json` | The two GPU runs supply per-trial latencies and per-path token or output records. The analysis verifies the per-seed coupling tallies, full controlled path lengths and votes, and the shared H20 reference workload. |
| `finite/`, `oracle/` | The two standard-library programs check the serial-prefix theorem against finite panels and alternative schedules. |

The 1,920 BRUMO development paths and ten additional validation questions came from the public MARS release. BRUMO reproduction starts from recorded numerical costs. The AIME reproduction starts from parsed integers and lengths. To rebuild those inputs directly from the public AIME completion files, run `python tracks/heldout/evaluate.py aime-from-source`. This optional command verifies its frozen code and source hashes, downloads the four pinned input shards, and reruns the original evaluation. The default analysis uses offline files. Provenance and terms are in `SOURCES.md`.

For new GPU measurements, use the scripts under `tracks/scheduling/live` with a local Qwen2.5-1.5B-Instruct checkpoint. The HF batch experiment used Transformers 4.40.1. The vLLM servers used 0.7.3 on H20 and 0.8.5 on A800. Use the appropriate per-card environment and inspect `--help` for each script. Example commands on a compatible Linux host are

```bash
python tracks/scheduling/live/hf_panel.py --model /path/to/model --out new-hf --device cuda:0 --dtype bfloat16 --attn sdpa --questions 6 --repeats 3 --n 8 --slots 4 --max-tokens 160 --temperature 0.7
python tracks/scheduling/live/serve_measure.py --model /path/to/model --out new-server --repeats 3
python tracks/scheduling/live/serve_measure.py --model /path/to/model --out new-controlled --repeats 3 --controlled-profile release/hardware/raw/h20/hf/trials.jsonl
```

Keep the archived H20 profile fixed when repeating the reported controlled experiment on either card. Exact latency depends on the serving stack and hardware.
