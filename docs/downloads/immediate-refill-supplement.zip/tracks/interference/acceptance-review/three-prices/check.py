"""Finite check for the fixed three-start price family, using exact scaled costs."""

from fractions import Fraction
from functools import lru_cache
from itertools import product
import json


def times(lengths, price):
    scale = price.denominator
    costs = (0, scale, scale, price.numerator)

    @lru_cache(None)
    def solve(state):
        if len(state) == 3 and not any(state):
            return 0, 0
        choices = []
        for end in range(len(state), 4):
            running = state + lengths[len(state):end]
            width = sum(t > 0 for t in running)
            if width == 0:
                continue
            greedy, optimum = solve(tuple(max(0, t - 1) for t in running))
            choices.append((costs[width] + greedy, costs[width] + optimum))
        return choices[-1][0], min(optimum for _, optimum in choices)

    return solve(())


def check():
    result = {}
    for price in map(Fraction, ("2", "5/2", "3", "4", "6", "11")):
        ratios = [Fraction(*times(lengths, price))
                  for lengths in product(range(1, 7), repeat=3)]
        expected = (price + 1) / 2
        if max(ratios) != expected or Fraction(*times((2, 1, 1), price)) != expected:
            raise ValueError(f"Mismatch at price {price}")
        result[str(price)] = {"ordered_triples": len(ratios), "maximum": str(expected)}
    return result


if __name__ == "__main__":
    print(json.dumps(check(), indent=2))
