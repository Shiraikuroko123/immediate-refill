# When Is Immediate Refill Optimal for Parallel Voting?

Open `main.pdf` to read the paper. `main.md` contains the revised English text. The LaTeX source uses `refs.bib` and the official `icml2027.bst` for author–year citations. The package includes the appendices, seven figures, and ICML style files.

To rebuild after editing `main.md`, run the following commands from this directory with Python 3 and TeX Live. If editing `main.tex` directly, skip the Python command. The Python script regenerates `main.tex` from `main.md`.

```sh
python build_author_tex.py
pdflatex -halt-on-error main.tex
bibtex main
pdflatex -halt-on-error main.tex
pdflatex -halt-on-error main.tex
```

To redraw figures, install Matplotlib and make `pdflatex` available on the command path. The plotting scripts use Matplotlib's PGF backend with the TeX packages `pgf`, `helvet`, and `amssymb` to embed Type 1 fonts. Run `python make_timeline.py` for the scheduling timeline. The script uses the two schedules and the three width costs in the paper and computes the elapsed time shown for each schedule. To redraw the indexed admission workflow, run `python -B plots/workflow.py` from the same directory. This produces `indexed-workflow.pdf`.

Run `python -B plots/price_hull.py` to draw the example width-price curve and its least concave majorant in `price-hull.pdf`. The four empirical figures can be rebuilt from the included plotting inputs. Their commands and data are described in [the plotting guide](plots/README.md).
