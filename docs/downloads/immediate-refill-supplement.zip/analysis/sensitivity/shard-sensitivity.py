"""Recompute the corresponding retrospective sensitivity analysis. Use reproduce.py from the ZIP root."""

import csv
import hashlib
import json
import math
from collections import Counter, defaultdict
from itertools import combinations_with_replacement
from pathlib import Path
import argparse

parser = argparse.ArgumentParser(add_help=False)
parser.add_argument('--out-dir', type=Path, required=True)
run_out = parser.parse_args().out_dir
from statistics import mean


HERE = Path(__file__).resolve().parent
DATA = HERE.parents[1] / "tracks" / "interference"


def rows(path):
    with path.open(encoding="utf-8", newline="") as source:
        return list(csv.DictReader(source))


def main():
    root = DATA / "holdout"
    manifest = json.loads((root / "freeze.json").read_bytes())
    membership = {}
    for entry in manifest["selected"]:
        name = Path(entry["path"]).name
        raw = (root / "raw" / name).read_bytes()
        assert hashlib.sha1(f"blob {len(raw)}\0".encode() + raw).hexdigest() == entry["oid"]
        counts = Counter(json.loads(line)["problem_key"] for line in raw.splitlines())
        assert set(counts.values()) == {16} and len(counts) == 25
        assert not membership.keys() & counts.keys()
        membership.update(dict.fromkeys(counts, name))
    data = defaultdict(lambda: defaultdict(list))
    for row in rows(DATA / "information-baseline" / "results" / "questions.csv"):
        if row["cohort"] == "archive":
            data[row["comparator"]][membership[row["question"]]].append(100 * float(row["saving"]))
    assert set(data) == {"buffer", "bag", "prefix_bag"} and len(membership) == 200
    result = {}
    for policy, shards in sorted(data.items()):
        assert len(shards) == 8 and all(len(v) == 25 for v in shards.values())
        mus = [mean(shards[k]) for k in sorted(shards)]
        support = []
        for combo in combinations_with_replacement(range(8), 8):
            weight = math.factorial(8) // math.prod(math.factorial(n) for n in Counter(combo).values())
            support.append((sum(mus[i] for i in combo) / 8, weight))
        assert sum(w for _, w in support) == 8**8
        ordered = sorted(support)
        def quantile(numerator):
            cumulative = 0
            for value, weight in ordered:
                cumulative += weight
                if cumulative * 40 >= numerator * 8**8:
                    return value
        loo = [mean(mus[:i] + mus[i + 1:]) for i in range(8)]
        result[policy] = dict(question_mean_pct=mean(mus), shard_means_pct=mus,
                              exact_shard_bootstrap_95_pct=[quantile(1), quantile(39)],
                              leave_one_shard_out_pct=[min(loo), max(loo)])
    output = dict(unit="eight observed shards, sampled with replacement, 25 questions per shard",
                  scope="post-hoc descriptive sensitivity, no inference to new models or clocks",
                  units="percent relative to each comparator", contrasts=result)
    (run_out / "shard-sensitivity.json").write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
