"""Reconstruct every paired endpoint from the GSM8K pilot's engine records."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import random
from statistics import mean, median
import sys
from collections import Counter

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0,str(ROOT/"tracks/quota"))
from summarize import tally, earliest, target


def digest(data):
    return hashlib.sha256(data).hexdigest()


def validate(path, item, ref):
    data=path.read_bytes()
    row=json.loads(data)
    assert row["unique_id"]==item["unique_id"]
    expected_seed="gsm-reference-20261120" if row["condition"]=="fixed" or row["policy"]=="full" else "gsm-natural-20261120"
    assert row["seed_namespace"]==expected_seed
    assert row["reference_sha256"]==(digest(ref.read_bytes()) if ref else None)
    obs={}
    active=set()
    launches=[]
    cancellations=[]
    for step in sorted({e["step"] for e in row["events"]}):
        events=[e for e in row["events"] if e["step"]==step]
        for e in events:
            if e["kind"]=="complete":
                i=e["index"]
                active.remove(i)
                obs[i]=row["paths"][i]["vote"]
        new=[e["index"] for e in events if e["kind"]=="launch"]
        assert new==[e["index"] for e in events if e["kind"]=="reserve"]
        winner, gap=tally(obs.values())
        stop=any(e["kind"]=="stop" for e in events)
        if stop:
            assert not new
        else:
            allowed=target(row["policy"],row["quota"],obs)
            assert new==list(range(len(launches),allowed))
        for i in new:
            assert i==len(launches)
            launches.append(step)
            active.add(i)
        for e in events:
            if e["kind"]=="cancel":
                active.remove(e["index"])
                cancellations.append(e["index"])
        assert len(active)<=4
    assert not active and row["launched"]==len(launches)<=row["quota"]
    assert row["completed"]==len(obs) and row["canceled"]==len(cancellations)
    assert row["generation_tokens"]==sum(len(p["token_ids"]) for p in row["paths"])
    assert row["canceled_tokens"]==sum(len(row["paths"][i]["token_ids"]) for i in cancellations)
    assert row["winner"]==winner and row["final_gap"]==gap
    assert row["certified"]==(len(obs)==16 or gap>16-len(obs))
    for i,p in enumerate(row["paths"]):
        assert p["index"]==i
        assert p["token_sha256"]==digest(json.dumps(p["token_ids"],separators=(",",":")).encode())
        seed=int.from_bytes(hashlib.sha256(f"{expected_seed}/{item['unique_id']}/{i}".encode()).digest()[:4],"big")%(2**31-1)
        assert p["seed"]==seed
    return row,launches


def interval(values):
    rng=random.Random(81227)
    samples=sorted(mean(rng.choices(values,k=len(values))) for _ in range(20000))
    return [samples[499],samples[19499]]


def analyze(raw,out):
    items=json.loads((HERE/"selection.json").read_bytes())["questions"]
    rows=[]
    costs=Counter()
    timing=Counter()
    manifest={}
    reference_quality=[]
    for qid,item in enumerate(items):
        reference_path=raw/f"q{qid:02}-natural-full.json"
        ref,_=validate(reference_path,item,None)
        fullvotes={p["index"]:p["vote"] for p in ref["paths"]}
        ref_prefix=earliest(fullvotes)
        ref_quality=dict(qid=qid,winner=ref["winner"],gold=item["gold"],correct=ref["winner"]==item["gold"],
                         abstentions=sum(x is None for x in fullvotes.values()),
                         capped_paths=sum(p["finish_reason"]=="length" for p in ref["paths"]))
        reference_quality.append(ref_quality)
        costs["reference"]+=ref["generation_tokens"]
        timing["reference"]+=ref["wall_seconds"]
        for cond in ("fixed","natural"):
            job={}
            launch={}
            for arm in ("exact","buffer"):
                path=raw/f"q{qid:02}-{cond}-{arm}.json"
                job[arm],launch[arm]=validate(path,item,reference_path)
                if cond=="fixed":
                    assert job[arm]["launched"]<=ref_prefix+1
                    assert all(p["length"]==ref["paths"][p["index"]]["length"] and p["vote"]==fullvotes[p["index"]]
                               for p in job[arm]["paths"] if p["finished"])
                costs[cond+"-"+arm]+=job[arm]["generation_tokens"]
                timing[cond+"-"+arm]+=job[arm]["wall_seconds"]
            e,b=job["exact"],job["buffer"]
            assert (e["position"]<b["position"]) == (qid%4 in ((0,3) if cond=="fixed" else (0,1)))
            if cond=="fixed":
                assert e["winner"]==b["winner"] and e["certified"]==b["certified"]
            rows.append(dict(qid=qid,question_sha256=item["unique_id"],gold=item["gold"],condition=cond,
                             exact_s=e["wall_seconds"],buffer_s=b["wall_seconds"],saving=1-e["wall_seconds"]/b["wall_seconds"],
                             changed=int(launch["exact"]!=launch["buffer"]),
                             events_identical=int(e["events"]==b["events"]),exact_steps=e["steps"],buffer_steps=b["steps"],
                             exact_tokens=e["generation_tokens"],buffer_tokens=b["generation_tokens"],
                             exact_winner=e["winner"],buffer_winner=b["winner"],exact_correct=int(e["winner"]==item["gold"]),
                             buffer_correct=int(b["winner"]==item["gold"]),exact_abstained=int(e["winner"] is None),
                             buffer_abstained=int(b["winner"] is None),same_answer=int(e["winner"]==b["winner"]),
                             exact_certified=int(e["certified"]),buffer_certified=int(b["certified"])))
    stats={}
    for cond in ("fixed","natural"):
        subset=[r for r in rows if r["condition"]==cond]
        savings=[r["saving"] for r in subset]
        ci=interval(savings)
        mean_saved=mean(savings)
        changed=sum(r["changed"] for r in subset)
        stats[cond]=dict(n=len(savings),mean=mean_saved,median=median(savings),ci=ci,dispatch_changed=changed,
            event_identical=sum(r["events_identical"] for r in subset),wins=sum(v>0 for v in savings),
            losses=sum(v<0 for v in savings),ties=sum(v==0 for v in savings),
            faster_steps=sum(r["exact_steps"]<r["buffer_steps"] for r in subset),
            slower_steps=sum(r["exact_steps"]>r["buffer_steps"] for r in subset),
            same_answer=sum(r["same_answer"] for r in subset),
            arm_statistics={a:{k:sum(r[f"{a}_{k}"] for r in subset) for k in ("tokens","correct","abstained","certified","steps")}
                            for a in ("exact","buffer")},
            passes_primary_gate=(mean_saved>=.02 and ci[0]>0 and changed>0) if cond=="fixed" else None)
    for p in sorted(raw.glob("*.json")): manifest[p.name]=digest(p.read_bytes())
    out.mkdir(parents=True,exist_ok=False)
    for name,data in (("questions",rows),("references",reference_quality)):
        with (out/f"{name}.csv").open("x",encoding="utf8",newline="") as f:
            w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
    results=dict(freeze_sha256=digest((HERE/"freeze.json").read_bytes()),results=stats,generated_tokens=costs,
                 panel_seconds=timing,raw_sha256=manifest,
                 reference_correct=sum(x["correct"] for x in reference_quality),
                 reference_abstentions=sum(x["abstentions"] for x in reference_quality),
                 reference_truncations=sum(x["capped_paths"] for x in reference_quality))
    (out/"summary.json").write_text(json.dumps(results,indent=2)+"\n",encoding="utf8")
    print(json.dumps(stats,indent=2))


if __name__=="__main__":
    if not __debug__: raise ValueError("Use Python without -O")
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--raw",type=Path,required=True)
    p.add_argument("--out",type=Path,required=True)
    args=p.parse_args()
    analyze(args.raw,args.out)
