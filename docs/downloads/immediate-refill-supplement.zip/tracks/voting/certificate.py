"""Adversarial changes to an open-label, unweighted plurality.

Input groups contain each current answer's trace switch probabilities.
Ties at the endpoint are treated as failure. The exact result refers to the
existence of a damaging assignment *after* the switch indicators are realized.
"""
import math

import numpy as np


def switch_counts(probabilities):
    mass = np.array([1.0])
    for p in probabilities:
        if not 0 <= p <= 1 or not math.isfinite(p):
            raise ValueError("Expected switch probabilities in [0, 1]")
        mass = np.convolve(mass, [1 - p, p])
    return mass


def _groups(groups):
    if not groups or any(len(group) == 0 for group in groups):
        raise ValueError("At least one nonempty group is required; omit empty groups")
    groups = sorted(groups, key=len, reverse=True)
    return [switch_counts(group) for group in groups]


def joint_risk(groups):
    """One minus the probability that every destination assignment is safe."""
    masses = _groups(groups)
    leader = len(masses[0]) - 1
    num_other = sum(len(mass) - 1 for mass in masses[1:])
    safe = 0.
    # For l leader flips and t other flips, h = leader - 2*l - t.
    # The unseen answer imposes h>0. Each rival needs size - 2*f < h.
    for h in range(1, leader + 1):
        poly = np.array([1.0])
        for mass in masses[1:]:
            size = len(mass) - 1
            lo = max(0, (size - h) // 2 + 1)
            allowed = mass.copy()
            allowed[:lo] = 0.
            poly = np.convolve(poly, allowed)
        for leader_flips, prob in enumerate(masses[0]):
            other_flips = leader - 2 * leader_flips - h
            if 0 <= other_flips <= num_other:
                safe += prob * poly[other_flips]
    return float(np.clip(1. - safe, 0., 1.))


def top_rival_risk(groups):
    """Track the largest rival explicitly and let other rivals keep all votes.

    The unseen rival remains eligible. This is conservative because a switched
    path cannot retain its old vote, even when it belonged to a smaller rival.
    """
    masses = _groups(groups)
    leader = len(masses[0]) - 1
    rival = masses[1] if len(masses) > 1 else np.ones(1)
    n_rival = len(rival) - 1
    n_third = len(masses[2]) - 1 if len(masses) > 2 else 0
    remainder = np.ones(1)
    for mass in masses[2:]:
        remainder = np.convolve(remainder, mass)
    tail = np.r_[remainder[::-1].cumsum()[::-1], 0.]
    risk = 0.
    for l, p_l in enumerate(masses[0]):
        for f, p_f in enumerate(rival):
            required = leader - 2 * l - f - max(n_rival - 2 * f, n_third)
            risk += p_l * p_f * tail[min(max(required, 0), len(remainder))]
    return float(np.clip(risk, 0., 1.))


def baselines(groups):
    """Exact marginal union, coarser total-flip bound, MARS theorem log bound."""
    groups = sorted(groups, key=len, reverse=True)
    masses = _groups(groups)
    sizes = [len(m) - 1 for m in masses]
    n = sum(sizes)
    active = max(1, sum(q > 0 for g in groups for q in g))
    # Threat from any specific rival. Use an extra zero-count rival for
    # all unseen answers. Shifts represent signed integer margin changes.
    risks, hoeff = [], []
    for rival in range(1, len(groups) + 1):
        size = sizes[rival] if rival < len(groups) else 0
        margin = sizes[0] - size
        poly = np.array([1.0])
        origin = 0
        mean = 0.
        for i, (group, mass) in enumerate(zip(groups, masses)):
            weight = 2 if i == 0 else -1 if i == rival else 1
            if weight == 2:
                factor = np.zeros(2 * len(mass) - 1)
                factor[::2] = mass
            elif weight == -1:
                origin -= len(mass) - 1
                factor = mass[::-1]
            else:
                factor = mass
            mean += weight * sum(group)
            poly = np.convolve(poly, factor)
        risks.append(sum(poly[max(0, margin - origin):]))
        # MARS Cor. 2.5 uses delta/N per tested challenger.
        hoeff.append(math.exp(-max(0., margin - mean) ** 2 / (2 * active)))
    total = np.array([1.])
    for mass in masses:
        total = np.convolve(total, mass)
    gap = sizes[0] - (sizes[1] if len(sizes) > 1 else 0)
    return {
        "marginal_union": min(1., sum(risks)),
        "total_flips": float(sum(total[(gap + 1) // 2:])),
        "mars_theorem": min(1., n * max(hoeff)),
    }
