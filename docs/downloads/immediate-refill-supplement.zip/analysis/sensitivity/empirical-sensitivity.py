"""Recompute the corresponding retrospective sensitivity analysis. Use reproduce.py from the ZIP root."""
import csv
import json
import random
from collections import defaultdict
from itertools import permutations
from pathlib import Path
import argparse

parser = argparse.ArgumentParser(add_help=False)
parser.add_argument('--out-dir', type=Path, required=True)
run_out = parser.parse_args().out_dir
from statistics import mean, median

import numpy as np


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
STUDY = ROOT / "tracks/interference"


def records(path):
    return [json.loads(line) for line in path.read_bytes().splitlines()]


def table(path):
    with path.open(encoding="utf-8", newline="") as file:
        return list(csv.DictReader(file))


def cost_reduction(baseline, candidate):
    return 100 * (1 - candidate / baseline)


def device_blocks():
    folder = STUDY / "prospective-device/session01"
    cal = [row for row in records(folder / "calibrate.jsonl") if row["event"] == "trial"]
    arms = {(r["block"], r["panel"], r["arm"]): r
            for r in records(folder / "validate.jsonl") if r["event"] == "trial"}
    clocks = [median(r["ms_per_step"] for r in cal if r["width"] == w) for w in (1, 2, 3)]
    c1, c2, c3 = clocks
    output = {"clock_ms": clocks, "calibration_rows": len(cal), "validation_rows": len(arms)}
    for panel, pred in (("witness", cost_reduction(c3 + c1, 2 * c2)),
                        ("control", cost_reduction(c2, 2 * c1))):
        values, by_order = [], defaultdict(list)
        recorded_step_counts = defaultdict(set)
        for b in range(12):
            imm, delay = [arms[b, panel, k] for k in ("immediate", "staged")]
            assert imm["token_counts"] == delay["token_counts"] and imm["token_hashes"] == delay["token_hashes"]
            for row in (imm, delay):
                recorded_step_counts[row["arm"]].add(len(row["steps"]))
            val = cost_reduction(imm["wall_ns"], delay["wall_ns"])
            values.append(val)
            by_order["immediate_first" if imm["pos"] < delay["pos"] else "staged_first"].append(val)
        ordered = sorted(values)
        output[panel] = dict(predicted_pct=pred, median_pct=median(values),
                             range_pct=[min(values), max(values)],
                             within_session_interval_pct=[ordered[2], ordered[9]],
                             engine_step_counts_observed={k: sorted(v) for k, v in recorded_step_counts.items()},
                             order_stratified_medians_pct={k: median(v) for k, v in by_order.items()})
    return output


def question_trials():
    folder = STUDY / "gsm_live/raw"
    fixed = []
    for q in range(16):
        e, b = [json.loads((folder / f"q{q:02d}-fixed-{a}.json").read_bytes()) for a in ("exact", "buffer")]
        changed = [r["launch_step"] for r in e["paths"]] != [r["launch_step"] for r in b["paths"]]
        fixed.append((changed, cost_reduction(b["wall_seconds"], e["wall_seconds"])))
    vals = [x for _, x in fixed]
    rng = random.Random(81227)
    samples = sorted(sum(rng.choices(vals, k=len(vals))) / len(vals) for _ in range(20000))
    output = dict(n=len(vals), mean_pct=mean(vals), question_bootstrap_pct=[samples[499], samples[19499]])
    for changed in (False, True):
        group = [x for c, x in fixed if c == changed]
        output["changed" if changed else "unchanged"] = {"n": len(group), "mean_pct": mean(group)}
    cap_values = []
    for q in range(32):
        effects = []
        for cap in (384, 1024):
            e, b = [json.loads((STUDY / f"cap-diagnostic/raw/q{q:02d}-{cap}-{a}.json").read_bytes())
                    for a in ("exact", "buffer")]
            effects.append(cost_reduction(b["wall_seconds"], e["wall_seconds"]))
        cap_values.append(effects[1] - effects[0])
    draws = np.random.default_rng(3841024).integers(32, size=(20000, 32))
    cap_ci = np.quantile(np.array(cap_values)[draws].mean(axis=1), [.025, .975])
    leave_out = [mean(cap_values[:i] + cap_values[i + 1:]) for i in range(32)]
    return {"fixed_16": output, "cap_32": {"paired_mean_pp": mean(cap_values), "interval_pp": cap_ci.tolist(),
                                         "omit_one_range_pp": [min(leave_out), max(leave_out)]}}


def archive():
    paths = defaultdict(dict)
    for shard in (STUDY / "holdout/raw").glob("*.jsonl"):
        for row in records(shard):
            paths[row["problem_key"]][row["rollout_index"]] = row["output_tokens"]
    assert len(paths) == 200 and all(set(v) == set(range(16)) for v in paths.values())
    rows = [r for r in table(STUDY / "holdout/results/questions.csv")
            if r["context"] == "3968" and r["arm"] == "indexed_vs_buffer"]
    assert {r["question"] for r in rows} == set(paths)
    def delta(r):
        return float(r["base_time"]) - float(r["time"])
    def describe(group):
        return {"n": len(group), "mean_pct": mean(cost_reduction(float(r["base_time"]), float(r["time"])) for r in group),
                "pooled_pct": cost_reduction(sum(float(r["base_time"]) for r in group), sum(float(r["time"]) for r in group))}
    rows.sort(key=delta, reverse=True)
    top = [{"question": r["question"], "longest_path_tokens": max(paths[r["question"]].values()),
            "modeled_seconds_saved": delta(r)} for r in rows[:2]]
    b = [r for r in rows if max(paths[r["question"]].values()) <= 8192 - 3968]
    oracle_rows = [r for r in table(STUDY / "holdout/results/questions.csv")
                   if r["context"] == "3968" and r["arm"] == "oracle_one"]
    gains = [cost_reduction(float(r["base_time"]), float(r["time"])) for r in oracle_rows]
    return (dict(full=describe(rows), excluding_top_two=describe(rows[2:]), top_two=top,
                 top_two_share_of_summed_gain_pct=100 * sum(delta(r) for r in rows[:2]) / sum(delta(r) for r in rows),
                 max_output_at_most_4224=describe(b),
                 one_wait_oracle={"mean_pct": mean(gains), "exceed_one_percent": sum(g > 1 for g in gains)}), paths)


def length_prevalence(paths, clock):
    # Apply the same two actions to all ordered triples from each 16-path panel.
    # Equal weight per question, not treating permutations as independent samples.
    lengths = np.array([[row[i] for i in range(16)] for row in paths.values()])
    triples = np.array(list(permutations(range(16), 3)))
    a, b, c = [lengths[:, triples[:, j]] for j in range(3)]
    lo, hi = np.minimum(np.minimum(a, b), c), np.maximum(np.maximum(a, b), c)
    mid = a + b + c - lo - hi
    c1, c2, c3 = clock
    imm = (hi - mid) * c1 + (mid - lo) * c2 + lo * c3
    gap = abs(a - b)
    staged = abs(gap - c) * c1 + (np.minimum(a, b) + np.minimum(gap, c)) * c2
    scores = cost_reduction(imm, staged)
    return {"ordered_triples_per_question": len(triples),
            "original_first_three_oracle_pct": float(np.maximum(scores[:, 0], 0).mean()),
            "all_ordered_triples_oracle_pct": float(np.maximum(scores, 0).mean())}


if __name__ == "__main__":
    device = device_blocks()
    summary, paths = archive()
    result = {"scope": "Retrospective audit. Percentages are relative latency savings unless marked pp.",
              "device": device, **question_trials(), "gsm8k_archive": summary,
              "two_action_length_sensitivity": length_prevalence(paths, device["clock_ms"])}
    out = run_out / "empirical-sensitivity.json"
    out.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(out)
