"""Reproduce the four development folds with zero held-question warmup."""
import argparse
import csv
import hashlib
import io
import json
from pathlib import Path
import random
import re
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "replay"))
import replay


def audit_accuracy(prediction, truth):
    def normalize(value):
        if value is None:
            return None
        value = value.replace(r"\dfrac", r"\frac")
        power = re.fullmatch(r"(\d{1,3})\^\{(\d{1,3})\}", value)
        if power:
            return str(int(power[1]) ** int(power[2]))
        return replay.answer(value)
    return replay.correctness(normalize(prediction), normalize(truth))


def stable_rule(panel, state_rows, det_row):
    n = len(panel)
    previous = None
    answer = None
    for state in state_rows:
        if not state["before_deterministic"]:
            break
        leader = state.get("leader")
        if state["status"] != "ok" or 4*len(state["votes"][leader]) < 3*n:
            previous = None
            continue
        if previous == leader:
            answer = leader
            position = state["position"]
            break
        previous = leader
    row = dict(det_row, method="share75_two")
    if answer is not None:
        row.update(stop="probe", stop_position=position, prediction=answer)
        row["main_tokens"] = sum(min(t["length"],position) for t in panel)
        row["saved_tokens"] = row["full_tokens"]-row["main_tokens"]
        row["disagrees"] = int(answer != row["full_prediction"])
        row["early_nonunique_or_disagrees"] = int(row["disagrees"] or not row["final_unique"])
    last = row["stop_position"] if row["stop"] == "probe" else row["stop_position"]-1
    row["probe_calls"] = sum(min(last,t["length"]-1)//replay.STEP for t in panel)
    return row


def aggregate(records, training):
    groups = {}
    for record in records:
        key = (record["qid"],record["n"],record["method"])
        groups.setdefault(key,[]).append(record)
    results = []
    for (qid, width, method), rows in groups.items():
        sum_key = lambda key: sum(r[key] for r in rows)
        known = [r["accuracy"] for r in rows if r["accuracy"] is not None]
        fit_cost = training[qid] if method in replay.MODELED else dict(main_tokens=0,probe_calls=0)
        for price in (0,25,50):
            online = sum_key("saved_tokens") - price * sum_key("probe_calls")
            training_cost = fit_cost["main_tokens"] + price * fit_cost["probe_calls"]
            results.append(dict(qid=qid,n=width,method=method,price=price,panels=len(rows),
                                full_tokens=sum_key("full_tokens"),online_main_tokens=sum_key("main_tokens"),
                                online_probes=sum_key("probe_calls"),net_online_saved=online,
                                train_main_tokens=fit_cost["main_tokens"],train_probes=fit_cost["probe_calls"],
                                net_saved_with_fold_training=online-training_cost,disagrees=sum_key("disagrees"),
                                correct=sum(known),accuracy_known=len(known),accuracy_unknown=len(rows)-len(known)))
    return results


def main(source, output):
    started = time.perf_counter()
    output.mkdir(parents=True,exist_ok=False)
    data = {q:{} for q in range(4)}
    with source.open(encoding="utf-8") as stream:
        for line in stream:
            raw = json.loads(line)
            qid = int(raw["qid"])
            trace = replay.prepare(raw)
            idx = trace["index"]
            if qid not in data or not 0 <= idx < 512 or idx in data[qid]:
                raise ValueError("Unexpected question or trace id")
            data[qid][idx] = trace
    if any(set(question) != set(range(512)) for question in data.values()):
        raise ValueError("Missing development traces")
    training, panels, q_scores, fit = {}, [], [], []
    with (output/"states.jsonl").open("w",encoding="utf-8") as checkpoints:
        for qid, traces in data.items():
            train_qids = [q for q in data if q!=qid]
            warmup = [data[q][i] for q in train_qids for i in range(32)]
            rate, probes, totals, classes = replay.warmup_model(warmup)
            training[qid] = dict(qid=qid,training_qids=train_qids,trace_count=len(warmup),
                                 main_tokens=sum(t["length"] for t in warmup),probe_calls=probes)
            for (position, cls),(switches,count) in sorted(classes.items()):
                fit.append(dict(qid=qid,pos=position,cls=cls,switches=switches,count=count,
                                total_switches=totals[position][0],total_count=totals[position][1],
                                q=rate(position,cls)))
            indices = list(range(32,512))
            random.Random(137+qid).shuffle(indices)
            for width in (8,16):
                for start in range(0,len(indices),width):
                    panel=[traces[i] for i in indices[start:start+width]]
                    buffer=io.StringIO()
                    rows=replay.run_panel(qid,panel,start//width,rate,buffer)
                    states=buffer.getvalue()
                    checkpoints.write(states)
                    deterministic=next(row for row in rows if row["method"]=="deterministic")
                    rows.append(stable_rule(panel,[json.loads(s) for s in states.splitlines()],deterministic))
                    for row in rows:
                        row["accuracy"]=audit_accuracy(row["prediction"],panel[0]["truth"])
                    panels.extend(rows)
            for idx in indices:
                t=traces[idx]
                for pos in range(replay.STEP,t["length"],replay.STEP):
                    current=t["probes"].get(pos)
                    if current is not None:
                        hist=replay.history(t,pos,current)
                        q_scores.append(dict(qid=qid,index=idx,pos=pos,cls=hist,q=rate(pos,hist),
                                             changed=int(t["final"]!=current)))
    replay.writecsv(output/"panels.csv",panels)
    replay.writecsv(output/"per_question_costs.csv",aggregate(panels,training))
    replay.writecsv(output/"training.csv",list(training.values()))
    replay.writecsv(output/"fitted_rates.csv",fit)
    replay.writecsv(output/"q_assessment.csv",q_scores)
    paths = (source,Path(__file__),HERE/"PROTOCOL.md",Path(replay.__file__),HERE.parent/"certificate.py")
    hashes = {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    manifest = dict(elapsed_seconds=time.perf_counter()-started,panel_rows=len(panels),sha256=hashes)
    (output/"manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")
    print(json.dumps(manifest))


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--data",type=Path,default=HERE.parent/"data_access/traces.jsonl")
    parser.add_argument("--out",type=Path,required=True)
    args=parser.parse_args()
    main(args.data,args.out)
