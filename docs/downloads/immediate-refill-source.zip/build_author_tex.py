"""Typeset the author's English Markdown with the local ICML style and figure PDFs."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
FIGURES = ["refill-timeline", "indexed-workflow", "price-hull", "transfer-blocks", "admission-gains", "evidence", "cap-comparison"]
PREAMBLE = r'''\documentclass{article}
\PassOptionsToPackage{hypertexnames=false}{hyperref}
\usepackage[T1]{fontenc}
\usepackage{microtype,graphicx,booktabs,hyperref}
\usepackage{icml2027}
\usepackage{amsmath,amssymb,tabularx,array,placeins}
\usepackage{xurl}
\setlength{\bibhang}{10pt}
\newcolumntype{L}{>{\raggedright\arraybackslash}X}
\newcolumntype{C}{>{\centering\arraybackslash}X}
\icmltitlerunning{When Is Immediate Refill Optimal for Parallel Voting?}
\begin{document}
\twocolumn[
\icmltitle{When Is Immediate Refill Optimal for Parallel Voting?}
\begin{icmlauthorlist}
\icmlauthor{Anonymous Authors}{anon}
\end{icmlauthorlist}
\icmlaffiliation{anon}{Anonymous Institution}
\icmlcorrespondingauthor{Anonymous Author}{anonymous@example.org}
\icmlkeywords{test-time computation, adaptive inference, scheduling, parallel voting}
\vskip 0.3in
]
\printAffiliationsAndNotice{}
'''

def escape(s):
    chars = {'\\': r'\textbackslash{}', '&': r'\&', '%': r'\%', '_': r'\_', '#': r'\#', '{': r'\{', '}': r'\}', '−': r'\ensuremath{-}', '≤': r'\ensuremath{\le}', '~': r'\textasciitilde{}'}
    return ''.join(chars.get(c,c) for c in s)

# Keep the author/year citations readable in the Markdown. BibTeX controls the
# printed names, bibliography order, and links in the review PDF.
CITATIONS = {
    "Badita et al., 2020": "badita2020stragglers",
    "Baccelli et al., 1989": "baccelli1989rr",
    "Baccelli et al., 1993": "baccelli1993extremal",
    "Chang & Yao, 1993": "chang1993rearrangement",
    "Chen et al., 2026": "mars",
    "Cicalese et al., 2011": "cicalese",
    "Cobbe et al., 2021": "gsm8k",
    "Cucu-Grosjean & Goossens, 2010": "cucu2010",
    "Dolev & Warmuth, 1985": "dolev1985profile",
    "EleutherAI, 2024": "eleuther2024gsm64",
    "Graham, 1969": "graham1969timing",
    "Guenther, 2004": "curtail",
    "Hampson & Jennison, 2013": "Hampson_2012",
    "He et al., 2024": "he2024olympiadbench",
    "Jäger et al., 2025": "jaeger2025",
    "Jeong et al., 2026": "jeong2026specscale",
    "Jiang et al., 2025": "duchess",
    "LangChain, 2026": "langchainlimit",
    "Li & Li, 2026": "recover",
    "Liu & Sanlaville, 1995": "liu1995det",
    "Liu & Sanlaville, 1997": "liu1997variable",
    "Möhring et al., 2004": "moehring2004",
    "Ni et al., 2017": "Ni_2017",
    "Pydantic, 2026": "pydanticlimit",
    "Ryser, 1957": "ryser1957",
    "Segev & Shaposhnik, 2022": "Segev_2022",
    "Wang et al., 2026": "wang2026cues",
    "Wang et al., 2023": "wang2023sc",
    "Xiong et al., 2026": "atts",
    "Yang et al., 2024": "yang2024testing",
    "Zhong et al., 2026": "zhong2026spex",
}
_AUTHORS = "|".join(re.escape(s) for s in sorted({s.rsplit(", ", 1)[0] for s in CITATIONS}, key=len, reverse=True))
_YEAR = r"(?:19|20)\d{2}"
_CITE = re.compile(rf"(?P<narrative>{_AUTHORS}) \((?P<year>{_YEAR})(?:, (?P<note>[^()]+))?\)"
                   rf"|\((?P<group>(?:{_AUTHORS}), {_YEAR}[^()]*)\)")


def cite_text(text):
    """Turn complete author/year groups into natbib commands, retaining locators."""
    pieces = []
    cursor = 0
    for match in _CITE.finditer(text):
        pieces.append(escape(text[cursor:match.start()]))
        if match["narrative"]:
            keys = [CITATIONS[f'{match["narrative"]}, {match["year"]}']]
            command = r"\citet"
            note = match["note"]
        else:
            keys = []
            note = None
            command = r"\citep"
            for item in match["group"].split("; "):
                author, year, *suffixes = item.split(", ")
                keys.append(CITATIONS[f"{author}, {year}"])
                for suffix in suffixes:
                    if re.fullmatch(_YEAR, suffix):
                        keys.append(CITATIONS[f"{author}, {suffix}"])
                    elif len(keys) == 1 and "; " not in match["group"]:
                        note = suffix
                    else:
                        raise ValueError(f"Ambiguous citation locator in {match[0]}")
        if note:
            command += "[" + escape(note) + "]"
        pieces.append(command + "{" + ",".join(keys) + "}")
        cursor = match.end()
    pieces.append(escape(text[cursor:]))
    return "".join(pieces)

INLINE = re.compile(r'(\$[^$\n]+?\$|`[^`]+`|\*\*[^*]+?\*\*|\*[^*]+?\*|https?://[^\s)`]+)')

def inline(s):
    result=[]
    for part in INLINE.split(s):
        if not part:continue
        if part.startswith('$') and part.endswith('$'): result.append(re.sub(r'(?<!\\)%',r'\\%',part.replace('−','-')))
        elif part.startswith('`'):
            item=part[1:-1]
            result.append((r'\url{'+item+'}') if item.startswith('http') else (r'\texttt{'+escape(item)+'}'))
        elif part.startswith('**'):result.append(r'\textbf{'+inline(part[2:-2])+'}')
        elif part.startswith('*'):result.append(r'\emph{'+inline(part[1:-1])+'}')
        elif part.startswith('http'):
            url=part.rstrip('.,');result.append(r'\url{'+url+'}'+part[len(url):])
        else: result.append(cite_text(part))
    return ''.join(result)

def figure_line(index,caption):
    env='figure*' if index in (2,4) else 'figure'
    placement='[t]' if index<6 else '[H]'
    width={1:'.96',2:'.9',3:'.91',4:'.86',5:'.94',6:'.96',7:'.97'}[index]
    return '\n'.join([r'\begin{'+env+'}'+placement,r'\centering\includegraphics[width='+width+r'\linewidth]{'+FIGURES[index-1]+'.pdf}',r'\caption{'+inline(caption)+r'}\label{fig:md'+str(index)+'}',r'\end{'+env+'}'])

def table_block(rows,number,caption):
    # Width allocation leaves descriptive first columns and wraps full authored headings.
    headers=rows[0];n=len(headers)
    if number==0:
        fmt='@{}lL@{}'
    elif number==1:fmt='@{}Lrrrr@{}'
    elif number==2:fmt=r'@{}l r C C C@{}'
    elif number==3:fmt=r'@{}L c C c c@{}'
    elif number in (4,5,6):fmt='@{}l'+'r'*(n-1)+'@{}'
    else:raise ValueError(number)
    isfloat=number!=0
    lines=[(r'\begin{table}'+('[tb]' if number<=3 else '[H]')+r'\centering') if isfloat else r'\begin{center}']
    if isfloat:lines.append(r'\caption{'+inline(caption)+r'}\label{tab:md'+str(number)+'}')
    else:lines.append(r'\textbf{Notation}\par\smallskip')
    lines.append(r'\small\setlength{\tabcolsep}{3pt}')
    if number<4:lines.append(r'\begin{tabularx}{\linewidth}{'+fmt+r'}\toprule')
    else:lines.append(r'\begin{tabular}{'+fmt+r'}\toprule')
    for i,row in enumerate(rows):lines.append(' & '.join(inline(cell) for cell in row)+r'\\'+(r'\midrule' if i==0 else ''))
    lines.append(r'\bottomrule\end{'+('tabularx' if number<4 else 'tabular')+'}')
    lines.append(r'\end{table}' if isfloat else r'\end{center}')
    return '\n'.join(lines)

def display(body):
    # Align the recurring relation signs in the longer chains.
    if body.startswith('T_G(c) '):
        body=body.replace(r' \le T_G(',r' &\le T_G(',1).replace(r' \le \gamma \sum',r' \\ &\le \gamma \sum',1)
        body=r'\begin{aligned}'+body+r'\end{aligned}'
    elif body.startswith(r'\int_E h_A') and r'\varepsilon' in body:
        body=body.replace(r' = \sum',r' &= \sum',1).replace(r' \le \int',r' \\ &\le \int',1)
        body=r'\begin{aligned}'+body+r'\end{aligned}'
    elif body.startswith(r'\frac{n_s}'):
        body=body.replace(' = L\\left',r' &= L\left',1).replace(r' = L \hat',r' \\ &= L \hat',1)
        body=r'\begin{aligned}'+body+r'\end{aligned}'
    env='equation' if r'\tag{' in body else 'equation*'
    return r'\begin{'+env+'}\n'+body.replace('−','-')+'\n'+r'\end{'+env+'}'

def render():
    src=(ROOT/'main.md').read_text(encoding='utf-8-sig').splitlines();assert src[0]=='# When Is Immediate Refill Optimal for Parallel Voting?'
    out=[PREAMBLE]; i=1;abstract=False;app=False;in_refs=False;tab=0;caption='';count_fig=count_refs=0
    while i<len(src):
        raw=src[i].strip();i+=1
        if not raw or raw=='---':continue
        if raw.startswith('## '):
            if abstract:out.append(r'\end{abstract}');abstract=False
            h=raw[3:]
            if h=='Abstract':out.append(r'\begin{abstract}');abstract=True;continue
            if h.startswith('Appendix ') and not app:out.append(r'\clearpage\appendix\onecolumn\raggedbottom');app=True
            if h.startswith('Appendix '):
                in_refs=False
                out.append(r'\refstepcounter{section}\section*{'+inline(h)+r'}\addcontentsline{toc}{section}{'+inline(h)+'}');continue
            if h=='References':
                in_refs=True
                out.extend([r'\FloatBarrier', r'\bibliographystyle{icml2027}', r'\bibliography{refs}'])
                continue
            in_refs=False
            if h in ('Impact Statement','AI Use Disclosure','AI Disclosure Statement'):out.append(r'\FloatBarrier\section*{'+inline(h)+'}');continue
            h=re.sub(r'^(?:[1-6] |Appendix [A-L]: )','',h);out.append(r'\section{'+inline(h)+'}');continue
        if raw.startswith('### '):
            _,h=raw[4:].split(' ',1);out.append(r'\subsection{'+inline(h)+'}');continue
        if raw.startswith('> **Figure'):
            m=re.fullmatch(r'> \*\*Figure (\d+)\*\*: (.+)',raw); idx=int(m[1]); count_fig+=1; assert idx==count_fig; out.append(figure_line(idx,m[2]));continue
        if raw.startswith('**Table '):
            m=re.fullmatch(r'\*\*Table (\d+)\*\*: (.+)',raw); tab=int(m[1]);caption=m[2];continue
        if raw.startswith('|'):
            rows=[]
            while raw.startswith('|'):
                cells=[c.strip() for c in raw.strip('|').split('|')]
                if not all(re.fullmatch(r':?-+:?',c) for c in cells):rows.append(cells)
                if i>=len(src) or not src[i].startswith('|'):break
                raw=src[i];i+=1
            out.append(table_block(rows,tab,caption)); continue
        if raw=='$$':
            end=src.index('$$',i);out.append(display('\n'.join(src[i:end])));i=end+1;continue
        if in_refs:
            # Markdown keeps a readable copy of the reference list. BibTeX
            # formats the PDF from the keys actually cited in the paper.
            count_refs += 1
            continue
        if re.fullmatch(r'\*\*[^*]+\*\*',raw) and i<len(src) and src[i].strip():
            raw+=' '+src[i].strip();i+=1
        out.append(inline(raw))
    assert (count_fig,tab,count_refs)==(7,6,len(CITATIONS))
    result='\n\n'.join(out)+r'\end{document}'+'\n'
    cited = {key for group in re.findall(r"\\cite[tp](?:\[[^]]+\])?\{([^}]+)\}", result) for key in group.split(",")}
    if cited != set(CITATIONS.values()):
        raise ValueError(f"Unmatched bibliography keys: {cited ^ set(CITATIONS.values())}")
    # Consecutive definitions form one display, with a separate right-hand tag on each row.
    result=re.sub(r'\\begin\{equation\}\n(M\(S\) =) (.*?)\n\\end\{equation\}\n\n\\begin\{equation\}\n(F\(S\) =) (.*?)\n\\end\{equation\}', lambda m: '\\begin{align}\n'+m[1][:-1]+'&= '+m[2]+r'\\'+'\n'+m[3][:-1]+'&= '+m[4]+'\n\\end{align}', result)
    # Display math continues the introducing sentence, without an empty TeX paragraph.
    result=re.sub(r'\n\n(?=\\begin\{(?:equation\*?|align)\})','\n',result)
    return result

if __name__=='__main__':
    (ROOT/'main.tex').write_text(render(),encoding='utf-8')
