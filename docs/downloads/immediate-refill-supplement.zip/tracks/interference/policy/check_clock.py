"""Check the step-price wall-time corollary for safe work-conserving delayed refill schedules."""
from collections import Counter
from functools import lru_cache
from itertools import product
import json
from pathlib import Path

from check_bound import gap, structurally_safe


CURVES = ((3,4,5), (5,4,3), (4,7,3), (6,2,5), (4,4,4))


def check(votes, lengths, quota, slots, h, prices):
    n = len(votes)
    def options(state):
        seen = {i:votes[i] for i,r in enumerate(state) if r==0}
        if gap(seen.values())>n-len(seen) or len(seen)==quota:
            return ()
        limit = structurally_safe(n,seen,slots,quota,1)
        variants = []
        for target in range(len(state) if state else limit,limit+1):
            active = state + lengths[len(state):target]
            width = sum(r>0 for r in active)
            if width:
                variants.append((int(target<limit), tuple(max(0,r-1) for r in active),prices[width-1]))
        return variants
    options=lru_cache(None)(options)

    state=()
    greedy_time=0
    while (choices:=options(state)):
        wait,state,inc=choices[-1]
        assert not wait
        greedy_time+=inc
    started,completed=len(state),state.count(0)

    @lru_cache(None)
    def extremes(s,left):
        choices=options(s)
        if not choices:
            return (0,0)
        lower,upper=float("inf"),0
        for charge,nxt,inc in choices:
            if charge<=left:
                lo,hi=extremes(nxt,left-charge)
                lower,upper=min(lower,lo+inc),max(upper,hi+inc)
        return lower,upper

    low,high=extremes((),h)
    applicable=prices[:slots]
    up=max([0]+[b-a for a,b in zip(applicable,applicable[1:])])
    down=max([0]+[a-b for a,b in zip(applicable,applicable[1:])])
    upper=h*(max(applicable)+completed*up+started*down)
    assert high-greedy_time<=upper
    return low<greedy_time,high>greedy_time,high-greedy_time==upper


if __name__=="__main__":
    if not __debug__:
        raise ValueError("Run with assertions enabled")
    counts=Counter()
    for n in (3,4):
        for votes in product(("A","B"),repeat=n):
            for lengths in product((1,2),repeat=n):
                for quota in (n-1,n):
                    for slots in (2,3):
                        for h in (1,2):
                            for curve in CURVES:
                                faster,slower,tight=check(votes,lengths,quota,slots,h,curve)
                                counts["cases"]+=1
                                counts["some_delay_faster"]+=faster
                                counts["some_delay_slower"]+=slower
                                counts["upper_attained"]+=tight
    print(json.dumps(dict(curves=CURVES,counts=counts),indent=2))
