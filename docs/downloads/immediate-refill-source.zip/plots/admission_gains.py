"""Draw the common-denominator decomposition for the 200 GSM8K questions.

Use --extract-from <tracks/interference> to regenerate the packaged data from
the original question-level records. The default mode draws from the local CSV.
"""
import argparse
import csv
import hashlib
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


# Let pdfLaTeX embed Type 1 fonts for both tick labels and math.
plt.rcParams.update({
    "pgf.texsystem": "pdflatex", "pgf.rcfonts": False,
    "pgf.preamble": r"\usepackage[T1]{fontenc}\usepackage{helvet,amssymb}",
    "font.family": "sans-serif",
})


HERE = Path(__file__).resolve().parent
DATA = HERE / "data" / "admission-gains.csv"
SOURCES = {
    "holdout/results/questions.csv":
        "b097d2eebe2c4c9021fcd008b35a929e23301154b8c52a12cf3fa2a9b6cc152c",
    "information-baseline/results/questions.csv":
        "6f21abfe8f252dc1d4b6018683b23da2d6d9140ada4780b291ab4de064f48170",
}


def records(path):
    with path.open(encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream))


def extract(study):
    for name, fingerprint in SOURCES.items():
        assert hashlib.sha256((study / name).read_bytes()).hexdigest() == fingerprint
    primary = [r for r in records(study / "holdout/results/questions.csv")
               if r["context"] == "3968" and r["arm"] == "indexed_vs_buffer"]
    runs = [r for r in records(study / "information-baseline/results/questions.csv")
            if r["cohort"] == "archive" and r["comparator"] == "prefix_bag"]
    middle = {r["question"]: r for r in runs}
    assert len(middle) == len(runs) == len(primary) == 200
    assert set(middle) == {r["question"] for r in primary}
    with DATA.open("w", encoding="utf-8", newline="") as stream:
        output = csv.writer(stream, lineterminator="\n")
        output.writerow(("question", "buffered_time", "prefix_multiset_time", "indexed_time"))
        for r in primary:
            matched = middle[r["question"]]
            np.testing.assert_allclose(float(r["time"]), float(matched["indexed_time"]),
                                       rtol=1e-13, atol=0)
            output.writerow((r["question"], r["base_time"], matched["comparator_time"], r["time"]))


def draw():
    data = records(DATA)
    assert len(data) == len({r["question"] for r in data}) == 200
    buffered, middle, indexed = (np.array([float(r[k]) for r in data])
                                 for k in ("buffered_time", "prefix_multiset_time", "indexed_time"))
    counts = 100 * (buffered - middle) / buffered
    indices = 100 * (middle - indexed) / buffered
    total = 100 * (1 - indexed / buffered)
    np.testing.assert_allclose(counts + indices, total, rtol=0, atol=3e-14)
    counts_mean, indices_mean, total_mean = (g.mean() for g in (counts, indices, total))
    means = np.random.default_rng(19431).choice(total, (10000, len(total))).mean(axis=1)
    lo, hi = np.quantile(means, [.025, .975])
    # All five values were published in the pre-figure baseline_results.json.
    np.testing.assert_allclose([counts_mean, indices_mean, total_mean, lo, hi],
                               [8.4099363390, .2986620617, 8.7085984007,
                                6.6118859857, 11.0199540470], rtol=0, atol=1e-9)

    plt.rcParams.update({"font.family": "sans-serif", "font.size": 8.2})
    fig = plt.figure(figsize=(3.25, 1.32))
    ax = fig.add_axes((.034, .31, .921, .68), xlim=(0, 12), ylim=(0, 2))
    ink, blue, orange = "#263944", "#305e78", "#aa542d"
    ax.text(0, 1.73, "Count out-of-prefix votes", va="center", color=ink)
    ax.text(11.97, 1.73, "Resolve their indices", va="center", ha="right", color=ink)
    ax.barh(1.16, counts_mean, height=.52, color=blue)
    ax.barh(1.16, indices_mean, left=counts_mean, height=.52,
            color=orange, edgecolor=ink, linewidth=.5)
    ax.text(counts_mean / 2, 1.16, f"{counts_mean:.2f}", ha="center", va="center",
            color="white", weight="bold")
    ax.text(total_mean + .29, 1.16, f"{indices_mean:.2f}", va="center", color=ink, weight="bold")
    ax.plot([counts_mean + indices_mean / 2] * 2, [1.42, 1.56], color=ink, lw=.75)
    ax.text(0, .36, f"Total saving   {total_mean:.2f}", color=ink, va="center", weight="bold")
    ax.errorbar(total_mean, .36, xerr=[[total_mean - lo], [hi - total_mean]],
                fmt="o", ms=4.5, color=ink, capsize=3, lw=1.1)
    ax.set_xticks((0, 3, 6, 9, 12))
    ax.set_xlabel("Modeled time saved vs. buffered (%)", labelpad=1.5, color=ink)
    ax.tick_params(axis="x", length=2.5, width=.6, pad=1.8, colors=ink)
    ax.set_yticks([])
    ax.spines[["left", "top", "right"]].set_visible(False)
    ax.spines["bottom"].set_color("#68777e")
    ax.spines["bottom"].set_linewidth(.6)
    fig.savefig(HERE.parent / "admission-gains.pdf",
                backend="pgf", metadata={"CreationDate": None, "ModDate": None})
    plt.close(fig)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--extract-from", type=Path)
    args = parser.parse_args()
    if args.extract_from:
        extract(args.extract_from)
    draw()
