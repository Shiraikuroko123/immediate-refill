"""Render the ten-question validation contrasts from the archived macro results."""
import csv
from pathlib import Path

source = Path(__file__).resolve().parent / "exact-recovered/schedule_macro.csv"
target = source.parents[3] / "manuscript/validation-table.tex"
with source.open(encoding="utf8", newline="") as stream:
    rows = {(int(r["n"]), int(r["capacity"]), r["chosen"], r["base"]): r
            for r in csv.DictReader(stream)}

lines = []
for n, cap in [(8, 4), (8, 8), (16, 4), (16, 16)]:
    rolling = rows[n, cap, "refill", "rolling"]
    fixed = rows[n, cap, "refill", "fixed"]
    value, low, high = (100 * float(rolling["time_savings" + suffix])
                        for suffix in ("", "_low", "_high"))
    work = 100 * float(fixed["work_savings"])
    time = 100 * float(fixed["time_savings"])
    lines.append(f"{n} & {cap} & {rolling['panels']} & {value:.2f} [{low:.2f}, {high:.2f}]"
                 f" & {work:.2f} & {time:.2f} " + r"\\")
lines.append(r"\bottomrule")
target.write_text("\n".join(lines) + "\n", encoding="ascii")
