"""Recompute the corresponding retrospective sensitivity analysis. Use reproduce.py from the ZIP root."""
import csv
import json
from itertools import product
from pathlib import Path
import argparse

parser = argparse.ArgumentParser(add_help=False)
parser.add_argument('--out-dir', type=Path, required=True)
run_out = parser.parse_args().out_dir
from runpy import run_path
from statistics import mean

HERE = Path(__file__).resolve().parent
oracle = run_path(str(HERE / "third-launch-oracle.py"))
costs = [0, *json.loads(oracle["CLOCK"].read_bytes())["clock_ms"]]


def grid_cost(a, b, c, start_tick):
    """Sum occupancy costs on quarter-ticks directly, independently of event sorting."""
    counts = [0, 0, 0, 0]
    for tick in range(max(4*a, 4*b, start_tick + 4*c)):
        width = (tick < 4*a) + (tick < 4*b) + (start_tick <= tick < start_tick + 4*c)
        counts[width] += 1
    return sum(count * price for count, price in zip(counts, costs)) / 4


def main():
    triples = 0
    starts = 0
    max_error = 0
    for a, b, c in product(range(1, 11), repeat=3):
        ticks = range(4*max(a, b) + 1)
        exhaustive = min(grid_cost(a, b, c, t) for t in ticks)
        launch, candidates = oracle["best_third_launch"](a, b, c, costs)
        error = abs(exhaustive - candidates[launch])
        assert error < 1e-8, (a, b, c, error)
        triples += 1
        starts += len(ticks)
        max_error = max(max_error, error)

    with oracle["QUESTIONS"].open(encoding="utf8", newline="") as stream:
        archive = list(csv.DictReader(stream))
    archived_gains = []
    for row in archive:
        lengths = [int(row[f"length_{i}"]) for i in range(3)]
        launch, times = oracle["best_third_launch"](*lengths, costs)
        archived_gains.append(100 * (1 - times[launch] / times[0]))
    reported = json.loads((run_out / "third-launch-oracle.json").read_bytes())["summary"]
    assert len(archive) == reported["questions"] == 200
    archive_gain = mean(archived_gains)
    assert abs(archive_gain - reported["continuous_mean_gain_pct"]) < 1e-10
    assert round(archive_gain, 3) == 0.764
    assert sum(g > 1e-8 for g in archived_gains) == reported["continuous_better_than_immediate"] == 135
    result = dict(
        matched_triples=triples, path_length_range_inclusive=[1, 10],
        grid_step=0.25, evaluated_start_times=starts, max_absolute_error_ms=max_error,
        tolerance_ms=1e-8, archived_questions=len(archive),
        archived_continuous_mean_gain_pct=archive_gain,
        archived_continuous_better_than_immediate=135,
        archived_summary_matches=True,
    )
    text = json.dumps(result, indent=2) + "\n"
    (run_out / "third-launch-grid-check.json").write_text(text, encoding="utf8")
    print(text, end="")


if __name__ == "__main__":
    main()
