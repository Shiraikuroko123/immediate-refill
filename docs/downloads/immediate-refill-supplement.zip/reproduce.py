"""Reproduce the five paper tables, figures, and finite checks without a GPU."""
import argparse
from collections import defaultdict
import csv
import hashlib
import json
import os
from pathlib import Path
import random
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "tracks/validation"))
import validate


def read(path):
    with path.open(encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream))


def run(script, *args):
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", MPLBACKEND="Agg")
    subprocess.run([sys.executable, str(ROOT / script), *map(str, args)], cwd=ROOT, env=env, check=True)


def equal_csv(actual, reference):
    assert read(actual) == read(reference), (actual, reference)


def verify_manifest():
    files = (ROOT / "SHA256SUMS").read_text(encoding="ascii").splitlines()
    for line in files:
        digest, name = line.split("  ", 1)
        if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != digest:
            raise ValueError(f"Unexpected file digest for {name}")
    return len(files)


def check_trace_tables(output):
    val = ROOT / "tracks/validation"
    numeric = [{k: v if k == "policy" else int(v) for k, v in row.items()}
               for row in read(val / "numeric_panels.csv")]
    dest = output / "brumo_validation"
    dest.mkdir()
    validate.summarize_schedule(dest, numeric)
    equal_csv(dest / "schedule_macro.csv", val / "exact-recovered/schedule_macro.csv")
    run("tracks/validation/make_manuscript_table.py")
    shutil.copyfile(ROOT / "manuscript/validation-table.tex", output / "table2.tex")

    held = ROOT / "tracks/heldout"
    groups = defaultdict(list)
    for row in read(held / "traces.csv"):
        groups[int(row["qid"])].append(row)
    assert len(groups) == 30 and all(len(group) == 32 for group in groups.values())
    simulated = []
    for q, group in sorted(groups.items()):
        group.sort(key=lambda r: int(r["slot"]))
        indices = list(range(32))
        random.Random(137 + q).shuffle(indices)
        for width in (8, 16):
            for offset in range(0, len(indices), width):
                panel = [dict(index=j, length=int(group[j]["length"]), final=group[j]["final"] or None)
                         for j in indices[offset:offset + width]]
                for slots in (4, width):
                    simulated.extend(validate.scheduling(panel, q, width, offset // width, slots))
    dest = output / "aime"
    dest.mkdir()
    validate.summarize_schedule(dest, simulated)
    equal_csv(dest / "schedule_macro.csv", held / "schedule_macro.csv")
    rows = {(int(r["n"]), int(r["capacity"]), r["chosen"], r["base"]): r
            for r in read(dest / "schedule_macro.csv")}
    result = []
    for width, slots in ((8, 4), (8, 8), (16, 4), (16, 16)):
        rolling, fixed = (rows[width, slots, "refill", base] for base in ("rolling", "fixed"))
        result.append(dict(paths=width, slots=slots, **{label: round(100 * float(row[key]), 1)
                           for label, row, key in (("rolling_time", rolling, "time_savings"),
                                                  ("low", rolling, "time_savings_low"),
                                                  ("high", rolling, "time_savings_high"),
                                                  ("fixed_time", fixed, "time_savings"),
                                                  ("fixed_work", fixed, "work_savings"))}))
    validate.save(output / "table3.csv", result)
    assert all(r["disagreements"] == 0 for r in simulated)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    destination = args.out.resolve()
    file_count = verify_manifest()
    destination.mkdir(parents=True, exist_ok=False)
    run("tracks/scheduling/checks/oracle.py", destination / "oracle")
    run("tracks/scheduling/checks/verify.py", destination / "finite")
    for dir_name, expected in (("oracle", 33018), ("finite", 368520)):
        data = json.loads((destination / dir_name / "summary.json").read_bytes())
        assert data["failures"] == 0 and data.get("integer_schedules", data.get("cases")) == expected
    check_trace_tables(destination)
    run("manuscript/figures.py")
    for filename, name in (("development-table.tex", "table1.tex"), ("example.pdf", "figure1.pdf"),
                           ("development.pdf", "figure2.pdf")):
        shutil.copyfile(ROOT / "manuscript" / filename, destination / name)
    run("manuscript/hardware_table.py", "--raw", ROOT / "release/hardware/raw", "--output",
        destination / "gpu", "--tex", destination / "tables4-5.tex")
    for table in ("table1.tex", "table2.tex", "table3.csv", "tables4-5.tex"):
        actual = (destination / table).read_text(encoding="utf-8").replace("\r\n", "\n")
        expected = (ROOT / "expected" / table).read_text(encoding="utf-8").replace("\r\n", "\n")
        assert actual == expected, table
    result = {"checked_payloads": file_count, "tables_matched": 5, "figures_regenerated": 2,
              "oracle_states": 2822, "oracle_schedules": 33018, "barrier_cases": 368520,
              "gpu_policy_observations": len(read(destination / "gpu/panels.csv"))}
    print(json.dumps(result))
    (destination / "verification.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
