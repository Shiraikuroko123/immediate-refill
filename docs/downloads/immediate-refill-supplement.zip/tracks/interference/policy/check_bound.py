"""Compare the additive waiting theorem with all safe discrete-time dispatches on small panels."""
from collections import Counter
from functools import lru_cache
from itertools import product
import json
from pathlib import Path


def gap(votes):
    counts = sorted(Counter(v for v in votes if v is not None).values(), reverse=True)
    counts.extend((0, 0))
    return counts[0] - counts[1]


def structurally_safe(n, seen, slots, quota, surplus):
    """Try every unobserved label in each prefix, independently of the published scan."""
    for length in range(1, n):
        partial = [seen[i] for i in range(length) if i in seen]
        unknown = length-len(partial)
        if any(gap(partial+list(extra)) > n-length for extra in product(("A","B"), repeat=unknown)):
            break
    else:
        length = n
    return min(quota, len(seen)+slots, length+surplus)


def solve(votes, lengths, slots, quota, surplus, allowance):
    n = len(votes)

    @lru_cache(None)
    def explore(state, left):
        obs = {i:votes[i] for i,rem in enumerate(state) if rem==0}
        if gap(obs.values())>n-len(obs) or len(obs)==quota:
            return 0,0
        limit = structurally_safe(n,obs,slots,quota,surplus)
        assert len(state)<=limit
        best, worst = float("inf"), 0
        # Require initial greedy admission and subsequent progress. This excludes
        # the vacuous equality construction that simply idles all slots at t=0.
        first_legal = len(state) if state else limit
        for target in range(first_legal, limit+1):
            cost = int(target<limit)
            if cost>left:
                continue
            launched = state + lengths[len(state):target]
            if not any(launched):
                continue
            nxt = tuple(max(0,x-1) for x in launched)
            a,b = explore(nxt,left-cost)
            best = min(best,1+a)
            worst = max(worst,1+b)
        return best,worst

    tg,_ = explore((),0)
    low,high = explore((),allowance)
    assert tg == low and high<=tg+allowance
    return tg,high


def witness(horizon, timeout):
    """Independent event simulation for N=16 and the all-A counterexample."""
    lengths = [horizon, 2]+[1]*14
    ends = {}
    next_id = finished = t = 0
    used = False
    release = None
    while finished < 9:
        # Along the constructed path its first nine votes could always be all A.
        target = min(10, finished+4)
        can_hold = target>next_id and ends and finished+2*len(ends)>16-finished
        if timeout and not used and can_hold:
            release = t+timeout
            used = True
        now_limit = target-int(release is not None and t<release and target>next_id)
        for i in range(next_id,now_limit):
            ends[i] = t+lengths[i]
        next_id = now_limit
        t = min([*ends.values()]+([release] if release is not None and release>t else []))
        for i in [i for i,end in ends.items() if end==t]:
            finished += 1
            del ends[i]
        if release==t:
            release = None
    return t


if __name__=="__main__":
    if not __debug__:
        raise RuntimeError("Assertions required")
    counts=Counter()
    for n in (2,3,4):
        for votes in product(("A","B",None),repeat=n):
            for lengths in product((1,2),repeat=n):
                for slots in (1,2):
                    for quota in (n-1,n):
                        for surplus in (0,1):
                            for allowance in (1,2):
                                tg,th=solve(votes,lengths,slots,quota,surplus,allowance)
                                counts["checked"]+=1
                                counts["upper_attained"]+=th==tg+allowance
                                counts["loss_possible"]+=th>tg
    witnesses=[]
    for h in (1,2,8,32,128):
        L=8+h
        greedy=witness(L,0)
        delayed=witness(L,h)
        unlimited=witness(L,2*L)
        assert (greedy,delayed,unlimited)==(4,4+h,L)
        witnesses.append(dict(h=h,L=L,greedy=greedy,timeout=delayed,unrestricted=unlimited))
    print(json.dumps(dict(counts=counts,witnesses=witnesses),indent=2))
