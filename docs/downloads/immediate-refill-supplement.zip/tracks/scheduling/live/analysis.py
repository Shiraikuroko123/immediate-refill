"""Summarize one host's measured profile, HF panels, and optional HTTP panels."""
import argparse
from collections import defaultdict
import csv
import hashlib
import json
import math
from pathlib import Path
import random
from statistics import mean, median


def json_rows(path):
    with path.open(encoding="utf-8") as source:
        return [json.loads(line) for line in source if line.strip()]


def file_hash(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def profile(directory):
    path = directory / "events.jsonl"
    rows = json_rows(path)
    meta = next(r for r in rows if r["event"] == "metadata")
    batches = defaultdict(list)
    for row in rows:
        if row["event"] == "trial":
            batches[row["batch"]].append(row)
    result = []
    for batch in sorted(batches):
        trials = batches[batch]
        if len(trials) != meta["args"]["repeats"]:
            raise ValueError(f"Incomplete profile batch {batch}")
        allocated = [r["peak_allocated_bytes"] for r in trials if r["peak_allocated_bytes"] is not None]
        reserved = [r["peak_reserved_bytes"] for r in trials if r["peak_reserved_bytes"] is not None]
        result.append(dict(batch=batch, trials=len(trials),
                           decode_tokens_per_second_median=median(r["tokens_per_second"] for r in trials),
                           decode_step_ms_median=median(r["mean_ms_per_step"] for r in trials),
                           prefill_ms_median=median(r["prefill_backbone_ms"] for r in trials),
                           peak_allocated_bytes=max(allocated, default=None),
                           peak_reserved_bytes=max(reserved, default=None)))
    if set(batches) != set(meta["args"]["batches"]):
        raise ValueError("Profile is missing a batch size")
    return dict(metadata=meta, batches=result, input_sha256={path.name:file_hash(path)})


def as_bool(value):
    if value in (True, "True", "true", 1):
        return True
    if value in (False, "False", "false", 0):
        return False
    if value is None or value == "":
        return None
    raise ValueError(f"Unexpected Boolean value {value!r}")


def hf_records(directory):
    summary_file = directory if directory.is_file() else directory / "summary.csv"
    with summary_file.open(newline="",encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream))
    common = []
    for r in rows:
        common.append(dict(q=int(r["qid"]), rep=int(r["repeat"]), policy=r["policy"],
                           wall=float(r["elapsed_s"]), work=int(r["main_tokens"]), correct=as_bool(r["correct"]),
                           warmup_s=float(r["warmup_s"]), launched=int(r["launched"]),
                           allocated=int(r["peak_allocated_bytes"]) if r["peak_allocated_bytes"] else None,
                           reserved=int(r["peak_reserved_bytes"]) if r["peak_reserved_bytes"] else None,
                           vote_diff=int(r["vote_mismatches"]), content_diff=int(r["token_hash_mismatches"]),
                           length_diff=int(r["length_mismatches"]), finish_diff=int(r["terminal_reason_mismatches"]),
                           winner_diff=not as_bool(r["full_winner_match"]), prefix_match=as_bool(r["prefix_match"])))
    meta_path = summary_file.parent/"manifest.json"
    meta = json.loads(meta_path.read_text(encoding="utf-8")) if meta_path.exists() else {}
    inputs = [summary_file]+([meta_path] if meta_path.exists() else [])
    raw_path = summary_file.parent/"trials.jsonl"
    if raw_path.exists():
        raw = {(r["qid"],r["repeat"],r["policy"]):r for r in json_rows(raw_path)}
        if len(raw) != len(common):
            raise ValueError("HF summary and raw trial counts disagree")
        for row in common:
            recorded = raw[row["q"],row["rep"],row["policy"]]
            reference = raw[row["q"],row["rep"],"full"]
            original = {p["index"]:p for p in reference["paths"]}
            paths = recorded["paths"]
            if row["wall"] != recorded["elapsed_s"] or row["work"] != sum(p["length"] for p in paths):
                raise ValueError("HF trial time or token accounting disagrees with summary")
            if {p["index"] for p in paths} != set(range(row["launched"])):
                raise ValueError("HF path indices do not form the recorded launch prefix")
            mismatch = {"vote_diff":0,"content_diff":0,"length_diff":0,"finish_diff":0}
            for p in paths:
                ref = original[p["index"]]
                token_hash = hashlib.sha256(json.dumps(p["token_ids"],separators=(",",":")).encode()).hexdigest()
                if p["seed"] != ref["seed"] or p["length"] != len(p["token_ids"]) or p["token_hash"] != token_hash:
                    raise ValueError("Invalid per-path seed, token length or token hash")
                for count, attribute in (("vote_diff","answer"),("length_diff","length"),
                                         ("content_diff","token_hash"),("finish_diff","finish_reason")):
                    mismatch[count] += p[attribute] != ref[attribute]
            if any(row[count] != total for count,total in mismatch.items()):
                raise ValueError("HF per-path coupling disagrees with summary")
        inputs.append(raw_path)
    return common, meta, inputs


def http_records(directory):
    paths = [directory/name for name in ("panels.jsonl","coupling.jsonl","warmups.jsonl","metadata.json")]
    key = lambda r:(r["qid"],r["repeat"],r["policy"])
    panels = json_rows(paths[0])
    comparisons = {key(r):r for r in json_rows(paths[1])}
    warmup = {key(r):r["request_s"] for r in json_rows(paths[2])}
    common = []
    for p in panels:
        c = comparisons[key(p)]
        common.append(dict(q=p["qid"],rep=p["repeat"],policy=p["policy"],
                           wall=p["decision_s"],drained_wall=p["drained_s"],work=p["generation_tokens"],
                           correct=p["correct"],warmup_s=warmup[key(p)],launched=p["launched"],
                           allocated=None,reserved=None,vote_diff=c["votes_mismatched"],
                           content_diff=c["generated_texts_mismatched"],length_diff=c["lengths_mismatched"],
                           finish_diff=sum(not v["finish_matches"] for v in c["per_seed"]),
                           winner_diff=not c["winner_agrees"],
                           prefix_match=c["launched_matches_full_prefix"] if p["policy"]!="full" else None))
    return common,json.loads(paths[-1].read_text(encoding="utf-8")),paths


def totals(rows):
    peak = lambda field:max((r[field] for r in rows if r[field] is not None),default=None)
    return dict(panels=len(rows),wall_seconds_total=sum(r["wall"] for r in rows),
                wall_seconds_median=median(r["wall"] for r in rows),
                work_tokens_total=sum(r["work"] for r in rows),
                correct=sum(r["correct"] for r in rows),paths_checked=sum(r["launched"] for r in rows),
                content_mismatches=sum(r["content_diff"] for r in rows),
                vote_mismatches=sum(r["vote_diff"] for r in rows),
                token_length_mismatches=sum(r["length_diff"] for r in rows),
                finish_reason_mismatches=sum(r["finish_diff"] for r in rows),
                winner_mismatches=sum(r["winner_diff"] for r in rows),
                serial_prefix_mismatches=sum(r["prefix_match"] is False for r in rows),
                serial_prefix_checked=sum(r["prefix_match"] is not None for r in rows),
                warmup_seconds_total=sum(r["warmup_s"] for r in rows),
                peak_allocated_bytes=peak("allocated"),peak_reserved_bytes=peak("reserved"))


def percentile(values, p):
    index=(len(values)-1)*p
    a,b=math.floor(index), math.ceil(index)
    return values[a]+(values[b]-values[a])*(index-a)


def controlled_summary(directory):
    """Verify each length charge and released vote from both live server responses."""
    files=[directory/name for name in ("manifest.json","pairs.jsonl","panels.jsonl","paths.jsonl")]
    meta=json.loads(files[0].read_text(encoding="utf-8"))
    pairs=json_rows(files[1])
    panels={(r["qid"],r["repeat"],r["policy"]):r for r in json_rows(files[2])}
    paths=defaultdict(dict)
    for item in json_rows(files[3]):
        key=item["qid"],item["repeat"],item["policy"]
        if item["index"] in paths[key] or item["required_tokens"]!=item["usage"]["completion_tokens"]:
            raise ValueError("Invalid controlled completion or repeated path")
        paths[key][item["index"]]=item
    checked=set()
    grouped=defaultdict(list)
    total_tokens=0
    for pair in pairs:
        key=pair["qid"],pair["repeat"]
        if key in checked:
            raise ValueError("Repeated controlled panel")
        checked.add(key)
        matched=[paths[(*key,m)] for m in ("refill","rolling")]
        rs,bs=matched
        if set(rs)!=set(bs) or set(rs)!=set(range(len(rs))):
            raise ValueError("Controlled policies used different prefixes")
        for idx in rs:
            for field in ("seed","required_tokens","released_vote"):
                if rs[idx][field]!=bs[idx][field]:
                    raise ValueError(f"Controlled paths differ on {field}")
        text_diffs=sum(rs[idx]["generated_text_hash"]!=bs[idx]["generated_text_hash"] for idx in rs)
        spent=sum(v["required_tokens"] for v in rs.values())
        if spent!=pair["generated_tokens_each"] or text_diffs!=pair["generated_text_hash_mismatches"]:
            raise ValueError("Raw controlled calls disagree with the paired work or output tally")
        for method in ("rolling","refill"):
            p=panels[(*key,method)]
            if p["decision_seconds"]!=pair[method+"_seconds"] or p["generation_tokens"]!=spent:
                raise ValueError("Raw controlled panels disagree with paired wall time or work")
        grouped[key[0]].append(pair)
        total_tokens+=spent
    if checked!={(q,r) for q in meta["qids"] for r in meta["repeats"]}:
        raise ValueError("Controlled panel grid is incomplete")
    by_q={q:mean(p["paired_reduction"] for p in rows) for q,rows in sorted(grouped.items())}
    values=list(by_q.values())
    rng=random.Random(20261120)
    boot=sorted(mean(rng.choices(values,k=len(values))) for _ in range(20000))
    return dict(trial_metadata=meta,input_sha256={p.name:file_hash(p) for p in files},
                questions=len(values),paired_trials=len(pairs),per_question_mean_wall_reduction=by_q,
                macro_paired_wall_reduction=mean(values),question_bootstrap_percentile_95=[
                    percentile(boot,.025),percentile(boot,.975)],positive_questions=sum(v>0 for v in values),
                pooled_wall_reduction=1-sum(r["refill_seconds"] for r in pairs)/sum(r["rolling_seconds"] for r in pairs),
                equal_tokens_each=total_tokens,matched_paths=sum(r["matched_paths"] for r in pairs),
                generated_text_hash_mismatches=sum(r["generated_text_hash_mismatches"] for r in pairs),
                task="conditional latency on fixed path lengths and archived votes")


def summarize(records, metadata, inputs, kind):
    by = {(r["q"],r["rep"],r["policy"]):r for r in records}
    if not by or len(by)!=len(records):
        raise ValueError("Empty or duplicate panel records")
    modes=sorted({r["policy"] for r in records})
    if not {"full","refill","rolling"}.issubset(modes):
        raise ValueError("A required policy is absent")
    qids=sorted({r["q"] for r in records})
    repeats=sorted({r["rep"] for r in records})
    args=metadata.get("args",metadata.get("arguments",{}))
    if set(qids)!=set(range(args.get("questions",len(qids)))) or set(repeats)!=set(range(args.get("repeats",len(repeats)))):
        raise ValueError("Manifest and available trial ids disagree")
    question_rows = []
    for q in qids:
        trials = [by[q,rep,policy] for rep in repeats for policy in modes]
        paired = []
        for rep in repeats:
            r, b = by[q,rep,"refill"],by[q,rep,"rolling"]
            paired.append(dict(repeat=rep,rolling_seconds=b["wall"],refill_seconds=r["wall"],
                               rolling_tokens=b["work"],refill_tokens=r["work"],
                               wall_reduction=1-r["wall"]/b["wall"],token_reduction=1-r["work"]/b["work"]))
        question_rows.append(dict(qid=q,repeats=len(repeats),paired=paired,
                                  mean_paired_wall_reduction=mean(p["wall_reduction"] for p in paired),
                                  mean_paired_token_reduction=mean(p["token_reduction"] for p in paired),
                                  by_policy={m:totals([r for r in trials if r["policy"]==m]) for m in modes}))
    aggregate={m:totals([r for r in records if r["policy"]==m]) for m in modes}
    rolling,refill=aggregate["rolling"],aggregate["refill"]
    gains=[q["mean_paired_wall_reduction"] for q in question_rows]
    rng=random.Random(20261120)
    resamples=sorted(mean(rng.choices(gains,k=len(gains))) for _ in range(20000))
    return dict(input_sha256={p.name:file_hash(p) for p in inputs},trial_metadata=metadata,
                scope=dict(independent_prompts=len(qids),repeats_per_prompt=len(repeats),
                           content_metric="sampled_token_id_hash" if kind=="hf" else "generated_text_hash",
                           timing_metric="in_process_wall" if kind=="hf" else "client_decision_wall",
                           work_metric="generated_tokens_including_drained_calls"),
                per_question=question_rows,by_policy=aggregate,
                paired=dict(macro_wall_reduction=mean(gains),
                            question_bootstrap_percentile_95=[percentile(resamples,.025),percentile(resamples,.975)],
                            bootstrap_resamples=20000, positive_questions=sum(v>0 for v in gains),
                            pooled_wall_reduction=1-refill["wall_seconds_total"]/rolling["wall_seconds_total"],
                            pooled_work_reduction=1-refill["work_tokens_total"]/rolling["work_tokens_total"],
                            unequal_work_pairs=sum(p["rolling_tokens"]!=p["refill_tokens"] for q in question_rows for p in q["paired"])))


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--profile",type=Path,help="measure.py output directory containing events.jsonl")
    parser.add_argument("--hf",type=Path,help="HF output directory or its summary.csv")
    parser.add_argument("--http",type=Path,help="HTTP output directory containing panels and coupling")
    parser.add_argument("--controlled",type=Path,help="Controlled vLLM output with fixed lengths and archived votes")
    parser.add_argument("--label",required=True,help="Human-readable card or run label")
    parser.add_argument("--out",required=True,type=Path)
    args=parser.parse_args()
    if not any((args.profile,args.hf,args.http,args.controlled)):
        parser.error("Provide at least one measured input.")
    result={"schema":"schedule-hardware-v1","label":args.label}
    if args.profile:
        result["profile"]=profile(args.profile)
    if args.hf:
        result["hf"]=summarize(*hf_records(args.hf),"hf")
    if args.http:
        result["http"]=summarize(*http_records(args.http),"http")
    if args.controlled:
        result["controlled"]=controlled_summary(args.controlled)
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False),encoding="utf-8")
    print(args.out)


if __name__=="__main__":
    main()
