"""Development-only plurality stopping replay. See PROTOCOL.md."""
import argparse
from collections import Counter, defaultdict
import csv
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import platform
import random
import re
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from certificate import baselines, joint_risk, top_rival_risk

STEP = 2048
DELTA = 0.05
METHODS = ["full", "deterministic", "mars_mean", "mars_theorem", "union_total", "one_rival", "joint"]
MODELED = METHODS[2:]
NUMERIC = re.compile(r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:/[+-]?\d+)?$")


def answer(value):
    if value is None or not str(value).strip():
        return None
    text = str(value).strip().strip("$").strip()
    boxed = re.fullmatch(r"\\boxed\{(.+)\}", text)
    if boxed:
        text = boxed[1].strip()
    frac = re.fullmatch(r"\\(?:d?frac)\{([+-]?\d+)\}\{([+-]?\d+)\}", text)
    if frac:
        text = f"{frac[1]}/{frac[2]}"
    if re.fullmatch(r"[+-]?\d{1,3}(?:,\d{3})+(?:\.\d+)?", text):
        text = text.replace(",", "")
    try:
        if NUMERIC.fullmatch(text):
            return str(Fraction(text))
    except (ZeroDivisionError, ValueError):
        pass
    return text or None


def winner(values):
    counts = Counter(v for v in values if v is not None)
    ordered = sorted(counts, key=lambda label: (-counts[label], label))
    if not ordered:
        return None, False, 0
    gap = counts[ordered[0]] - (counts[ordered[1]] if len(ordered) > 1 else 0)
    return ordered[0], gap > 0, gap


def correctness(pred, truth):
    if pred is None:
        return False
    if pred == truth:
        return True
    if truth is not None and NUMERIC.fullmatch(pred) and NUMERIC.fullmatch(truth):
        return False
    return None


def prepare(row):
    probes = {}
    for position, record in row["probes"].items():
        value = record.get("answer") if isinstance(record, dict) else record
        probes[int(position)] = answer(value)
    return dict(index=int(row["trace_idx"]), length=int(row["length"]),
                final=answer(row["extracted_answer"]), truth=answer(row["ground_truth"]), probes=probes)


def history(trace, pos, current):
    prev = trace["probes"].get(pos-STEP)
    if prev is None:
        return "first"
    return "same" if current == prev else "changed"


def warmup_model(warmup):
    totals = defaultdict(lambda: [0, 0])
    classes = defaultdict(lambda: [0, 0])
    calls = 0
    for trace in warmup:
        for pos in range(STEP, trace["length"], STEP):
            calls += 1
            current = trace["probes"].get(pos)
            if current is None:
                continue
            changed = (current != trace["final"])
            for counts in (totals[pos], classes[pos,history(trace,pos,current)]):
                counts[0] += changed
                counts[1] += 1
    def estimate(pos, cls):
        switches, total = totals[pos]
        prior = (switches+1)/(total+2)
        switches, total = classes[pos,cls]
        return (switches+8*prior)/(total+8)
    return estimate, calls, totals, classes


def practical_margin(groups):
    leader = groups[0]
    others = groups[1:]
    total_q = sum(sum(g) for g in groups)
    return min(len(leader) - len(rival) - (total_q + sum(leader) - 2*sum(rival))
               for rival in [*others, []])


def checkpoint(panel, pos, rate):
    labels, groups = {}, defaultdict(list)
    for trace in panel:
        if trace["length"] <= pos:
            current, q = trace["final"], 0.
        else:
            current = trace["probes"].get(pos)
            if current is None:
                return {}, {}, "missing_live_probe"
            q = rate(pos, history(trace,pos,current))
        labels[trace["index"]] = current
        if current is not None:
            groups[current].append(q)
    leader, unique, _ = winner(labels.values())
    if not unique:
        return {}, {}, "tied_or_empty"
    order = sorted(groups, key=lambda label:(-len(groups[label]),label))
    g = [groups[label] for label in order]
    b = baselines(g)
    risks = {**b, "union_total":min(b["marginal_union"],b["total_flips"]),
             "one_rival":top_rival_risk(g), "joint":joint_risk(g), "mars_slack":practical_margin(g)}
    # With completed abstentions, MARS union correction uses panel N in Cor. 2.5.
    risks["mars_theorem"] = min(1., risks["mars_theorem"]*len(panel)/sum(map(len,g)))
    can = {m:bool(risks[m] <= DELTA) for m in ("joint","one_rival","union_total","mars_theorem")}
    can["mars_mean"] = risks["mars_slack"] >= 0.
    return can, dict(votes=dict(groups), leader=leader, **risks), "ok"


def finished_stop(panel):
    for t in sorted(set(trace["length"] for trace in panel)):
        finished = [tr["final"] for tr in panel if tr["length"] <= t]
        leader, unique, gap = winner(finished)
        if unique and gap > len(panel)-len(finished):
            return t, leader
    return None


def writecsv(path, rows):
    with path.open("w", newline="", encoding="utf-8") as f:
        out = csv.DictWriter(f,fieldnames=list(rows[0]))
        out.writeheader()
        out.writerows(rows)


def run_panel(qid, panel, batch, rate, state_file):
    n = len(panel)
    base = sum(tr["length"] for tr in panel)
    final, unique, _ = winner([tr["final"] for tr in panel])
    end = max(tr["length"] for tr in panel)
    det = finished_stop(panel)
    det_event = (*det, "deterministic") if det and det[0]<end else (end,final,"budget")
    stops = {"full":(end, final, "budget"), "deterministic":det_event}
    for pos in range(STEP, end, STEP):
        can, state, reason = checkpoint(panel,pos,rate)
        state_file.write(json.dumps(dict(qid=qid,n=n,batch=batch,position=pos,status=reason,
                                          before_deterministic=pos<det_event[0],can=can,**state))+"\n")
        if pos >= det_event[0]:
            continue
        for method, yes in can.items():
            if yes and method not in stops:
                stops[method] = (pos,state["leader"],"probe")
    rows = []
    for method in METHODS:
        pos, pred, stop_type = stops.get(method,det_event)
        tokens = sum(min(tr["length"],pos) for tr in panel)
        last = pos if stop_type == "probe" else pos-1
        probe_calls = sum(max(0,min(tr["length"]-1,last)//STEP) for tr in panel) if method in MODELED else 0
        rows.append(dict(qid=qid,n=n,batch=batch,method=method,stop=stop_type,stop_position=pos,
                         full_tokens=base,main_tokens=tokens,saved_tokens=base-tokens,probe_calls=probe_calls,
                         prediction=pred,full_prediction=final,final_unique=unique,
                         disagrees=int(pred!=final),early_nonunique_or_disagrees=int(pos<end and (not unique or pred!=final)),
                         accuracy=correctness(pred,panel[0]["truth"]), trace_ids=",".join(str(t["index"]) for t in panel)))
    return rows


def run(path, output):
    start = time.perf_counter()
    output.mkdir(parents=True,exist_ok=False)
    questions = defaultdict(dict)
    for line in path.read_text(encoding="utf-8").splitlines():
        row=json.loads(line)
        qid=int(row["qid"])
        tr=prepare(row)
        if qid not in range(4) or tr["index"] not in range(512) or tr["index"] in questions[qid]:
            raise ValueError("Input violates predeclared development scope or contains duplicate IDs")
        questions[qid][tr["index"]] = tr
    if set(questions)!=set(range(4)) or any(set(rows)!=set(range(512)) for rows in questions.values()):
        raise ValueError("Missing development trace IDs")
    all_rows, qs, warm, calibration = [], [], [], []
    with (output/"states.jsonl").open("w",encoding="utf-8") as states:
        for qid in sorted(questions):
            rows=questions[qid]
            assert len({t["truth"] for t in rows.values()})==1
            warm_traces=[rows[j] for j in range(32)]
            rate, warm_calls, totals, classes=warmup_model(warm_traces)
            warm.append(dict(qid=qid,main_tokens=sum(t["length"] for t in warm_traces),probe_calls=warm_calls))
            for (pos,cls),(changes,count) in sorted(classes.items()):
                calibration.append(dict(qid=qid,pos=pos,cls=cls,changes=changes,count=count,
                                        global_changes=totals[pos][0],global_count=totals[pos][1],q=rate(pos,cls)))
            ids=list(range(32,512))
            random.Random(137+qid).shuffle(ids)
            for n in [8,16]:
                for i in range(0,len(ids),n):
                    panel=[rows[j] for j in ids[i:i+n]]
                    all_rows.extend(run_panel(qid,panel,i//n,rate,states))
            # Only the retrospective assessment below sees the endpoint for active live votes.
            for j in ids:
                tr=rows[j]
                for pos in range(STEP,tr["length"],STEP):
                    a=tr["probes"].get(pos)
                    if a is not None:
                        cls=history(tr,pos,a)
                        qs.append(dict(qid=qid,index=j,pos=pos,cls=cls,q=rate(pos,cls),switch=int(a!=tr["final"])))
    writecsv(output/"panels.csv",all_rows)
    writecsv(output/"warmup.csv",warm)
    writecsv(output/"fitted_rates.csv",calibration)
    writecsv(output/"q_assessment.csv",qs)
    agg=[]
    for qid in sorted(questions):
        for n in [8,16]:
            for method in METHODS:
                rows=[r for r in all_rows if (r["qid"],r["n"],r["method"])==(qid,n,method)]
                known=[r["accuracy"] for r in rows if r["accuracy"] is not None]
                total=sum(r["full_tokens"] for r in rows)
                saved=sum(r["saved_tokens"] for r in rows)
                agg.append(dict(qid=qid,n=n,method=method,panels=len(rows),full_tokens=total,saved_tokens=saved,
                                main_token_saving_frac=saved/total,probe_calls=sum(r["probe_calls"] for r in rows),
                                disagrees=sum(r["disagrees"] for r in rows),
                                early_nonunique_or_disagrees=sum(r["early_nonunique_or_disagrees"] for r in rows),
                                final_ties_or_empty=sum(not r["final_unique"] for r in rows),correct=sum(known),
                                accuracy_known_n=len(known),accuracy_known=sum(known)/len(known) if known else None))
    writecsv(output/"per_question.csv",agg)
    sha=lambda file:hashlib.sha256(file.read_bytes()).hexdigest()
    manifest={"sha256":{f.name:sha(f) for f in [path,Path(__file__),HERE/"PROTOCOL.md",HERE.parent/"certificate.py"]},
              "seconds":time.perf_counter()-start,"python":sys.version,"platform":platform.platform(),
              "n_questions":len(questions),"n_panel_rows":len(all_rows),"n_q_assessment":len(qs)}
    (output/"manifest.json").write_text(json.dumps(manifest,indent=2))
    print(json.dumps(manifest))


if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("--data",type=Path,default=HERE.parent/"data_access/traces.jsonl")
    p.add_argument("--out",type=Path,required=True)
    args=p.parse_args()
    run(args.data,args.out)
