"""Check finite instances of the fixed panel size and quota results."""
from fractions import Fraction
from functools import cache
from itertools import product
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "information-baseline"))
from gates import allowed, simulate


def violation_witnesses():
    cases = 0
    padded = 0
    for n in range(1, 15):
        for quota in range(1, n + 1):
            inventory = min(quota, n // 2 + 1)
            for slots in range(1, 9):
                bound = min(slots, inventory)
                for j in range(1, bound):
                    # A strictly increasing clock with a discrete concavity violation at j.
                    prices = [4 * width - int(width == j) for width in range(slots + 1)]
                    gap = prices[j-1] + prices[j+1] - 2 * prices[j]
                    tail = inventory - j - 1
                    epsilon = Fraction(gap, 4 * max(prices[:bound+1]) * max(1, tail))
                    work = [2] * (j - 1) + [1, 1] + [epsilon] * (n - j - 1)
                    votes = ["A"] * n
                    greedy = simulate(work, votes, 0, quota, slots, "indexed")
                    assert len(greedy["starts"]) == inventory
                    greedy_cost = sum(d * c for d, c in zip(greedy["occ"], prices[1:]))
                    # Start the core jobs at the two prescribed times, then run the tail serially.
                    starts = [0] * j + [1] + [2 + k * epsilon for k in range(tail)]
                    ends = [s + w for s, w in zip(starts, work)]
                    for i, t in enumerate(starts):
                        seen = {k: "A" for k in range(i) if ends[k] <= t}
                        assert i - len(seen) < slots and i < quota
                        assert allowed(seen, i + 1, 0, n, "indexed")
                    comparator_cost = 0
                    times = sorted(set(starts + ends))
                    for left, right in zip(times, times[1:]):
                        busy = sum(s <= left < e for s, e in zip(starts, ends))
                        comparator_cost += (right - left) * prices[busy]
                    assert comparator_cost < greedy_cost
                    cases += 1
                    padded += int(tail > 0)
    return dict(fixed_spec_and_violation_index_combinations=cases, positive_tail_cases=padded)


def three_job_check():
    prices = (0, 1, 1, 6)
    ratios = []
    for work in product(range(1, 9), repeat=3):
        @cache
        def optimal(launched, running):
            if launched == 3 and not running:
                return 0
            costs = []
            for count in range(3 - launched + 1):
                active = running + work[launched:launched + count]
                if active:
                    remaining = tuple(r - 1 for r in active if r > 1)
                    costs.append(prices[len(active)] + optimal(launched + count, remaining))
            return min(costs)

        best = optimal(0, ())
        greedy = simulate(work + (1,), ("A",) * 4, 0, 3, 3, "indexed")
        cost = sum(t * c for t, c in zip(greedy["occ"], prices[1:]))
        x, y, z = sorted(work)
        assert cost == 5*x + z and best >= max(x+y, z)
        if work == (2, 1, 1):
            assert (cost, best) == (7, 2)
        ratios.append(Fraction(cost, best))
    assert max(ratios) == Fraction(7, 2)
    return dict(ordered_length_triples=len(ratios), maximum_ratio=str(max(ratios)),
                maximizers=ratios.count(max(ratios)), concave_envelope_bound=4)


if __name__ == "__main__":
    print(json.dumps(dict(witnesses=violation_witnesses(), three_jobs=three_job_check()), indent=2))
