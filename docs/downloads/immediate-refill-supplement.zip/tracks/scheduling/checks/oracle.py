"""Check maximality and per-path start times against an exhaustive serial oracle."""
import argparse
from collections import Counter
from functools import lru_cache
import hashlib
from itertools import product
import json
from pathlib import Path


MISSING, ABSTAIN = "?", "-"
LABELS = ("A", "B", ABSTAIN)


def serial_length(votes):
    for end in range(1, len(votes) + 1):
        difference = abs(votes[:end].count("A") - votes[:end].count("B"))
        if difference > len(votes) - end:
            return end
    return len(votes)


def make_oracle(n):
    """Return the minimum serial length of any panel matching each partial observation."""
    minima = {}
    for full in product(LABELS, repeat=n):
        stop = serial_length(full)
        for mask in range(2 ** n):
            observations = tuple(v if mask & (1 << j) else MISSING for j, v in enumerate(full))
            minima[observations] = min(minima.get(observations, n), stop)
    return minima


def formula(observed):
    remaining = observed.count(MISSING)
    counts = Counter(v for v in observed if v not in (MISSING, ABSTAIN))
    top = sorted(counts.values(), reverse=True) + [0, 0]
    gap = top[0] - top[1]
    certainty = min(remaining, max(0, (remaining - gap) // 2 + 1))
    return len(observed) - remaining + certainty


def reachable_states(n, oracle):
    """Use only the independent oracle to admit starts. Any active path may finish next."""
    pending = [(0, (MISSING,) * n)]
    seen = set()
    while pending:
        launched, observations = state = pending.pop()
        if state in seen:
            continue
        seen.add(state)
        ceiling = oracle[observations]
        if formula(observations) != ceiling:
            raise ValueError(("mandatory prefix", state, formula(observations), ceiling))
        if launched < ceiling:
            pending.append((launched + 1, observations))
        for j in range(launched):
            if observations[j] == MISSING:
                for label in LABELS:
                    pending.append((launched, observations[:j] + (label,) + observations[j + 1:]))
    return len(seen)


def observation_at(tick, votes, durations, starts):
    return tuple(vote if index < len(starts) and starts[index] + durations[index] <= tick else MISSING
                 for index, vote in enumerate(votes))


def greedy_starts(votes, durations, slots):
    starts = ()
    for tick in range(sum(durations) + 1):
        obs = observation_at(tick, votes, durations, starts)
        complete = len(obs) - obs.count(MISSING)
        limit = min(formula(obs), complete + slots)
        starts += (tick,) * (limit - len(starts))
        if len(starts) == complete:
            return starts
    raise ValueError(("greedy scheduler did not stop", votes, durations, slots))


def integer_schedules(votes, durations, slots, oracle):
    """Check every integer-time start choice, including idling while a path runs."""
    greedy = greedy_starts(votes, durations, slots)
    required = serial_length(votes)

    @lru_cache(maxsize=None)
    def visit(tick, starts):
        obs = observation_at(tick, votes, durations, starts)
        complete = len(obs) - obs.count(MISSING)
        active = len(starts) - complete
        max_launches = min(oracle[obs] - len(starts), slots - active)
        if complete == required:
            if starts != starts[:required] or len(greedy) != required:
                raise ValueError(("incorrect prefix", starts, greedy, required))
            return 1
        paths = 0
        # Pure waiting with an entirely idle system merely shifts all future actions.
        for count in range(0 if active else 1, max_launches + 1):
            after = starts + (tick,) * count
            for j in range(len(starts), len(after)):
                if j >= len(greedy) or after[j] < greedy[j]:
                    raise ValueError(("earlier start", votes, durations, slots, after, greedy))
            paths += visit(tick + 1, after)
        if not paths:
            raise ValueError(("unreachable dead end", votes, durations, slots, tick, starts))
        return paths

    return visit(0, ())


def run():
    families = []
    for n in range(1, 7):
        oracle = make_oracle(n)
        row = {"n": n, "reachable_states": reachable_states(n, oracle)}
        if n <= 4:
            instances = schedules = 0
            for votes in product(LABELS, repeat=n):
                for durations in product((1, 2), repeat=n):
                    for slots in range(1, n + 1):
                        schedules += integer_schedules(votes, durations, slots, oracle)
                        instances += 1
            row.update(instances=instances, integer_schedules=schedules)
        families.append(row)
    return {
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "votes": list(LABELS), "positive_integer_durations": [1, 2], "failures": 0,
        "families": families,
        **{key: sum(row.get(key, 0) for row in families)
           for key in ("reachable_states", "instances", "integer_schedules")},
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("out", type=Path)
    out = parser.parse_args().out
    out.mkdir(parents=True, exist_ok=False)
    try:
        result = run()
    except Exception as exc:
        (out / "failure.txt").write_text(repr(exc), encoding="utf-8")
        raise
    (out / "summary.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result))
