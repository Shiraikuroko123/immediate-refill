"""Evaluate the immutable question split and reproduce the question-paired intervals."""
import csv
from collections import defaultdict
import hashlib
import heapq
import io
import json
from pathlib import Path
import random
import sys
import time

import numpy as np

HERE = Path(__file__).resolve().parent
VOTING = HERE.parent/"voting"
sys.path[:0] = [str(HERE.parent/"scheduling"), str(VOTING/"replay"), str(VOTING/"transfer")]
from schedule import simulate
import replay
import transfer


def read_lines(path):
    with path.open(encoding="utf-8") as f:
        for line in f:
            yield json.loads(line)


def save(path, records):
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)


def full_budget(lengths, answers, capacity):
    free = [0]*capacity
    for length in lengths:
        start = heapq.heappop(free)
        heapq.heappush(free, start+length)
    n = len(lengths)
    return dict(winner=replay.winner(answers)[0], launched=n, completed=n, tokens=sum(lengths),
                steps=max(free), canceled=0)


def train(out):
    old = VOTING/"data_access"/"traces.jsonl"
    rows = [replay.prepare(r) for r in read_lines(old) if 0 <= r["qid"] < 4 and r["trace_idx"] < 32]
    assert len(rows) == 128
    predict, calls, _, _ = replay.warmup_model(rows)
    (out/"training.json").write_text(json.dumps(dict(qids=list(range(4)), ids=[0,31], n=128,
        train_main_tokens=sum(t["length"] for t in rows), train_probe_calls=calls,
        source_sha256=hashlib.sha256(old.read_bytes()).hexdigest()), indent=2), encoding="utf-8")
    return predict


def scheduling(panel, q, size, number, cap):
    lengths = [t["length"] for t in panel]
    votes = [t["final"] for t in panel]
    full = full_budget(lengths,votes,cap)
    rows = []
    for name, width in [("full",cap),("fixed",cap),("rolling",cap),("refill",cap),("serial",1)]:
        mode = "fixed" if name == "serial" else name
        result = full if mode == "full" else simulate(lengths,votes,mode,width)
        rows.append(dict(qid=q, n=size, panel=number, capacity=cap, policy=name,
                         trace_ids=" ".join(str(t["index"]) for t in panel),
                         disagreements=int(result["winner"] != full["winner"]),
                         prediction=result["winner"], full_winner=full["winner"],
                         tokens=result["tokens"], steps=result["steps"], launched=result["launched"],
                         completed=result["completed"], canceled=result["canceled"]))
    return rows


def probe(panel,q,size,number,rate):
    stream = io.StringIO()
    rows = replay.run_panel(q,panel,number,rate,stream)
    deterministic = next(r for r in rows if r["method"]=="deterministic")
    states = [json.loads(s) for s in stream.getvalue().splitlines()]
    rows.append(transfer.stable_rule(panel,states,deterministic))
    keep = {"full","deterministic","joint","one_rival","share75_two"}
    return [r for r in rows if r["method"] in keep], states


def summarize_schedule(out, rows):
    by = defaultdict(lambda: defaultdict(lambda: defaultdict(int)))
    for r in rows:
        group=by[(r["qid"],r["n"],r["capacity"])][r["policy"]]
        group["panels"]+=1
        for k in ["tokens","steps","disagreements"]:
            group[k]+=r[k]
    individual=[]
    for (q,n,c),res in sorted(by.items()):
        for chosen,ref in [("refill","rolling"),("refill","fixed"),("refill","full"),("rolling","full"),
                           ("fixed","full"),("serial","full")]:
            test,base=res[chosen],res[ref]
            individual.append(dict(qid=q,n=n,capacity=c,chosen=chosen,base=ref,panels=test["panels"],
                              disagreements=test["disagreements"],tokens=test["tokens"],ref_tokens=base["tokens"],
                              steps=test["steps"],ref_steps=base["steps"],
                              work_savings=1-test["tokens"]/base["tokens"],
                              time_savings=1-test["steps"]/base["steps"]))
    save(out/"schedule_by_question.csv", individual)
    group_keys={(r["n"],r["capacity"],r["chosen"],r["base"]) for r in individual}
    bootstrap(individual,group_keys,["n","capacity","chosen","base"],["work_savings","time_savings"],
              out/"schedule_macro.csv")


def bootstrap(rows, keys, fields, metrics, dest):
    summary=[]
    for key in sorted(keys):
        block=sorted([r for r in rows if tuple(r[f] for f in fields)==key],key=lambda r:r["qid"])
        assert len(set(r["qid"] for r in block)) == len(block)
        rng=np.random.default_rng(20261120)
        indices=rng.integers(0,len(block),size=(20_000,len(block)))
        item={**dict(zip(fields,key)), "questions":len(block),"panels":sum(r["panels"] for r in block),
              "disagreements":sum(r["disagreements"] for r in block)}
        for metric in metrics:
            v=np.array([r[metric] for r in block],dtype=float)
            lo,hi=np.quantile(v[indices].mean(1),[.025,.975])
            item.update({metric:float(v.mean()),metric+"_low":float(lo),metric+"_high":float(hi)})
        summary.append(item)
    save(dest,summary)


def summarize_probe(out, rows):
    groups=defaultdict(list)
    for r in rows:
        groups[(r["qid"],r["n"],r["method"])].append(r)
    indiv=[]
    for (q,n,m),block in sorted(groups.items()):
        denom=sum(r["full_tokens"] for r in block)
        main=sum(r["main_tokens"] for r in block)
        num=sum(r["probe_calls"] for r in block)
        errors=sum(r["disagrees"] for r in block)
        for price in [0,25,50]:
            indiv.append(dict(qid=q,n=n,method=m,price=price,panels=len(block),disagreements=errors,
                              full_tokens=denom,main_tokens=main,probes=num,
                              savings=1-(main+price*num)/denom,disagreement_rate=errors/len(block)))
    save(out/"probe_by_question.csv",indiv)
    fields=["n","method","price"]
    bootstrap(indiv,{tuple(r[k] for k in fields) for r in indiv},fields,["savings","disagreement_rate"],out/"probe_macro.csv")


def run(out, endpoints):
    started=time.perf_counter()
    out.mkdir(parents=True,exist_ok=False)
    rate=train(out)
    data=defaultdict(dict)
    path=HERE/"validation_traces.jsonl"
    for r in read_lines(path):
        q,i=r["qid"],r["trace_idx"]
        if q not in range(4,14) or i not in range(128) or i in data[q]:
            raise ValueError("Unexpected trace")
        at_cap = r["length"] is None or r["length"] >= 30_720
        if endpoints.startswith("cap") and at_cap:
            r["length"] = 30_720
            r["extracted_answer"] = (r["probes"].get("30720",{}).get("answer")
                                     if endpoints=="cap-probe" else None)
        data[q][i]=None if r["length"] is None else replay.prepare(r)
    assert set(data)==set(range(4,14)) and all(set(d)==set(range(128)) for d in data.values())
    schedule_rows,probe_rows,coverage=[],[],[]
    with (out/"states.jsonl").open("w",encoding="utf-8") as states_file:
        for q,traces in sorted(data.items()):
            indices=list(range(128))
            random.Random(137+q).shuffle(indices)
            for size in [8,16]:
                for i in range(0,128,size):
                    selected=indices[i:i+size]
                    panel=[traces[j] for j in selected]
                    missing=[j for j in selected if traces[j] is None]
                    coverage.append(dict(qid=q,n=size,panel=i//size,trace_ids=" ".join(map(str,selected)),
                                         unresolved_length_ids=" ".join(map(str,missing)),retained=int(not missing)))
                    if missing:
                        continue
                    for cap in [4,size]:
                        schedule_rows.extend(scheduling(panel,q,size,i//size,cap))
                    sub,states=probe(panel,q,size,i//size,rate)
                    probe_rows.extend(sub)
                    for s in states:
                        states_file.write(json.dumps(s)+"\n")
    save(out/"coverage.csv",coverage)
    save(out/"schedule_panels.csv",schedule_rows)
    save(out/"probe_panels.csv",probe_rows)
    summarize_schedule(out,schedule_rows)
    summarize_probe(out,probe_rows)
    files=[path,Path(__file__),HERE/"PROTOCOL.md",Path(replay.__file__),Path(transfer.__file__),
           HERE.parent/"scheduling"/"schedule.py",VOTING/"certificate.py"]
    manifest=dict(elapsed_s=time.perf_counter()-started,gpu_hours=0,questions=len(data),endpoints=endpoints,
                  panels_candidate=len(coverage),retained=sum(r["retained"] for r in coverage),
                  python=sys.version,numpy=np.__version__,
                  sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files})
    (out/"manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")
    print(json.dumps(manifest))


if __name__=="__main__":
    mode=sys.argv[2] if len(sys.argv)>2 else "exact"
    assert mode in {"exact","cap-abstain","cap-probe"}
    run(Path(sys.argv[1]),mode)
