# Reproducing *When Is Immediate Refill Optimal for Parallel Voting?*

Extract this ZIP into a new directory. Run the commands below in that directory with CPython 3.10. The analysis uses a CPU and the included measurements. Installing the Python dependencies initially requires an internet connection or a local wheel cache.

```sh
python -m venv .venv
```

Activate the environment with `source .venv/bin/activate` on Linux or macOS, or `.\.venv\Scripts\Activate.ps1` in Windows PowerShell. Then run:

```sh
python -m pip install -r requirements.txt
python -B reproduce.py --out results.json
```

The program checks the hash of each distributed input, script and reference output against `MANIFEST.sha256.json`. It compares each computation with recorded results and writes one JSON report. Use a new output path when running again.

| Question | Computation and inputs | What to look for in the report |
| --- | --- | --- |
| Does the clock predict the fixed-length timing contrast? | `check.py` checks the sealed prediction and reconstructs trial effects from the calibration and validation events in `tracks/interference/prospective-device/session01/`. | `archived_replay.device_and_oracle` reports 3.13% predicted and 2.46% measured median saving in one A800 session. The two-request control has the opposite sign. |
| How often does delaying the third launch help in recorded traces? | `tracks/interference/opportunity/` compares two actions on three mandatory requests drawn from 200 GSM8K problems. `analysis/sensitivity/third-launch-oracle.py` also optimizes the third launch time while starting the first two at zero. | The two-action mean oracle gain is 0.364%. The retrospective continuous-time comparison gives 0.764%. `third-launch-grid-check` checks the candidate-time algorithm against a quarter-step grid on 1,000 small triples. |
| Where do the replay savings come from? | The 14 analyses in `cpu/replay.py` include information ablations, the finite oracle, width costs, occupancy checks, cost uncertainty and the output-cap study. | `archived_replay.fourteen_groups` lists all groups. The three indexed-admission contrasts average 8.71%, 0.67% and 0.30% across questions. |
| What happens on the device-generated workload? | `tracks/interference/gsm_live/analyze.py` reconstructs the 16-question pilot from 80 panel records. `analysis/sensitivity/empirical-sensitivity.py` extracts trial-order strata, question-level and pooled contrasts, cap interactions and sensitivity to long paths. | `sixteen_question_pilot` includes the fixed-workload mean and interval. `retrospective_sensitivity` also contains the exact resampling analysis of eight shards. These follow-up analyses reuse the same archived samples. |
| Do the finite examples agree with the theory? | `tracks/interference/acceptance-review/` contains the fixed-specification and three-price enumerations. `affine/`, `bound/` and `policy/` contain the work and wait-bound checks. | `finite_theory` includes 1,764 fixed-specification witnesses, 512 length triples, six price settings, 11,776 certificate-bound configurations and 17,640 zero-budget panel checks. |

To also regenerate all seven study figures, install Matplotlib with `python -m pip install -r figures/requirements.txt`. Provide a working `pdflatex` with `pgf`, `helvet` and `amssymb` on the command path. Use:

```sh
python -B reproduce.py --out results-with-figures.json --figures rebuilt-figures
```

`figures/plots/data-sha256.json` records the plotting inputs. `figures/plots/README.md` gives commands for individual figures. The paper PDF and its LaTeX source are separate downloads.

The CPU run uses previously recorded device events. For a fresh device session use the pinned model hashes and Linux GPU instructions in [models/README.md](models/README.md) and [runtime/README.md](runtime/README.md). The two models, engine settings and workload lengths differ between calibrations. Original A800 records keep their SHA-256 seals, including generic machine paths used when running the experiments. Dataset sources and terms are described in [SOURCES.md](SOURCES.md).
