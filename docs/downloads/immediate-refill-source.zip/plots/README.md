# Rebuilding the four empirical figures

From the directory containing `main.tex`, use Python with Matplotlib and NumPy. These scripts read CSV and JSON records from `plots/data` and write their respective vector PDFs next to `main.tex`.

```sh
python -B plots/transfer.py
python -B plots/admission_gains.py
python -B plots/evidence.py
python -B plots/cap.py
```

The recorded build used Python 3.10, Matplotlib 3.7.2 and NumPy 1.26.4. The files under `data/holdout/`, `data/bound/`, `data/cap-diagnostic/` and `data/prospective-device/` are byte-for-byte copies of the corresponding records under `tracks/interference/` in the experiment archive. The device panels use all twelve paired block measurements per condition and predictions recorded before validation. The replay figure uses 200 question-level comparisons and the archived cohort bounds. The output-limit figure uses all 32 paired questions and the three archived estimates and intervals.

The admission-gains figure uses modeled times for the same 200 questions under three admission rules. To regenerate `data/admission-gains.csv` from the full experiment archive, run `python -B plots/admission_gains.py --extract-from PATH/TO/tracks/interference` from the directory containing `main.tex`. The script checks the source files' hashes and joins their records by question ID. `data-sha256.json` records the SHA-256 hashes of all eight plotting inputs.
