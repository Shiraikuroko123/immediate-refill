"""Draw the three-slot price example in the fixed-panel corollary."""

import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
from matplotlib import pyplot as plt


# Let pdfLaTeX embed Type 1 fonts for both tick labels and math.
plt.rcParams.update({
    "pgf.texsystem": "pdflatex", "pgf.rcfonts": False,
    "pgf.preamble": r"\usepackage[T1]{fontenc}\usepackage{helvet,amssymb}",
    "font.family": "sans-serif",
})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path,
                        default=Path(__file__).resolve().parents[1] / "price-hull.pdf")
    args = parser.parse_args()

    # For these prices the endpoint chord lies above every interior point.
    # Every concave majorant is at least as high as that chord.
    widths = (0, 1, 2, 3)
    costs = (0, 1, 1, 6)
    majorant = tuple(costs[-1] * k / widths[-1] for k in widths)
    assert all(c <= h for c, h in zip(costs, majorant))

    plt.rcParams.update({ "font.family": "sans-serif",
                         "font.size": 8.25, "axes.linewidth": 0.65})
    fig, ax = plt.subplots(figsize=(3.25, 1.60))
    fig.subplots_adjust(left=0.14, right=0.97, bottom=0.25, top=0.96)
    ink = "#263845"
    blue = "#46758f"
    ax.plot(widths, costs, color=ink, lw=1.5, marker="o", ms=4,
            zorder=3, label=r"Step cost $c_k$")
    ax.plot(widths, majorant, color=blue, lw=1.4, ls=(0, (4, 2)),
            marker="D", ms=4.1, mfc="white", markevery=[1, 2],
            label=r"Least concave majorant $\hat c_k$")
    ax.annotate("", xy=(2, 3.92), xytext=(2, 1.08),
                arrowprops=dict(arrowstyle="<->", lw=0.85, color=ink,
                                shrinkA=1.8, shrinkB=2.1, mutation_scale=7))
    ax.text(1.94, 2.25, r"$4/1$", color=ink, ha="right", va="center", size=9)
    ax.legend(loc="upper left", bbox_to_anchor=(0.01, 1.04), borderaxespad=0,
              frameon=False, handlelength=1.65, labelspacing=0.2, handletextpad=0.55)
    ax.set(xlim=(-0.07, 3.08), ylim=(-0.2, 6.45), xticks=widths,
           yticks=(0, 1, 4, 6), xlabel=r"Active width $k$", ylabel="Step cost")
    ax.tick_params(length=2.4, width=0.65, pad=2)
    ax.spines[["right", "top"]].set_visible(False)
    fig.savefig(args.out, backend="pgf", metadata={"CreationDate": None, "ModDate": None})
    plt.close(fig)


if __name__ == "__main__":
    main()
