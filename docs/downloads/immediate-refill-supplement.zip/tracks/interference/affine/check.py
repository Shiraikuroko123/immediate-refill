"""Independently enumerate safe integer-clock schedules and all terminal work totals."""
from collections import Counter
from functools import lru_cache
from itertools import product
import json
from pathlib import Path


@lru_cache(None)
def gap(votes):
    counts = sorted(Counter(x for x in votes if x).values(), reverse=True) + [0, 0]
    return counts[0] - counts[1]


def serial(votes):
    for k in range(1, len(votes)):
        if gap(votes[:k]) > len(votes) - k:
            return k
    return len(votes)


@lru_cache(None)
def safe_limit(partial):
    holes = [i for i, label in enumerate(partial) if label == "?"]
    filled = list(partial)
    bound = len(partial)
    for labels in product("AB-", repeat=len(holes)):
        for idx, label in zip(holes, labels):
            filled[idx] = "" if label == "-" else label
        bound = min(bound, serial(tuple(filled)))
    return bound


def possibilities(work, votes, p, q):
    """Return all width histograms reachable by an admissible timer on integer ticks."""
    n = len(votes)
    @lru_cache(None)
    def advance(state, greedy):
        observed = tuple(votes[i] if i < len(state) and state[i] == 0 else "?" for i in range(n))
        done = tuple(v for v in observed if v != "?")
        if gap(done) > n - len(done) or len(done) == q:
            assert len(done) == len(state) == min(serial(votes), q)
            return {(0,) * p}
        limit = min(q, safe_limit(observed), len(done) + p)
        counts = set()
        for new in range(limit if greedy else len(state), limit + 1):
            remaining = state + work[len(state):new]
            width = sum(v > 0 for v in remaining)
            if width == 0:
                continue
            after = tuple(max(0, v - 1) for v in remaining)
            for child in advance(after, greedy):
                hist = list(child)
                hist[width-1] += 1
                counts.add(tuple(hist))
        assert counts
        return counts
    legal = advance((), False)
    eager, = advance((), True)
    return legal, eager


def price(h, costs):
    return sum(a*b for a, b in zip(h, costs))


def main():
    affine_parameters = [(1, 0), (0, 2), (2, 1), (5, -1)]
    counts = dict(panel_settings=0, distinct_occupancy_histograms=0, affine_comparisons=0,
                  full_width_comparisons=0, three_slot_curve_comparisons=0)
    curves = {(2, 1): [False,0], (2, 3): [False,0], (2,4): [False,0], (2,5): [False,0]}
    for n in (2, 3, 4):
        for votes, work, p, q in product(product(("", "A", "B"),repeat=n), product((1, 2),repeat=n),
                                         range(1, min(3,n)+1), range(1,n+1)):
            all_h, eager = possibilities(work,votes,p,q)
            expected_work = sum(work[:min(q, serial(votes))])
            assert {price(h, range(1, p+1)) for h in all_h} == {expected_work}
            assert sum(eager) == min(map(sum, all_h))
            assert eager[-1] == max(h[-1] for h in all_h)
            counts["full_width_comparisons"] += len(all_h)
            counts["panel_settings"] += 1
            counts["distinct_occupancy_histograms"] += len(all_h)
            for a,b in affine_parameters:
                c = [a+b*k for k in range(1,p+1)]
                assert price(eager,c) == min(price(h,c) for h in all_h)
                counts["affine_comparisons"] += 1
            if p==2:
                for c,record in curves.items():
                    if price(eager,c)>min(price(h,c) for h in all_h):
                        record[0]=True
                        record[1]+=1
            if p==3:
                for curve in ((10,15,17),(10,18,19),(6,5,3),(2,4,6),(10,19,25)):
                    assert curve[1] <= 2*curve[0] and curve[0]+curve[2] <= 2*curve[1]
                    assert price(eager,curve) == min(price(h,curve) for h in all_h)
                    counts["three_slot_curve_comparisons"] += 1
    assert all(record[0] == (c[1] > 2*c[0]) for c,record in curves.items())
    hist, eager = possibilities((2,1,1,2), ("A","A","A","B"),3,3)
    assert eager==(1,0,1) and (0,2,0) in hist and min(price(h,(10,11,13)) for h in hist)==22
    print(json.dumps(dict(**counts, curves=[dict(cost=c,witnesses=v[1]) for c,v in curves.items()],
                          three_slot_witness=dict(greedy=eager, comparison=(0,2,0),costs=(10,11,13),
                                                  greedy_time=23, optimal_integer_time=22)),indent=2))


if __name__=="__main__":
    main()
