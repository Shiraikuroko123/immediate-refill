"""Generate manuscript figures and the development table from archived replay rows."""
from pathlib import Path
import csv
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent
SCHEDULE = HERE.parent / "tracks" / "scheduling"
sys.path.insert(0, str(SCHEDULE))
from schedule import simulate

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8.5, "pdf.fonttype": 42,
                     "axes.spines.top": False, "axes.spines.right": False})
BLUE, DARK, GOLD = "#216782", "#213448", "#A4571E"


def example():
    answers, lengths = ["A", "B", "A", "B"], [1, 1, 4, 3]
    fig, axes = plt.subplots(2, 1, figsize=(6.15, 2.3), sharex=True, layout="constrained")
    for ax, (mode, label, launches) in zip(axes, [
        ("rolling", "Committed wave", [0,0,0,4]), ("refill","Immediate refill",[0,0,0,1])]):
        res = simulate(lengths,answers,mode,3)
        assert res["tokens"]==9 and res["steps"]==max(t+l for t,l in zip(launches,lengths))
        for idx, (s, d, slot) in enumerate(zip(launches,lengths,[0,1,2,0])):
            ax.barh(slot,d,left=s,height=.66,color=GOLD if idx==3 else BLUE)
            ax.text(s+d/2,slot,str(idx+1),ha="center",va="center",color="white",fontsize=7,weight="bold")
        ax.set_yticks([]); ax.set_ylim(2.6,-.6)
        ax.set_title(label,loc="left",fontsize=9,weight="bold")
        ax.spines["left"].set_visible(False); ax.spines["bottom"].set_color("#aab6c0")
        ax.set_xlim(-.02,7.1); ax.set_xticks(range(8))
    axes[1].set_xlabel("Elapsed service time")
    fig.savefig(HERE/"example.pdf",bbox_inches="tight"); plt.close(fig)


def results():
    directory=SCHEDULE/"runs"/"dev-01"
    with (directory/"rolling.csv").open() as fp: rows=list(csv.DictReader(fp))
    with (directory/"summary.csv").open() as fp: summary=list(csv.DictReader(fp))
    keys=[(8,8),(16,16),(8,4),(16,4)]
    fig, ax=plt.subplots(figsize=(6.4,2.75),layout="constrained")
    table=[]
    for i,(n,cap) in enumerate(keys):
        group=[r for r in rows if (int(r["n"]),int(r["cap"]))==(n,cap)]
        def gain(records):
            return 100*(1-sum(int(r["refill"]) for r in records)/sum(int(r["rolling"]) for r in records))
        g = gain(group)
        for q, marker in enumerate(["o","s","^","v"]):
            subset = [r for r in group if int(r["qid"])==q]
            ax.scatter(i+(q-1.5)*.12,gain(subset),s=31,marker=marker,color=BLUE,alpha=.85,
                       label=f"Q{q+1}" if i==0 else None)
        ax.plot([i-.26,i+.26],[g,g],color=GOLD,lw=2.2,label="Pooled" if i==0 else None)
        old=next(r for r in summary if r["qid"]=="all" and int(r["n"])==n and int(r["cap"])==cap and float(r["b"])==0)
        a,b=sum(int(r["refill"]) for r in group),sum(int(r["rolling"]) for r in group)
        strict=sum(int(r["refill"])<int(r["rolling"]) for r in group)
        table.append(f"{n} & {cap} & {len(group)} & {a:,} & {b:,} & {g:.2f}\\% & "
                     f"{float(old['reduction_vs_barrier'])*100:.2f}\\% & {strict} \\\\")
    ax.axhline(5,color="#82909a",ls=":",lw=1)
    ax.text(3.35,5.16,"5%",ha="right",color="#586875",fontsize=7.5)
    ax.set_ylim(-.3,6); ax.set_ylabel("Modeled time reduction (%)")
    ax.set_xticks(range(4),["8 / 8","16 / 16","8 / 4","16 / 4"]); ax.set_xlabel("Panel size / available slots")
    ax.legend(loc="upper left",ncol=5,fontsize=7,frameon=False)
    fig.savefig(HERE/"development.pdf",bbox_inches="tight"); plt.close(fig)
    (HERE/"development-table.tex").write_text("\n".join(table)+"\n\\bottomrule\n")


if __name__=="__main__":
    example()
    results()
