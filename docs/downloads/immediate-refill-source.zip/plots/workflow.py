"""Draw the online indexed immediate-refill rule from Section 2."""

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, Rectangle


# Let pdfLaTeX embed Type 1 fonts for both tick labels and math.
plt.rcParams.update({
    "pgf.texsystem": "pdflatex", "pgf.rcfonts": False,
    "pgf.preamble": r"\usepackage[T1]{fontenc}\usepackage{helvet,amssymb}",
    "font.family": "sans-serif",
})


def main():
    plt.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.size": 8.5,
            "mathtext.fontset": "dejavusans",
            "text.color": "#202a30",
        }
    )
    # Use printer's points as the coordinate system at the intended two-column size.
    width, height = 486, 124
    fig = plt.figure(figsize=(width / 72, height / 72))
    ax = fig.add_axes([0, 0, 1, 1], xlim=(0, width), ylim=(0, height))
    ax.set_axis_off()
    ink = "#374a56"

    def panel(x, y, w, h, fill):
        ax.add_patch(Rectangle((x, y), w, h, facecolor=fill, edgecolor=ink, lw=0.85))

    def label(x, y, value, *, bold=False, size=8.5):
        ax.text(x, y, value, va="center", ha="left", fontsize=size,
                fontweight="bold" if bold else "normal")

    def arrow(points):
        xs, ys = zip(*points[:-1])
        ax.plot(xs, ys, color=ink, lw=0.9, solid_capstyle="butt")
        ax.add_patch(FancyArrowPatch(points[-2], points[-1], arrowstyle="-|>",
                                     mutation_scale=7.2, linewidth=0.9,
                                     shrinkA=0, shrinkB=0.6, color=ink))

    panel(2, 47.5, 134, 46, "#f0f3f4")
    label(9, 82, "Check for a decision", bold=True, size=9.3)
    label(9, 67.5, r"Strict lock: $\mathrm{gap}(S)>N-|S|$")
    label(9, 54.5, r"or quota complete: $|S|=Q$")

    panel(163, 47.5, 174, 46, "#edf2f4")
    label(170, 82, "Refill in index order", bold=True, size=9.3)
    label(170, 67.5, r"$F=\min\{Q,\,|S|+P,\,M(S)+B\}$", size=9)
    label(170, 54.5, r"Launch $J+1$ through $F$ and set $J=F$.")

    panel(350, 47.5, 134, 46, "#f9fafb")
    label(357, 82, "Decode to next return", bold=True, size=9.3)
    label(357, 67.5, r"Active width $k=J-|S|$.")
    label(357, 54.5, r"Each virtual unit costs $c_k$.")

    arrow([(136, 70), (163, 70)])
    label(142, 77, "No", size=8.2)
    arrow([(337, 70), (350, 70)])

    label(3, 117, r"Start with $S=\varnothing,\ J=0$", size=8.7)
    arrow([(26, 109), (26, 93.5)])
    arrow([(420, 93.5), (420, 105), (118, 105), (118, 93.5)])
    label(122, 116, r"Add every finishing index to $S$ and record its vote or abstention.")

    panel(74, 2, 410, 32, "#ffffff")
    arrow([(33, 47.5), (33, 18), (74, 18)])
    label(39, 33, "Yes", size=8.2)
    label(82, 24.5, "Strict lock", bold=True)
    label(148, 24.5, "Return the certified winner and cancel any active paths.")
    label(82, 11.5, "Quota only", bold=True)
    label(148, 11.5, r"Return the plurality using the tie rule. Mark uncertified if $Q<N$.")

    fig.savefig(
        Path(__file__).resolve().parents[1] / "indexed-workflow.pdf",
        backend="pgf", metadata={"Title": "Online indexed immediate-refill scheduler",
                  "CreationDate": None, "ModDate": None},
    )
    plt.close(fig)


if __name__ == "__main__":
    main()
