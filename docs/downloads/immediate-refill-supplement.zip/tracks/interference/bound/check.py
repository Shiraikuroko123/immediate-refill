"""Exhaust each small schedule, using vote completion enumeration to check safe actions."""
from collections import Counter
from functools import lru_cache
from itertools import product
from fractions import Fraction as F
from pathlib import Path
import argparse
import json
from panel_bound import lower_demands, price


def decisive(votes, n):
    counts = Counter(x for x in votes if x is not None)
    top = sorted(counts.values(), reverse=True) + [0, 0]
    return top[0] - top[1] > n-len(votes)


@lru_cache(None)
def first_possible_prefix(partial):
    """Enumerate unseen labels. - is unknown and None is a completed abstention."""
    missing = [i for i, x in enumerate(partial) if x == "-"]
    n = len(partial)
    best = n
    for assignment in product(("A","B",None), repeat=len(missing)):
        votes = list(partial)
        for i,x in zip(missing,assignment):
            votes[i] = x
        for t in range(1,best):
            if decisive(votes[:t], n):
                best = t
                break
    return best


def optimal(lengths, votes, slots, quota, excess, curves, resolution):
    @lru_cache(None)
    def go(state):
        observed = [votes[i] for i,x in enumerate(state) if x==0]
        if decisive(observed, len(votes)) or len(observed)==quota:
            return (0,)*len(curves)
        partial = tuple(votes[i] if i<len(state) and not state[i] else "-" for i in range(len(votes)))
        limit = min(quota, len(observed)+slots, first_possible_prefix(partial)+excess)
        result = None
        for j in range(len(state),limit+1):
            current = state + tuple(resolution*lengths[i] for i in range(len(state),j))
            width = sum(w>0 for w in current)
            if width:
                sub = go(tuple(max(0,x-1) for x in current))
                option = tuple(row[width-1]+t for row,t in zip(curves,sub))
                result = option if result is None else tuple(map(min,zip(result,option)))
        if result is None:
            raise AssertionError("No legal advancing action")
        return result
    return tuple(F(t,resolution) for t in go(()))


def main(out):
    nchecks = tightened = exact = faster = halfchecked = 0
    for n in (3,4):
        labels = list(product("AB",repeat=n)) + [tuple([None]*(n-1)+["A"]), tuple(["B",None]+["A"]*(n-2))]
        for votes, lengths, slots, quota, excess in product(
            labels,product((1,2),repeat=n), (2,3), (n-1,n), (0,1)):
            curves = [row[:slots] for row in ((5,6,8),(7,5,6),(3,7,5),(6,6,6))]
            opt = optimal(lengths,votes,slots,quota,excess,curves,1)
            half = optimal(lengths,votes,slots,quota,excess,curves,2)
            assert opt == half
            halfchecked += len(curves)
            ticks, widths, demand, _ = lower_demands(lengths,votes,slots,quota,excess)
            for costs, value in zip(curves,opt):
                upper = sum(costs[w-1]*dt for w,dt in widths.items())
                floor = price(demand,costs)
                simple = ticks*min(costs)
                if not simple <= floor <= value <= upper:
                    raise AssertionError((lengths,votes,slots,quota,excess,costs,simple,floor,value,upper))
                nchecks += 1
                tightened += floor > simple
                exact += floor==value
                faster += value<upper
    results = dict(configurations=nchecks, independently_matched_half_ticks=halfchecked, bound_tight=exact,
                   bound_stricter_than_unweighted_virtual_floor=tightened, oracle_strictly_better_than_greedy=faster)
    with out.open("x",encoding="utf8") as f:
        json.dump(results,f,indent=2)
        f.write("\n")
    print(results)


if __name__=="__main__":
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--out",required=True,type=Path)
    main(ap.parse_args().out)
