"""Verify the artifact and recompute each result group from the extracted inputs."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
STUDY = ROOT / "tracks/interference"
SENS = ROOT / "analysis/sensitivity"


def read(path):
    return json.loads(path.read_bytes())


def equal(left, right):
    """Allow floating-point round-off across supported NumPy builds."""
    if isinstance(left, dict):
        return isinstance(right, dict) and left.keys() == right.keys() and all(equal(left[k], right[k]) for k in left)
    if isinstance(left, list):
        return isinstance(right, list) and len(left) == len(right) and all(equal(x, y) for x, y in zip(left, right))
    if isinstance(left, float):
        return isinstance(right, (int, float)) and math.isclose(left, right, rel_tol=1e-10, abs_tol=1e-10)
    return left == right


def check(value, expected, name):
    if not equal(value, expected):
        raise ValueError(f"Recomputed result differs for {name}")
    return value


def run(script, *args, cwd=ROOT):
    env = dict(os.environ, PYTHONIOENCODING="utf-8", OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1")
    process = subprocess.run([sys.executable, "-B", str(script), *map(str, args)],
                             cwd=cwd, capture_output=True, encoding="utf8", errors="replace", env=env)
    if process.returncode:
        raise RuntimeError(f"{script.name} failed\n{process.stderr}\n{process.stdout[-2500:]}")
    return process.stdout


def numeric(tmp):
    manifest = read(ROOT / "MANIFEST.sha256.json")
    for name, digest in manifest.items():
        file = (ROOT / name).resolve()
        if not file.is_relative_to(ROOT) or hashlib.sha256(file.read_bytes()).hexdigest() != digest:
            raise ValueError(f"SHA-256 differs for {name}")
    print(f"Checked {len(manifest)} file fingerprints.", flush=True)
    results = {"verified_files":len(manifest), "python":platform.python_version()}

    def legacy():
        summary = json.loads(run(ROOT / "check.py"))
        run(ROOT / "cpu/replay.py", "--root", ROOT, "--report", tmp / "core.json")
        full = check(read(tmp / "core.json"), read(ROOT / "cpu/numerical-check.json"), "14 core groups")
        return {"device_and_oracle":summary, "fourteen_groups":full}

    def theory():
        checks = {"fixed_spec":"acceptance-review/fixed", "three_prices":"acceptance-review/three-prices",
                  "zero_budget":"affine", "virtual_wait_bound":"policy", "wall_wait_bound":"policy"}
        drivers = {"virtual_wait_bound":("check_bound.py","results/bound.json"),
                   "wall_wait_bound":("check_clock.py","results/clock-bound.json")}
        block = {}
        for name, folder in checks.items():
            program, expected = drivers.get(name, ("check.py","results.json"))
            path = STUDY / folder
            block[name] = check(json.loads(run(path / program)), read(path / expected), name)
        out = tmp / "certificate.json"
        run(STUDY / "bound/check.py", "--out", out)
        block["certificate_primal_oracle"] = check(read(out), read(STUDY / "bound/results/oracle.json"), "certificate bound")
        return block

    def pilot():
        folder = STUDY / "gsm_live"
        target = tmp / "pilot"
        run(folder / "analyze.py", "--raw", folder / "raw", "--out", target)
        summary = check(read(target/"summary.json"), read(folder/"results/summary.json"), "16-problem device records")
        for name in ("questions.csv", "references.csv"):
            check((target/name).read_text("utf8"), (folder/"results"/name).read_text("utf8"), name)
        return {"fixed":summary["results"]["fixed"], "natural":summary["results"]["natural"]}

    def sensitivity():
        block = {}
        # The oracle grid independently checks the recomputed per-question oracle output.
        for run_name, saved in [("empirical-sensitivity","empirical-sensitivity"),
                                ("shard-sensitivity","shard-sensitivity"),
                                ("third-launch-oracle","third-launch-oracle"),
                                ("verify-third-launch-grid","third-launch-grid-check")]:
            run(SENS / (run_name+".py"), "--out-dir", tmp)
            value = check(read(tmp / (saved+".json")), read(SENS / "expected" / (saved+".json")), saved)
            block[saved] = value.get("summary", value)
        return block

    cases = {"archived_replay":legacy, "finite_theory":theory,
             "sixteen_question_pilot":pilot, "retrospective_sensitivity":sensitivity}
    with ThreadPoolExecutor(max_workers=3) as executor:
        jobs = {k:executor.submit(fn) for k,fn in cases.items()}
        for k,job in jobs.items():
            results[k] = job.result()
            print(f"Recomputed {k}.", flush=True)
    return results


def figures(destination):
    destination.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp) / "figures"
        shutil.copytree(ROOT / "figures", base)
        for script in ("make_timeline.py", "plots/workflow.py", "plots/price_hull.py", "plots/transfer.py",
                       "plots/admission_gains.py", "plots/evidence.py", "plots/cap.py"):
            run(base / script, cwd=base)
        pdfs = sorted(base.glob("*.pdf"))
        if len(pdfs) != 7 or any(not p.read_bytes().startswith(b"%PDF-") for p in pdfs):
            raise ValueError("Expected seven regenerated vector PDFs")
        for path in pdfs:
            if (destination / path.name).exists():
                raise FileExistsError(destination / path.name)
        for path in pdfs:
            shutil.copyfile(path, destination / path.name)
        return [p.name for p in pdfs]


if __name__ == "__main__":
    if not __debug__:
        raise SystemExit("Use Python without -O so that the scientific assertions run.")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", required=True, type=Path, help="fresh path for the JSON report")
    parser.add_argument("--figures", type=Path, help="also render seven PDFs; requires Matplotlib and pdfLaTeX")
    args = parser.parse_args()
    if args.out.exists():
        raise SystemExit("Choose a new --out path; the report already exists.")
    with tempfile.TemporaryDirectory() as tmp:
        report = numeric(Path(tmp))
        if args.figures:
            report["generated_figures"] = figures(args.figures)
    with args.out.open("x", encoding="utf8") as output:
        json.dump(report, output, indent=2, allow_nan=False)
        output.write("\n")
    print("Wrote", args.out)
